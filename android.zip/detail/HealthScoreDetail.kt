// جزئیات امتیاز سلامت
package com.avina.health.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthScoreDetailScreen(
    onBackClick: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "جزئیات امتیاز سلامت",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppTheme.colors.textPrimary
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "بازگشت",
                                tint = AppTheme.colors.textPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = AppTheme.colors.pageBackground
                    )
                )
            },
            containerColor = AppTheme.colors.pageBackground
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // دایره بزرگ امتیاز ۷۸
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { 0.78f },
                        modifier = Modifier.size(110.dp),
                        color = Color(0xFF2A65F0),
                        trackColor = AppTheme.colors.cardBackground,
                        strokeWidth = 10.dp
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "78",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppTheme.colors.textPrimary
                        )
                        Text(
                            text = "از 100",
                            fontSize = 12.sp,
                            color = AppTheme.colors.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "عالی",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF10B981)
                )
                Text(
                    text = "امتیاز شما بر اساس ۵ شاخص کلیدی محاسبه شده است.",
                    fontSize = 11.sp,
                    color = AppTheme.colors.textSecondary
                )

                Spacer(modifier = Modifier.height(24.dp))

                // لیست فاکتورها
                ScoreProgressItem(title = "قند خون", scoreText = "85/100", progress = 0.85f, color = Color(0xFF2A65F0))
                ScoreProgressItem(title = "چربی خون", scoreText = "70/100", progress = 0.70f, color = Color(0xFF2A65F0))
                ScoreProgressItem(title = "ویتامین‌ها", scoreText = "60/100", progress = 0.60f, color = Color(0xFF2A65F0))
                ScoreProgressItem(title = "عملکرد کبد", scoreText = "90/100", progress = 0.90f, color = Color(0xFF2A65F0))
                ScoreProgressItem(title = "التهاب و استرس", scoreText = "80/100", progress = 0.80f, color = Color(0xFF2A65F0))

                Spacer(modifier = Modifier.height(20.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground)
                ) {
                    Text(
                        text = "با ادامه سبک زندگی سالم، امتیاز شما می‌تواند به بالای ۹۰ برسد.",
                        fontSize = 12.sp,
                        color = Color(0xFF2A65F0),
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ScoreProgressItem(title: String, scoreText: String, progress: Float, color: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppTheme.colors.textPrimary
                )
                Text(
                    text = scoreText,
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = color,
                trackColor = AppTheme.colors.pageBackground
            )
        }
    }
}