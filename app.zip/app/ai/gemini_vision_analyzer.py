import os
import json
import base64
import logging

from dotenv import load_dotenv
from google import genai


load_dotenv()


logger = logging.getLogger(__name__)


class GeminiVisionAnalyzer:
    """
    ارسال تصویر آزمایش به Gemini Vision
    و دریافت JSON ساختاریافته
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None
    ):

        self.api_key = (
            api_key
            or os.getenv("GEMINI_API_KEY")
        )


        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY پیدا نشد"
            )


        self.model = (
            model
            or os.getenv(
                "GEMINI_VISION_MODEL",
                "gemini-3.5-flash-lite"
            )
        )


        self.client = genai.Client(
            api_key=self.api_key
        )



    def analyze_image(
        self,
        image_path: str
    ) -> dict:


        with open(
            image_path,
            "rb"
        ) as file:

            image_bytes = file.read()



        image_base64 = base64.b64encode(
            image_bytes
        ).decode("utf-8")



        prompt = """
این تصویر یک برگه آزمایش پزشکی است.

فقط JSON معتبر برگردان.

ساختار خروجی:

{
 "tests":[
  {
   "name":"",
   "value":"",
   "unit":"",
   "reference":""
  }
 ]
}


قوانین:

- فقط نام آزمایش و مقدار را استخراج کن.
- تحلیل پزشکی انجام نده.
- توضیح اضافه نده.
- Markdown استفاده نکن.
- همه موارد آزمایش را استخراج کن.
- JSON معتبر باشد.
"""



        response = (
            self.client
            .models
            .generate_content(

                model=self.model,

                contents=[

                    {
                        "role":"user",
                        "parts":[

                            {
                                "text": prompt
                            },

                            {
                                "inline_data":{

                                    "mime_type":
                                    "image/jpeg",

                                    "data":
                                    image_base64

                                }
                            }

                        ]
                    }

                ],

                config={

                    "response_mime_type":
                    "application/json"

                }

            )
        )



        # =====================
        # TOKEN USAGE
        # =====================

        if (
            hasattr(
                response,
                "usage_metadata"
            )
            and response.usage_metadata
        ):

            usage = response.usage_metadata


            print(
                "\n====== GEMINI VISION TOKEN ======"
            )


            print(
                "Prompt:",
                usage.prompt_token_count
            )


            print(
                "Response:",
                usage.candidates_token_count
            )


            print(
                "Total:",
                usage.total_token_count
            )


            print(
                "=================================\n"
            )



        if not response.text:

            raise Exception(
                "Gemini Vision پاسخ خالی داد"
            )



        return self._parse_json(
            response.text
        )




    def _parse_json(
        self,
        text: str
    ) -> dict:


        text = text.strip()



        text = (
            text
            .replace(
                "```json",
                ""
            )
            .replace(
                "```",
                ""
            )
            .strip()
        )



        return json.loads(
            text
        )