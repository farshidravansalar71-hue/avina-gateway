package com.avina.health.screen.splash

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.R
import kotlinx.coroutines.delay


val vazirFont = FontFamily(
    Font(R.font.vazirmatn_bold)
)


@Composable
fun SplashScreen(
    onFinished: () -> Unit
) {

    var logoVisible by remember { mutableStateOf(false) }
    var titleVisible by remember { mutableStateOf(false) }
    var sloganVisible by remember { mutableStateOf(false) }


    LaunchedEffect(Unit) {

        delay(150)
        logoVisible = true

        delay(350)
        titleVisible = true

        delay(300)
        sloganVisible = true


        delay(1800)

        onFinished()
    }


    val logoAlpha by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0f,
        animationSpec = tween(
            durationMillis = 1200,
            easing = FastOutSlowInEasing
        ),
        label = ""
    )


    val logoScale by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0.88f,
        animationSpec = tween(
            durationMillis = 1200,
            easing = FastOutSlowInEasing
        ),
        label = ""
    )


    val logoOffset by animateFloatAsState(
        targetValue = if (logoVisible) 0f else 25f,
        animationSpec = tween(
            durationMillis = 1200,
            easing = FastOutSlowInEasing
        ),
        label = ""
    )


    val titleAlpha by animateFloatAsState(
        targetValue = if (titleVisible) 1f else 0f,
        animationSpec = tween(700),
        label = ""
    )


    val sloganAlpha by animateFloatAsState(
        targetValue = if (sloganVisible) 1f else 0f,
        animationSpec = tween(700),
        label = ""
    )
    Box(

        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF081220)),

        contentAlignment = Alignment.Center

    ) {


        Column(

            horizontalAlignment = Alignment.CenterHorizontally,

            modifier = Modifier.offset(y = logoOffset.dp)

        ) {


            Image(

                painter = painterResource(id = R.drawable.logo),

                contentDescription = "Logo",

                modifier = Modifier
                    .size(220.dp)
                    .alpha(logoAlpha)
                    .scale(logoScale)

            )


            Spacer(
                modifier = Modifier.height(10.dp)
            )


            // متن‌ها جدا شده‌اند تا فقط خودشان بالا بروند
            Column(

                horizontalAlignment = Alignment.CenterHorizontally,

                modifier = Modifier.offset(y = (-20).dp)

            ) {


                Text(

                    text = "آوین طب",

                    color = Color.White,

                    fontSize = 34.sp,

                    fontWeight = FontWeight.Bold,

                    fontFamily = vazirFont,

                    modifier = Modifier.alpha(titleAlpha)

                )


                Spacer(
                    modifier = Modifier.height(8.dp)
                )


                Text(

                    text = "دستیار هوشمند سلامت",

                    color = Color(0xFF7AE582),

                    fontSize = 16.sp,

                    fontFamily = vazirFont,

                    modifier = Modifier.alpha(sloganAlpha)

                )

            }

        }

    }

}