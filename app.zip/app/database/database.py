from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base


# =========================
# Database URL
# =========================

DATABASE_URL = "sqlite:///./avina.db"


# =========================
# Engine
# =========================

engine = create_engine(
    DATABASE_URL,
    connect_args={
        "check_same_thread": False
    }
)


# =========================
# Base Model
# =========================

Base = declarative_base()