package com.avina.health.network

object ApiConfig {
    // ⚠️ باید دقیقاً همون HMAC_SECRET_KEY باشد که در .env سرور گذاشتی
    const val HMAC_SECRET_KEY = "a3f9c8e21b4d67890fedcba123456789abcdef0123456789abcdef012345678"
}