//دسترسی سریع
package com.avina.health.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue

@Composable
fun QuickActionsSection(
    onAddTestClick: () -> Unit,
    onOcrScanClick: () -> Unit,
    onPdfReportClick: () -> Unit,
    onConsultationClick: () -> Unit,
    onTrendClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        QuickIconBubble(
            icon = {
                Icon(
                    imageVector = Icons.Outlined.AutoGraph,
                    contentDescription = "روند",
                    tint = AppTheme.colors.textSecondary
                )
            },
            onClick = onTrendClick,
            modifier = Modifier.offset(y = 8.dp)
        )

        QuickIconBubble(
            icon = {
                Icon(
                    imageVector = Icons.Outlined.SupportAgent,
                    contentDescription = "مشاوره",
                    tint = AppTheme.colors.textSecondary
                )
            },
            onClick = onConsultationClick,
            modifier = Modifier.offset(y = 8.dp)
        )

        AddPrimaryButton(
            onClick = onAddTestClick
        )

        QuickIconBubble(
            icon = {
                Icon(
                    imageVector = Icons.Outlined.Description,
                    contentDescription = "گزارش",
                    tint = AppTheme.colors.textSecondary
                )
            },
            onClick = onPdfReportClick,
            modifier = Modifier.offset(y = 8.dp)
        )

        QuickIconBubble(
            icon = {
                Icon(
                    imageVector = Icons.Outlined.DocumentScanner,
                    contentDescription = "اسکن",
                    tint = AppTheme.colors.textSecondary
                )
            },
            onClick = onOcrScanClick,
            modifier = Modifier.offset(y = 8.dp)
        )
    }
}

@Composable
private fun QuickIconBubble(
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(50.dp)
            .shadow(
                elevation = 8.dp,
                shape = CircleShape,
                ambientColor = Color(0x14000000),
                spotColor = Color(0x14000000)
            )
            .background(AppTheme.colors.cardBackground, CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        icon()
    }
}

@Composable
private fun AddPrimaryButton(
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(66.dp)
            .shadow(
                elevation = 14.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.22f),
                spotColor = PrimaryBlue.copy(alpha = 0.22f)
            )
            .background(
                color = PrimaryBlue,
                shape = RoundedCornerShape(24.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.Add,
            contentDescription = "افزودن آزمایش",
            tint = Color.White,
            modifier = Modifier.size(30.dp)
        )
    }
}