package com.avina.health.screen.register

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.R
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import com.avina.health.utils.LocalLanguage

@Composable
fun RegisterScreen(
    onLoginClick: () -> Unit,
    onGuestClick: () -> Unit,
    onRegisterClick: () -> Unit
) {
    val currentLang = LocalLanguage.current
    val isEnglish = currentLang == "en"

    val pulseTransition = rememberInfiniteTransition(
        label = "logo_pulse"
    )

    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1100,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1100,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AppTheme.colors.cardBackground,
                        AppTheme.colors.cardBackground.copy(alpha = 0.8f)
                    )
                )
            )
    ) {
        DecorativeBackground()

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.80f)
                .widthIn(max = 390.dp)
                .align(Alignment.Center)
                .padding(horizontal = 18.dp),
            shape = RoundedCornerShape(42.dp),
            colors = CardDefaults.cardColors(
                containerColor = AppTheme.colors.cardBackground
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 10.dp
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        horizontal = 22.dp,
                        vertical = 20.dp
                    )
                    .verticalScroll(
                        rememberScrollState()
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Box(
                    modifier = Modifier
                        .height(122.dp)
                        .padding(top = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(
                            id = R.drawable.register_logo
                        ),
                        contentDescription = "لوگوی آوینا",
                        modifier = Modifier
                            .size(122.dp)
                            .scale(pulseScale)
                            .alpha(pulseAlpha),
                        contentScale = ContentScale.Fit
                    )
                }

                Spacer(
                    modifier = Modifier.height(14.dp)
                )

                Text(
                    text = if (isEnglish) "Avin Med" else "آوین طب",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = AppTheme.colors.textPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(
                    modifier = Modifier.height(6.dp)
                )

                Text(
                    text = if (isEnglish) "Smart Health Assistant" else "دستیار هوشمند سلامت",
                    style = MaterialTheme.typography.bodyLarge,
                    color = AppTheme.colors.textSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = if (isEnglish)
                        "Create your account and benefit\nfrom smart health services."
                    else
                        "حساب کاربری خود را ایجاد کنید\nو از خدمات هوشمند سلامت بهره‌مند شوید.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppTheme.colors.textSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(
                    modifier = Modifier.height(24.dp)
                )

                PrimaryActionButton(
                    text = if (isEnglish) "Create Account" else "ایجاد حساب",
                    iconText = "👤＋",
                    onClick = onRegisterClick,
                    isEnglish = isEnglish
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                SecondaryActionButton(
                    text = if (isEnglish) "Login" else "ورود",
                    iconText = "↪",
                    onClick = onLoginClick,
                    isEnglish = isEnglish
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                GuestActionButton(
                    text = if (isEnglish) "Continue as Guest" else "ادامه بدون حساب",
                    iconText = "👤",
                    onClick = onGuestClick
                )

                Spacer(
                    modifier = Modifier.height(18.dp)
                )

                BenefitsCard(isEnglish = isEnglish)
            }
        }
    }
}

@Composable
private fun PrimaryActionButton(
    text: String,
    iconText: String,
    onClick: () -> Unit,
    isEnglish: Boolean
) {
    val shape = RoundedCornerShape(26.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .shadow(10.dp, shape)
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        PrimaryBlue,
                        PrimaryBlue.copy(alpha = 0.8f)
                    )
                )
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .align(if (isEnglish) Alignment.CenterEnd else Alignment.CenterStart)
                .size(30.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.95f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = iconText,
                fontSize = 12.sp,
                color = PrimaryBlue
            )
        }

        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.Bold
            ),
            color = Color.White
        )

        Text(
            text = if (isEnglish) "›" else "‹",
            fontSize = 24.sp,
            color = Color.White,
            modifier = Modifier.align(if (isEnglish) Alignment.CenterStart else Alignment.CenterEnd)
        )
    }
}

@Composable
private fun DecorativeBackground() {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        androidx.compose.foundation.Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            drawCircle(
                color = PrimaryBlue.copy(alpha = 0.08f),
                radius = size.minDimension * 0.26f,
                center = androidx.compose.ui.geometry.Offset(
                    size.width * 0.98f,
                    size.height * 0.12f
                )
            )

            drawCircle(
                color = PrimaryBlue.copy(alpha = 0.08f),
                radius = size.minDimension * 0.22f,
                center = androidx.compose.ui.geometry.Offset(
                    size.width * 0.02f,
                    size.height * 0.88f
                )
            )
        }
    }
}

@Composable
private fun SecondaryActionButton(
    text: String,
    iconText: String,
    onClick: () -> Unit,
    isEnglish: Boolean
) {
    val shape = RoundedCornerShape(26.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(AppTheme.colors.cardBackground)
            .border(
                1.dp,
                PrimaryBlue.copy(alpha = 0.3f),
                shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .align(if (isEnglish) Alignment.CenterEnd else Alignment.CenterStart)
                .size(30.dp)
                .clip(CircleShape)
                .background(PrimaryBlue.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = iconText,
                fontSize = 12.sp,
                color = PrimaryBlue
            )
        }

        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.SemiBold
            ),
            color = PrimaryBlue
        )

        Text(
            text = if (isEnglish) "›" else "‹",
            fontSize = 24.sp,
            color = PrimaryBlue,
            modifier = Modifier.align(if (isEnglish) Alignment.CenterStart else Alignment.CenterEnd)
        )
    }
}

@Composable
private fun GuestActionButton(
    text: String,
    iconText: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(26.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(shape)
            .border(
                1.dp,
                PrimaryBlue.copy(alpha = 0.2f),
                shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(30.dp)
                .clip(CircleShape)
                .background(AppTheme.colors.cardBackground),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = iconText,
                fontSize = 12.sp,
                color = PrimaryBlue
            )
        }

        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.SemiBold
            ),
            color = PrimaryBlue
        )
    }
}

@Composable
private fun BenefitsCard(isEnglish: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppTheme.colors.cardBackground
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 18.dp,
                    horizontal = 10.dp
                ),
            verticalAlignment = Alignment.Top
        ) {
            BenefitItem(
                modifier = Modifier.weight(1f),
                icon = "🛡️",
                title = if (isEnglish) "Secure" else "امن",
                subtitle = if (isEnglish) "Your Data" else "اطلاعات شما"
            )

            VerticalDivider()

            BenefitItem(
                modifier = Modifier.weight(1f),
                icon = "🧠",
                title = if (isEnglish) "AI" else "هوش مصنوعی",
                subtitle = if (isEnglish) "Smart lab test analysis" else "تحلیل هوشمند نتایج\nآزمایش‌ها"
            )

            VerticalDivider()

            BenefitItem(
                modifier = Modifier.weight(1f),
                icon = "🩺",
                title = if (isEnglish) "Health access" else "سلامت در دسترس شما",
                subtitle = if (isEnglish) "Health services anytime, anywhere" else "خدمات سلامت در هر زمان\nو مکان"
            )
        }
    }
}

@Composable
private fun VerticalDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(88.dp)
            .background(PrimaryBlue.copy(alpha = 0.15f))
    )
}

@Composable
private fun BenefitItem(
    modifier: Modifier,
    icon: String,
    title: String,
    subtitle: String
) {
    Column(
        modifier = modifier.padding(horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(PrimaryBlue.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = icon,
                fontSize = 20.sp
            )
        }

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold
            ),
            color = AppTheme.colors.textPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(
            modifier = Modifier.height(4.dp)
        )

        Text(
            text = subtitle,
            fontSize = 11.sp,
            color = AppTheme.colors.textSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp
        )
    }
}