package com.avina.health.screen.notification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avina.health.data.NotificationDao
import com.avina.health.data.NotificationEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotificationViewModel(private val dao: NotificationDao) : ViewModel() {

    // دریافت داده‌ها به صورت StateFlow با مدیریت چرخه حیات
    val notifications: StateFlow<List<NotificationEntity>> = dao.getAllNotifications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // متد حذف اعلان
    fun deleteNotification(notification: NotificationEntity) {
        viewModelScope.launch {
            dao.deleteNotification(notification)
        }
    }
}

// فکتوری استاندارد برای ساخت ویومدل دارای پارامتر DAO
class NotificationViewModelFactory(private val dao: NotificationDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotificationViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NotificationViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}