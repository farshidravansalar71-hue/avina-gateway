import json
from dataclasses import asdict
from typing import List

from app.ocr.lab_result_parser import LabResult


class LabResultJsonExporter:
    """
    تبدیل خروجی LabResult به JSON
    برای ارسال به Gemini API
    """

    def export(
        self,
        results: List[LabResult],
    ) -> str:

        data = []

        for item in results:
            data.append(
                {
                    "test_name": item.test_name,
                    "result": item.result,
                    "flag": item.flag,
                    "unit": item.unit,
                    "reference": item.reference,
                    "category": item.category,
                }
            )

        return json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
        )


    def export_dict(
        self,
        results: List[LabResult],
    ) -> list:

        return [
            {
                "test_name": item.test_name,
                "result": item.result,
                "flag": item.flag,
                "unit": item.unit,
                "reference": item.reference,
                "category": item.category,
            }
            for item in results
        ]