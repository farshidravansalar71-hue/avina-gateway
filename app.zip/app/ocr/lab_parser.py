import re
from typing import List, Dict


class LabResultParser:

    FLAGS = {
        "high",
        "low",
        "h",
        "l",
        "abnormal",
        "positive",
        "negative",
        "pos",
        "neg",
    }


    def parse(self, tables) -> List[Dict]:

        results = []

        for table in tables:

            category = getattr(
                table,
                "type",
                None
            )

            for row in table.rows:

                cells = [
                    c.text.strip()
                    for c in row.cells
                    if c.text.strip()
                ]

                item = self._parse_row(
                    cells,
                    category
                )

                if item:
                    results.append(item)

        return results



    def _parse_row(
        self,
        cells,
        category
    ):

        if len(cells) < 2:
            return None


        test_name = cells[0]


        if not self._valid_test_name(test_name):
            return None


        result = None
        flag = None
        unit = None
        reference = None


        for cell in cells[1:]:

            flag_value = self.extract_flag(cell)

            if flag_value:
                flag = flag_value
                continue


            if self.is_number(cell):

                result = cell
                continue


            if self.is_unit(cell):

                unit = cell
                continue


            if self.is_reference(cell):

                reference = cell



        if result is None:
            return None


        return {
            "testName": test_name,
            "result": result,
            "flag": flag,
            "unit": unit,
            "reference": reference,
            "category": category
        }



    def extract_flag(self,text):

        words = text.lower().split()

        for word in words:

            clean = re.sub(
                r"[^a-z]",
                "",
                word
            )

            if clean in self.FLAGS:
                return word.capitalize()

        return None



    def is_number(self,text):

        text=text.replace(",","")

        return bool(
            re.match(
                r"^[+-]?\d+(\.\d+)?$",
                text
            )
        )



    def is_unit(self,text):

        t=text.lower()

        return (
            "/" in t
            or t in {
                "%",
                "fl",
                "pg"
            }
        )



    def is_reference(self,text):

        return bool(
            re.search(
                r"\d|-|<|>",
                text
            )
        )



    def _valid_test_name(self,text):

        if len(text)<2:
            return False


        bad=[
            "[",
            "]",
            "*",
            "pattern",
            "clinical",
            "information",
            "consideration"
        ]

        low=text.lower()

        for b in bad:
            if b in low:
                return False


        return True