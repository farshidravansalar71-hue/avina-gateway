import base64
import json
import logging

from openai import OpenAI

from app.core.settings import settings


logger = logging.getLogger(__name__)


class GPTClient:
    """
    AVINA GPT Vision Extractor

    Flow:

    Image
      ↓
    GPT Vision
      ↓
    Raw Lab JSON
    """


    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None
    ):

        self.client = OpenAI(
            api_key=(
                api_key
                or settings.OPENAI_API_KEY
            ),

            base_url=settings.OPENAI_BASE_URL
        )


        self.model = (
            model
            or settings.OPENAI_MODEL
        )



    def extract_lab(
        self,
        image_path: str
    ) -> dict:


        with open(
            image_path,
            "rb"
        ) as file:

            image_base64 = base64.b64encode(
                file.read()
            ).decode()



        prompt = """
این تصویر یک برگه آزمایش پزشکی است.

فقط اطلاعات خام آزمایش را استخراج کن.

خروجی فقط JSON معتبر باشد.

ساختار:

{
 "tests":[
  {
   "name":"",
   "value":"",
   "unit":"",
   "reference":"",
   "flag":""
  }
 ]
}


قوانین:

- فقط استخراج انجام بده.
- تحلیل پزشکی انجام نده.
- مقدار حدس نزن.
- ردیف‌های جدول را جدا نگه دار.
- نام بیمار، پزشک و اطلاعات شخصی حذف شود.
- H,L,HH,LL,* فقط در flag قرار بگیرند.
- داخل value نباشند.
- Markdown استفاده نکن.
"""



        response = (
            self.client
            .chat
            .completions
            .create(

                model=self.model,

                temperature=0,

                messages=[

                    {
                        "role": "user",

                        "content":[

                            {
                                "type":"text",
                                "text":prompt
                            },

                            {
                                "type":"image_url",

                                "image_url":{

                                    "url":
                                    f"data:image/jpeg;base64,{image_base64}"

                                }
                            }
                        ]
                    }
                ]
            )
        )



        if response.usage:

            logger.info(
                f"GPT tokens: {response.usage.total_tokens}"
            )



        content = (
            response
            .choices[0]
            .message
            .content
        )


        return self._parse_json(
            content
        )



    def _parse_json(
        self,
        text: str
    ) -> dict:


        text = (
            text
            .strip()
            .replace(
                "```json",
                ""
            )
            .replace(
                "```",
                ""
            )
            .strip()
        )


        start = text.find("{")
        end = text.rfind("}")


        if start != -1 and end != -1:

            text = text[
                start:end + 1
            ]


        return json.loads(
            text
        )