from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Finding:
    test_name: str
    value: str
    status: str
    explanation: str


@dataclass
class AttentionItem:
    title: str
    description: str
    priority: str


@dataclass
class ChartItem:
    test_name: str
    value: str
    unit: str


@dataclass
class HealthScore:
    score: int
    label: str
    description: str


@dataclass
class OverallStatus:
    status: str
    title: str
    description: str


@dataclass
class AIAnalysisResult:
    health_score: HealthScore

    overall_status: OverallStatus

    important_findings: List[Finding]

    attention_items: List[AttentionItem]

    recommendations: List[str]

    chart_data: List[ChartItem]