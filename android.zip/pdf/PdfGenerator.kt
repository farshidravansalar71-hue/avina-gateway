package com.avina.health.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.avina.health.R
import com.avina.health.network.AvinaReportDto
import com.avina.health.network.LabResultDto
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import android.graphics.BitmapFactory

/**
 * -----------------------------------------------------------------------
 * هر خط با Canvas خود اندروید (android.graphics) رسم می‌شه — همون موتور
 * رندری که Compose هم استفاده می‌کنه، پس فارسی بی‌نقص نشون داده می‌شه.
 * هر صفحه یک Bitmap می‌شه و آن Bitmap داخل PDF جاسازی می‌شه. تریدآف:
 * متن PDF قابل کپی/جستجو نیست (چون تصویره)، ولی همیشه درست نمایش
 * داده می‌شه.
 *
 * تصمیم‌های محصولی این نسخه:
 * - امتیاز سلامت فقط برای Premium نمایش داده می‌شود؛ برای Free کلاً
 *   حذف می‌شود (نه فقط عدد، کل بخش).
 * - نتایج آزمایش به‌صورت جدول واقعی (ستون‌بندی‌شده) نشان داده می‌شود،
 *   نه بلوک‌های پشت‌سرهم. توضیح آموزشی هر آزمایش (که معمولاً یک
 *   پاراگراف است) به‌خاطر طول متغیرش داخل جدول نمی‌گنجد، پس زیر همان
 *   ردیف، تمام‌عرض و با رنگ کم‌رنگ‌تر نوشته می‌شود.
 * -----------------------------------------------------------------------
 */
object PdfGenerator {

    private const val DPI = 150f
    private const val SCALE = DPI / 72f

    private val PAGE_WIDTH_PT = PDRectangle.A4.width
    private val PAGE_HEIGHT_PT = PDRectangle.A4.height
    private val PAGE_WIDTH_PX = (PAGE_WIDTH_PT * SCALE).roundToInt()
    private val PAGE_HEIGHT_PX = (PAGE_HEIGHT_PT * SCALE).roundToInt()

    private const val MARGIN_PT = 40f
    private const val LINE_HEIGHT_PT = 20f
    private val MARGIN_PX = MARGIN_PT * SCALE
    private val LINE_HEIGHT_PX = LINE_HEIGHT_PT * SCALE

    // ستون‌های جدول نتایج، از راست به چپ (نسبت از عرض قابل‌استفاده‌ی صفحه)
    private val COL_PERSIAN_NAME = 0.24f
    private val COL_ENGLISH_NAME = 0.16f
    private val COL_RESULT = 0.16f
    private val COL_REFERENCE = 0.26f
    private val COL_STATUS = 0.18f

    private lateinit var regularTypeface: Typeface
    private lateinit var boldTypeface: Typeface

    fun init(context: Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    /**
     * ساخت PDF گزارش آزمایش.
     * @param isPremium اگر true باشد، امتیاز سلامت + تفسیر/توصیه/نمودار هم اضافه می‌شود.
     * @return مسیر فایل PDF ساخته‌شده روی دیسک
     */
    fun generateReport(
        context: Context,
        report: AvinaReportDto,
        userName: String,
        isPremium: Boolean
    ): File {

        regularTypeface = ResourcesCompat.getFont(context, R.font.vazirmatn_regular)
            ?: Typeface.DEFAULT
        boldTypeface = ResourcesCompat.getFont(context, R.font.vazirmatn_bold)
            ?: Typeface.DEFAULT_BOLD

        val document = PDDocument()
        val painter = PagePainter(
            document,
            regularTypeface,
            boldTypeface,
            context,
            userName
        )

        // ===== امتیاز سلامت — فقط Premium =====
        if (isPremium) {
            val healthScore = report.health_summary?.health_score
            painter.writeLine(
                "امتیاز سلامت: ${healthScore?.score ?: 0} از ۱۰۰ (${healthScore?.label ?: ""})",
                boldTypeface, 14f
            )
            painter.writeSpacer(15f)
        }

// ===== نتایج آزمایش =====
        painter.writeLine("نتایج آزمایش", boldTypeface, 15f)
        painter.writeSpacer(8f)

        for (result in report.lab_results) {
            painter.drawLabCard(result)
        }

        // ===== محتوای پرمیوم =====
        if (isPremium) {

            if (report.important_findings.isNotEmpty()) {
                painter.writeSpacer(15f)
                painter.writeLine("تحلیل هوشمند و موارد نیازمند توجه", boldTypeface, 15f)
                painter.writeSpacer(8f)

                for (finding in report.important_findings) {
                    val title = finding.test_name.ifBlank { finding.title }
                    painter.writeLine("• $title", boldTypeface, 12f)
                    finding.description?.takeIf { it.isNotBlank() }?.let { desc ->
                        painter.writeWrapped(desc, regularTypeface, 11f)
                    }
                    painter.writeSpacer(6f)
                }
            }

            if (report.smart_recommendations.isNotEmpty()) {
                painter.writeSpacer(10f)
                painter.writeLine("پیشنهادهای هوشمند", boldTypeface, 15f)
                painter.writeSpacer(8f)

                for (rec in report.smart_recommendations) {
                    painter.writeLine("• ${rec.title}", boldTypeface, 12f)
                    if (rec.description.isNotBlank()) {
                        painter.writeWrapped(rec.description, regularTypeface, 11f)
                    }
                    painter.writeSpacer(6f)
                }
            }

            if (report.charts.available_tests.isNotEmpty()) {
                painter.writeSpacer(10f)
                painter.writeLine("روند شاخص‌ها", boldTypeface, 15f)
                painter.writeSpacer(8f)

                for (chart in report.charts.available_tests) {
                    painter.writeLine(
                        "${chart.test_name}: ${chart.value ?: "-"} ${chart.unit ?: ""}",
                        regularTypeface, 11f
                    )
                }
            }

        }
        else {
        // ===== بنر تبلیغاتی برای کاربر رایگان =====

        painter.writeSpacer(25f)

        painter.writeLine(
            "این گزارش فقط خلاصه نتایج است.",
            boldTypeface,
            13f,
            Color.rgb(70, 70, 70)
        )

        painter.writeSpacer(8f)

        painter.writeLine(
            "برای دریافت تحلیل هوشمند آوین طب، روند تغییرات و",
            regularTypeface,
            11f,
            Color.rgb(100, 100, 100)
        )

        painter.writeLine(
            "پیشنهادهای شخصی‌سازی‌شده، به Avina Premium ارتقا دهید.",
            regularTypeface,
            11f,
            Color.rgb(100, 100, 100)
        )
    }

    // ===== Disclaimer پزشکی =====

    painter.writeSpacer(25f)

    painter.writeWrapped(
    "این گزارش جایگزین تشخیص پزشک نیست و صرفاً برای نمایش اطلاعات آزمایش تهیه شده است.",
    regularTypeface,
    10f,
    Color.rgb(110, 110, 110)
    )

        painter.finish()

        // ===== ذخیره فایل =====
        val outputDir = File(context.getExternalFilesDir(null), "reports")
        if (!outputDir.exists()) outputDir.mkdirs()

        val fileName = "avina_report_${System.currentTimeMillis()}.pdf"
        val outputFile = File(outputDir, fileName)

        document.save(FileOutputStream(outputFile))
        document.close()

        return outputFile
    }

    /**
     * هر صفحه رو با Canvas اندروید رسم می‌کنه و وقتی جا تموم بشه، آن
     * صفحه را به‌صورت تصویر داخل PDF جاسازی و صفحه‌ی خالی جدید می‌سازد.
     */
    private class PagePainter(
        private val document: PDDocument,
        private val regularTypeface: Typeface,
        private val boldTypeface: Typeface,
        private val context: Context,
        private val userName: String
    ) {
        private var bitmap = createBlankPage()
        private var canvas = Canvas(bitmap)
        private var yPx = MARGIN_PX
        private var pageNumber = 1
        init {
            drawHeader()
        }


        private fun createBlankPage(): Bitmap {

            val bmp = Bitmap.createBitmap(
                PAGE_WIDTH_PX,
                PAGE_HEIGHT_PX,
                Bitmap.Config.ARGB_8888
            )

            val canvas = Canvas(bmp)

            canvas.drawColor(Color.WHITE)

            return bmp
        }
        private fun drawHeader() {

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(40, 40, 40)
                textSize = 18f * SCALE
                typeface = boldTypeface
                textAlign = Paint.Align.CENTER
            }
            val headerLogo = BitmapFactory.decodeResource(
                context.resources,
                R.drawable.logo
            )

            headerLogo?.let {
                val logoSize = (60 * SCALE).toInt()

                val scaledLogo = Bitmap.createScaledBitmap(
                    it,
                    logoSize,
                    logoSize,
                    true
                )

                val logoPaint = Paint().apply {
                    alpha = 420
                }

                canvas.drawBitmap(
                    scaledLogo,
                    PAGE_WIDTH_PX / 2f - 290f,
                    yPx - 50f,
                    logoPaint
                )
            }
            canvas.drawText(
                "گزارش سلامت آوین طب",
                PAGE_WIDTH_PX / 2f,
                yPx + 18f * SCALE,
                paint
            )


            val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(60,60,60)
                textSize = 12f * SCALE
                typeface = regularTypeface
                textAlign = Paint.Align.RIGHT
            }


            canvas.drawText(
                ":بیمار $userName",
                PAGE_WIDTH_PX - MARGIN_PX,
                yPx + 45f * SCALE,
                infoPaint
            )


            canvas.drawText(
                "تاریخ: ${SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale("fa")).format(Date())}",
                PAGE_WIDTH_PX - MARGIN_PX,
                yPx + 65f * SCALE,
                infoPaint
            )


            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.LTGRAY
                strokeWidth = 2f
            }

            canvas.drawLine(
                MARGIN_PX,
                yPx + 90f* SCALE,
                PAGE_WIDTH_PX - MARGIN_PX,
                yPx + 90f* SCALE,
                linePaint
            )


            yPx += 120f* SCALE
        }
        fun yPosition(): Float = yPx

        /** اگه فضای لازم (بر حسب px) نمونده، صفحه‌ی فعلی رو finalize و یکی جدید می‌سازه. */
        fun ensureSpace(neededPx: Float) {
            if (yPx + neededPx > PAGE_HEIGHT_PX - MARGIN_PX) {
                flushPage()
            }
        }

        fun writeLine(text: String, typeface: Typeface, sizePt: Float, colorInt: Int = Color.BLACK) {
            ensureSpace(LINE_HEIGHT_PX)
            val paint = makePaint(typeface, sizePt, colorInt)
            canvas.drawText(text, PAGE_WIDTH_PX - MARGIN_PX, yPx + sizePt * SCALE, paint)
            yPx += LINE_HEIGHT_PX
        }

        fun writeWrapped(text: String, typeface: Typeface, sizePt: Float, colorInt: Int = Color.BLACK) {
            val paint = makePaint(typeface, sizePt, colorInt)
            val maxWidthPx = PAGE_WIDTH_PX - 2 * MARGIN_PX
            for (line in wrapText(text, paint, maxWidthPx)) {
                ensureSpace(LINE_HEIGHT_PX)
                canvas.drawText(line, PAGE_WIDTH_PX - MARGIN_PX, yPx + sizePt * SCALE, paint)
                yPx += LINE_HEIGHT_PX
            }
        }

        fun writeSpacer(heightPt: Float) {
            yPx += heightPt * SCALE
        }
        fun drawLabCard(result: LabResultDto) {

            ensureSpace(LINE_HEIGHT_PX * 8)

            // خط جداکننده بالای کارت
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.LTGRAY
                strokeWidth = 2f
            }

            canvas.drawLine(
                MARGIN_PX,
                yPx,
                PAGE_WIDTH_PX - MARGIN_PX,
                yPx,
                linePaint
            )

            yPx += LINE_HEIGHT_PX

            writeLine(
                result.name,
                boldTypeface,
                13f
            )

            result.persian_name
                ?.takeIf { it.isNotBlank() }
                ?.let {
                    writeLine(
                        "نام فارسی: $it",
                        regularTypeface,
                        11f,
                        Color.rgb(60, 60, 60)
                    )
                }

            writeLine(
                "نتیجه: ${result.value ?: "-"} ${result.unit ?: ""}",
                boldTypeface,
                12f
            )

            result.reference
                ?.takeIf { it.isNotBlank() }
                ?.let {
                    writeLine(
                        "محدوده مرجع: $it",
                        regularTypeface,
                        10f,
                        Color.rgb(60, 60, 60)
                    )
                }

            val flag = result.flag?.uppercase()

            val statusText = when (flag) {
                "H", "HIGH" -> "بالا"
                "L", "LOW" -> "پایین"
                "NORMAL", "N" -> "طبیعی"
                else -> "طبیعی"
            }

            val statusColor = when (flag) {
                "H", "HIGH" -> Color.rgb(200, 50, 50)
                "L", "LOW" -> Color.rgb(200, 150, 0)
                else -> Color.rgb(50, 150, 50)
            }

            writeLine(
                "وضعیت: $statusText",
                boldTypeface,
                10f,
                statusColor
            )
            result.description
                ?.takeIf { it.isNotBlank() }
                ?.let {
                    writeWrapped(
                        "توضیح: $it",
                        regularTypeface,
                        10f,
                        Color.rgb(60, 60, 60)
                    )
                }

            yPx += LINE_HEIGHT_PX
        }

        /**
         * یک ردیف جدول رو راست‌به‌چپ می‌کشه — cells[0] راست‌ترین ستونه.
         * هر سلول تک‌خطیه (بدون wrap)؛ اگه متن از عرض ستون بلندتر بود،
         * با measureText کوچیک‌تر می‌شه تا جا بشه (بدون افتادن به خط بعد).
         */
        fun drawRow(
            cells: List<String>,
            colWidthsPx: FloatArray,
            typeface: Typeface,
            sizePt: Float,
            textColor: Int,
            bgColor: Int?
        ) {
            ensureSpace(LINE_HEIGHT_PX)

            bgColor?.let {
                val bgPaint = Paint().apply { color = it }
                canvas.drawRect(
                    MARGIN_PX, yPx - 2f,
                    PAGE_WIDTH_PX - MARGIN_PX, yPx + LINE_HEIGHT_PX - 2f,
                    bgPaint
                )
            }

            var xRight = PAGE_WIDTH_PX - MARGIN_PX
            for (i in cells.indices) {
                val paint = makePaint(typeface, sizePt, textColor)
                val colWidth = colWidthsPx[i]
                val text = fitTextToWidth(cells[i], paint, colWidth - 6f)
                canvas.drawText(text, xRight - 3f, yPx + sizePt * SCALE, paint)
                xRight -= colWidth
            }

            yPx += LINE_HEIGHT_PX
        }

        fun finish() {
            flushPage()
        }

        private fun flushPage() {
            val pagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.GRAY
                textSize = 10f * SCALE
                typeface = regularTypeface
                textAlign = Paint.Align.CENTER
            }

            canvas.drawText(
                "صفحه $pageNumber",
                PAGE_WIDTH_PX / 2f,
                PAGE_HEIGHT_PX - 25f * SCALE,
                pagePaint
            )
            val image = LosslessFactory.createFromImage(document, bitmap)
            val page = PDPage(PDRectangle.A4)
            document.addPage(page)
            val stream = PDPageContentStream(document, page)
            stream.drawImage(image, 0f, 0f, PAGE_WIDTH_PT, PAGE_HEIGHT_PT)
            stream.close()
            pageNumber++

            bitmap = createBlankPage()
            canvas = Canvas(bitmap)
            yPx = MARGIN_PX
            drawHeader()
        }

        private fun makePaint(typeface: Typeface, sizePt: Float, colorInt: Int): Paint {
            return Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.typeface = typeface
                textSize = sizePt * SCALE
                color = colorInt
                textAlign = Paint.Align.RIGHT
            }
        }

        /** اگه متن از عرض ستون بلندتر بود، با "…" کوتاهش می‌کنه تا از ستون بیرون نزنه. */
        private fun fitTextToWidth(text: String, paint: Paint, maxWidthPx: Float): String {
            if (paint.measureText(text) <= maxWidthPx) return text
            var truncated = text
            while (truncated.isNotEmpty() && paint.measureText("$truncated…") > maxWidthPx) {
                truncated = truncated.dropLast(1)
            }
            return "$truncated…"
        }

        private fun wrapText(text: String, paint: Paint, maxWidthPx: Float): List<String> {
            val words = text.split(" ")
            val lines = mutableListOf<String>()
            var current = StringBuilder()
            for (word in words) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) > maxWidthPx && current.isNotEmpty()) {
                    lines.add(current.toString())
                    current = StringBuilder(word)
                } else {
                    current = StringBuilder(candidate)
                }
            }
            if (current.isNotEmpty()) lines.add(current.toString())
            return lines
        }
    }
}