package com.avina.health.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.avina.health.R

val VazirFont = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_bold, FontWeight.Bold)
)

// ۱. تعریف کلاس رنگ‌های اختصاصی آوین
data class AvinaColors(
    val pageBackground: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val lightBlue: Color,
    val profileBlue: Color,
    val cardBackground: Color
)

// ۲. رنگ‌های حالت روشن
private val LightAvinaColors = AvinaColors(
    pageBackground = Color(0xFFF7F9FD),
    textPrimary = Color(0xFF14213D),
    textSecondary = Color(0xFF7B8498),
    lightBlue = Color(0xFFEFF4FF),
    profileBlue = Color(0xFF3978E8),
    cardBackground = Color.White
)

// ۳. رنگ‌های حالت تاریک (دارک‌مود یکجا و تمیز)
private val DarkAvinaColors = AvinaColors(
    pageBackground = Color(0xFF111827),
    textPrimary = Color(0xFFF3F4F6),
    textSecondary = Color(0xFF9CA3AF),
    lightBlue = Color(0xFF374151),
    profileBlue = Color(0xFF5A91F5),
    cardBackground = Color(0xFF1F2937)
)

val LocalAvinaColors = compositionLocalOf { LightAvinaColors }

// میانبر راحت برای صدا زدن رنگ‌ها توی صفحات
object AppTheme {
    val colors: AvinaColors
        @Composable
        get() = LocalAvinaColors.current
}

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

@Composable
fun AVINATheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    // انتخاب پالت رنگ اختصاصی بر اساس دارک یا لایت بودن
    val avinaColors = if (darkTheme) DarkAvinaColors else LightAvinaColors

    CompositionLocalProvider(LocalAvinaColors provides avinaColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}