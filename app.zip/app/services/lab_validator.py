import logging


logger = logging.getLogger(__name__)





# =====================================================
# ALLOWED VALUES
# =====================================================


ALLOWED_FINDING_STATUS = {

    "high",
    "low",
    "critical",
    "positive",
    "negative",
    "warning"

}



ALLOWED_OVERALL_STATUS = {

    "normal",
    "warning",
    "critical"

}



ALLOWED_PRIORITIES = {

    "low",
    "medium",
    "high"

}







# =====================================================
# CLEAN STRING
# =====================================================


def clean_string(value):

    if value is None:

        return ""


    return str(value).strip()







# =====================================================
# VALIDATE GEMINI ANALYSIS
# =====================================================


def validate_gemini_analysis(
    clean_lab_json,
    analysis_json
):

    print(
        "\n========== SERVER VALIDATION ==========\n"
    )



    if not isinstance(
        analysis_json,
        dict
    ):

        raise ValueError(
            "Gemini analysis JSON معتبر نیست"
        )





    # =================================================
    # SOURCE LAB DATA
    # =================================================


    source = {}



    for test in clean_lab_json.get(
        "tests",
        []
    ):


        if not isinstance(
            test,
            dict
        ):

            continue



        name = clean_string(
            test.get(
                "name",
                ""
            )
        )


        if name:

            source[name] = test






    # =================================================
    # VALIDATE IMPORTANT FINDINGS
    # =================================================


    validated_findings = []



    findings = analysis_json.get(
        "important_findings",
        []
    )



    if isinstance(
        findings,
        list
    ):



        for item in findings:



            if not isinstance(
                item,
                dict
            ):

                continue




            test_name = clean_string(
                item.get(
                    "test_name",
                    ""
                )
            )



            value = clean_string(
                item.get(
                    "value",
                    ""
                )
            )




            # Gemini اجازه ساخت آزمایش ندارد

            if test_name not in source:


                logger.warning(
                    f"Rejected finding: {test_name}"
                )


                continue





            # مقدار نباید تغییر کند

            if value != clean_string(
                source[test_name].get(
                    "value",
                    ""
                )
            ):


                logger.warning(
                    f"Value mismatch: {test_name}"
                )


                continue






            status = clean_string(
                item.get(
                    "status",
                    ""
                )
            ).lower()



            if status not in ALLOWED_FINDING_STATUS:

                status = "warning"






            validated_findings.append({


                "title": clean_string(
                    item.get(
                        "title",
                        test_name
                    )
                ),



                "test_name": test_name,



                "value": value,



                "status": status,



                "description": clean_string(
                    item.get(
                        "explanation",
                        item.get(
                            "description",
                            ""
                        )
                    )
                )


            })









    # =================================================
    # HEALTH SCORE
    # =================================================


    health_score = analysis_json.get(
        "health_score",
        {}
    )



    if not isinstance(
        health_score,
        dict
    ):

        health_score = {}




    try:

        score = int(
            health_score.get(
                "score",
                0
            )
        )


    except (
        ValueError,
        TypeError
    ):

        score = 0





    score = max(
        0,
        min(
            score,
            100
        )
    )



    health_score["score"] = score







    # =================================================
    # OVERALL STATUS
    # =================================================


    overall_status = analysis_json.get(
        "overall_status",
        {}
    )



    if not isinstance(
        overall_status,
        dict
    ):

        overall_status = {}





    status = clean_string(
        overall_status.get(
            "status",
            ""
        )
    ).lower()



    if status not in ALLOWED_OVERALL_STATUS:

        status = "warning"



    overall_status["status"] = status







    # =================================================
    # SMART RECOMMENDATIONS
    # =================================================


    smart_recommendations = []



    recommendations = analysis_json.get(
        "recommendations",
        []
    )



    if isinstance(
        recommendations,
        list
    ):



        for item in recommendations:



            if isinstance(
                item,
                str
            ):



                smart_recommendations.append({


                    "title": item,


                    "description": "",


                    "priority": "medium"


                })





            elif isinstance(
                item,
                dict
            ):



                priority = clean_string(
                    item.get(
                        "priority",
                        "medium"
                    )
                ).lower()



                if priority not in ALLOWED_PRIORITIES:

                    priority = "medium"




                smart_recommendations.append({


                    "title": clean_string(
                        item.get(
                            "title",
                            ""
                        )
                    ),



                    "description": clean_string(
                        item.get(
                            "description",
                            ""
                        )
                    ),



                    "priority": priority


                })








    # =================================================
    # FINAL VALIDATED DATA
    # =================================================


    return {


        "health_score": health_score,



        "overall_status": overall_status,



        "important_findings": validated_findings,



        "smart_recommendations": smart_recommendations,



        "lab_results": clean_lab_json.get(
            "tests",
            []
        )

    }