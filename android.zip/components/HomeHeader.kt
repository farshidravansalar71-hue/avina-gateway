package com.avina.health.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.avina.health.ui.theme.AppTheme

@Composable
fun HomeHeader(
    userName: String,
    profileImageUri: String?,
    hasUnreadNotifications: Boolean = true,
    onNotificationClick: () -> Unit = {},
    onProfileClick: () -> Unit = {}
) {
    // قفل کردن جهت هدر روی Ltr برای اینکه ترتیب دستیِ ما به هم نخورد
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // ۱. بخش چپ: آیکون‌ها (پروفایل و زنگوله)
            // استفاده از wrapContentWidth برای جلوگیری از فشرده شدن آیکون‌ها
            Row(
                modifier = Modifier.wrapContentWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // آیکون پروفایل
                HeaderCircleIcon(
                    onClick = onProfileClick,
                    content = {
                        if (!profileImageUri.isNullOrEmpty()) {
                            AsyncImage(
                                model = Uri.parse(profileImageUri),
                                contentDescription = "تصویر پروفایل",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.PersonOutline,
                                contentDescription = "پروفایل",
                                tint = AppTheme.colors.textPrimary,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                )

                // آیکون زنگوله با قابلیت نمایش بج اعلان خوانده نشده
                HeaderCircleIcon(
                    onClick = onNotificationClick,
                    content = {
                        Box(
                            modifier = Modifier.size(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = "اعلان‌ها",
                                tint = AppTheme.colors.textPrimary,
                                modifier = Modifier.size(21.dp)
                            )

                            // نمایش نقطه قرمز رنگ
                            if (hasUnreadNotifications) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .align(Alignment.TopEnd)
                                        .offset(x = 2.dp, y = (-2.dp))
                                        .background(Color(0xFFFF5252), CircleShape)
                                )
                            }
                        }
                    }
                )
            }

            // ۲. بخش راست: متون سلام (کاملاً راست‌چین)
            // استفاده از weight(1f) برای اشغال فضای باقی‌مانده و جلوگیری از بیرون راندن آیکون‌ها
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 12.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "سلام، $userName",
                    color = AppTheme.colors.textPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.End,
                    maxLines = 1 // جلوگیری از چند خطی شدن و به هم ریختن UI
                )

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "امروز وضعیت سلامتت رو بررسی کن",
                    color = AppTheme.colors.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.End,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun HeaderCircleIcon(
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .shadow(elevation = 4.dp, shape = CircleShape, clip = false)
            .clip(CircleShape)
            .background(AppTheme.colors.cardBackground)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
