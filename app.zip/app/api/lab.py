from pathlib import Path
from uuid import uuid4
import re
import json
import logging
import time



from fastapi import (
    APIRouter,
    File,
    HTTPException,
    UploadFile,
    Header,
    Depends,
)


from sqlalchemy.orm import Session


from app.models.lab_models import (
    LabAnalysisResponse,
    LabReportSummary,
    LabReportListResponse,
)


from app.database.session import get_db
from app.database import crud


from app.pipeline.lab_analysis_pipeline import LabAnalysisPipeline
from app.services.report_access import build_report_for_user

from app.core.settings import settings

from app.auth.security import validate_request_signature



logger = logging.getLogger(__name__)




router = APIRouter(
    prefix="/api/v1/lab",
    tags=["Lab"]
)





BASE_UPLOAD_DIR = Path(
    "uploads/users"
)


BASE_UPLOAD_DIR.mkdir(
    parents=True,
    exist_ok=True
)





ALLOWED_CONTENT_TYPES = {

    "image/jpeg",
    "image/png",
    "image/webp",

}





MAX_FILE_SIZE = (

    settings.MAX_IMAGE_SIZE_MB
    *
    1024
    *
    1024

)





DEVICE_ID_PATTERN = re.compile(
    r"^dev_[a-f0-9]{32}$"
)





pipeline = LabAnalysisPipeline()






@router.post(
    "/analyze",
    response_model=LabAnalysisResponse,
)
async def analyze_lab_image(

    image: UploadFile = File(...),

    x_device_id: str | None = Header(None),
    x_timestamp: str | None = Header(None),
    x_signature: str | None = Header(None),

    db: Session = Depends(get_db),

):


    start_time = time.time()



    logger.info(
        f"Analysis started device={x_device_id}"
    )





    # =========================
    # 1. Device ID Format Check
    # =========================


    if not x_device_id or not DEVICE_ID_PATTERN.match(
        x_device_id
    ):


        raise HTTPException(

            status_code=400,

            detail="شناسه دستگاه نامعتبر است."

        )





    # =========================
    # 2 & 3. Timestamp + HMAC Signature Check
    # =========================


    is_valid, error_message = validate_request_signature(
        device_id=x_device_id,
        timestamp=x_timestamp,
        signature=x_signature,
        secret=settings.HMAC_SECRET_KEY,
    )

    if not is_valid:

        raise HTTPException(

            status_code=401,

            detail=error_message

        )





    # =========================
    # User / Device
    # =========================


    user = crud.get_user_by_device_id(

        db,

        x_device_id

    )



    if user:


        device = crud.get_device(

            db,

            x_device_id

        )


        crud.update_device_seen(

            db,

            device

        )



    else:


        user = crud.create_user(

            db

        )



        device = crud.create_device(

            db=db,

            user_id=user.id,

            device_id=x_device_id

        )










    # =========================
    # Image Validation
    # =========================


    if image.content_type not in ALLOWED_CONTENT_TYPES:


        raise HTTPException(

            status_code=400,

            detail="فرمت تصویر پشتیبانی نمی‌شود."

        )





    content = await image.read()





    if not content:


        raise HTTPException(

            status_code=400,

            detail="فایل تصویر خالی است."

        )





    if len(content) > MAX_FILE_SIZE:


        raise HTTPException(

            status_code=413,

            detail="حجم تصویر بیشتر از حد مجاز است."

        )










    # =========================
    # Usage Check
    # =========================


    usage = crud.get_device_usage(

        db,

        device.id

    )





    if not usage:


        usage = crud.create_device_usage(

            db,

            device.id

        )








    if not user.is_premium:


        if not crud.can_use_free_analysis(

            usage

        ):


            raise HTTPException(

                status_code=403,

                detail="سهمیه رایگان تمام شده است."

            )










    # =========================
    # 5. Save Image
    # =========================


    report_id = (

        f"lab_{uuid4().hex[:12]}"

    )





    user_dir = (

        BASE_UPLOAD_DIR

        /

        user.public_id

        /

        "reports"

    )





    user_dir.mkdir(

        parents=True,

        exist_ok=True

    )







    extension = {


        "image/jpeg": ".jpg",

        "image/png": ".png",

        "image/webp": ".webp",


    }.get(

        image.content_type,

        ".jpg"

    )







    file_path = (

        user_dir

        /

        f"{report_id}{extension}"

    )





    file_path.write_bytes(

        content

    )



    # =========================
    # 6 & 7. AI Pipeline
    # (GPT Vision + Gemini + DB Cache)
    # =========================

    try:


        result = pipeline.run(

            image_path=str(file_path),
            db=db  # ارسال نشست دیتابیس برای بررسی کش و ذخیره تست‌های جدید

        )



    except Exception as e:


        logger.exception(

            "Pipeline failed"

        )


        raise HTTPException(

            status_code=500,

            detail=f"Pipeline error: {str(e)}"

        )










    # =========================
    # Increase Usage
    # only after success
    # =========================


    if not user.is_premium:


        crud.increase_usage(

            db,

            usage

        )










    # =========================
    # Prepare Report JSON
    # New Avina Structure
    # =========================


    report_json = result.get("report", result)



    lab_results_json = result.get(

        "lab_results",

        []

    )











    # =========================
    # Save Report
    # Database
    # =========================


    crud.create_lab_report(

        db=db,

        user_id=user.id,

        report_id=report_id,


        lab_results_json=json.dumps(

            lab_results_json,

            ensure_ascii=False

        ),



        analysis_json=json.dumps(

            report_json,

            ensure_ascii=False

        )

    )





    # =========================
    # Filter Report For API Response
    # =========================


    user_report = build_report_for_user(

        report_json=report_json,

        is_premium=user.is_premium,

    )








    elapsed = (

        time.time()

        -

        start_time

    )





    logger.info(

        f"Analysis completed report={report_id} time={elapsed:.2f}s"

    )


    remaining = max(0, settings.FREE_ANALYSIS_LIMIT - usage.free_analysis_count) if not user.is_premium else None

    return LabAnalysisResponse(

        success=True,

        reportId=report_id,

        report=user_report,

        message="آزمایش با موفقیت تحلیل شد.",

        remainingFreeTests=remaining,

        isPremium=user.is_premium,

    )


# ============================================================
# STATUS ENDPOINT
# ============================================================

@router.get("/status")
async def get_user_status(

    x_device_id: str | None = Header(None),
    x_timestamp: str | None = Header(None),
    x_signature: str | None = Header(None),

    db: Session = Depends(get_db),

):

    if not x_device_id or not DEVICE_ID_PATTERN.match(x_device_id):
        raise HTTPException(
            status_code=400,
            detail="شناسه دستگاه نامعتبر است."
        )

    is_valid, error_message = validate_request_signature(
        device_id=x_device_id,
        timestamp=x_timestamp,
        signature=x_signature,
        secret=settings.HMAC_SECRET_KEY,
    )

    if not is_valid:
        raise HTTPException(
            status_code=401,
            detail=error_message
        )

    user = crud.get_user_by_device_id(db, x_device_id)

    if not user:
        return {
            "isPremium": False,
            "remainingFreeTests": settings.FREE_ANALYSIS_LIMIT,
            "totalFreeTests": settings.FREE_ANALYSIS_LIMIT,
        }

    device = crud.get_device(db, x_device_id)
    usage = crud.get_device_usage(db, device.id)

    remaining = settings.FREE_ANALYSIS_LIMIT
    if usage:
        remaining = max(0, settings.FREE_ANALYSIS_LIMIT - usage.free_analysis_count)

    return {
        "isPremium": user.is_premium,
        "remainingFreeTests": remaining if not user.is_premium else None,
        "totalFreeTests": settings.FREE_ANALYSIS_LIMIT,
    }


# ============================================================
# REPORT HISTORY — LIST
# ============================================================

@router.get("/reports", response_model=LabReportListResponse)
async def list_user_reports(

    x_device_id: str | None = Header(None),
    x_timestamp: str | None = Header(None),
    x_signature: str | None = Header(None),

    db: Session = Depends(get_db),

):

    if not x_device_id or not DEVICE_ID_PATTERN.match(x_device_id):
        raise HTTPException(status_code=400, detail="شناسه دستگاه نامعتبر است.")

    is_valid, error_message = validate_request_signature(
        device_id=x_device_id,
        timestamp=x_timestamp,
        signature=x_signature,
        secret=settings.HMAC_SECRET_KEY,
    )

    if not is_valid:
        raise HTTPException(status_code=401, detail=error_message)

    user = crud.get_user_by_device_id(db, x_device_id)

    if not user:
        return LabReportListResponse(success=True, reports=[])

    reports = crud.get_user_reports(db, user.id)

    summaries: list[LabReportSummary] = []

    for report in reports:

        overall_status_title = None
        tests_count = 0

        try:
            if report.analysis_json:
                parsed = json.loads(report.analysis_json)
                overall_status = parsed.get("health_summary", {}).get("overall_status", {})
                overall_status_title = overall_status.get("title")
        except (ValueError, AttributeError):
            logger.warning(f"Could not parse analysis_json for report={report.report_id}")

        try:
            if report.lab_results_json:
                tests_count = len(json.loads(report.lab_results_json))
        except (ValueError, TypeError):
            logger.warning(f"Could not parse lab_results_json for report={report.report_id}")

        summaries.append(
            LabReportSummary(
                report_id=report.report_id,
                created_at=report.created_at.isoformat(),
                overall_status_title=overall_status_title,
                tests_count=tests_count,
            )
        )

    return LabReportListResponse(success=True, reports=summaries)


# ============================================================
# REPORT HISTORY — SINGLE REPORT
# ============================================================

@router.get("/reports/{report_id}", response_model=LabAnalysisResponse)
async def get_user_report(

    report_id: str,

    x_device_id: str | None = Header(None),
    x_timestamp: str | None = Header(None),
    x_signature: str | None = Header(None),

    db: Session = Depends(get_db),

):

    if not x_device_id or not DEVICE_ID_PATTERN.match(x_device_id):
        raise HTTPException(status_code=400, detail="شناسه دستگاه نامعتبر است.")

    is_valid, error_message = validate_request_signature(
        device_id=x_device_id,
        timestamp=x_timestamp,
        signature=x_signature,
        secret=settings.HMAC_SECRET_KEY,
    )

    if not is_valid:
        raise HTTPException(status_code=401, detail=error_message)

    user = crud.get_user_by_device_id(db, x_device_id)

    if not user:
        raise HTTPException(status_code=404, detail="گزارشی یافت نشد.")

    report = crud.get_lab_report(db, report_id)

    if not report or report.user_id != user.id:
        raise HTTPException(status_code=404, detail="گزارشی یافت نشد.")

    try:
        report_json = json.loads(report.analysis_json) if report.analysis_json else {}
    except ValueError:
        logger.exception(f"Corrupt analysis_json for report={report_id}")
        raise HTTPException(status_code=500, detail="گزارش خراب است.")

    user_report = build_report_for_user(
        report_json=report_json,
        is_premium=user.is_premium,
    )

    return LabAnalysisResponse(
        success=True,
        reportId=report.report_id,
        report=user_report,
        message="گزارش با موفقیت بازیابی شد.",
        remainingFreeTests=None,
        isPremium=user.is_premium,
    )


# ============================================================
# REPORT HISTORY — DELETE
# ============================================================

@router.delete("/reports/{report_id}")
async def delete_user_report(

    report_id: str,

    x_device_id: str | None = Header(None),
    x_timestamp: str | None = Header(None),
    x_signature: str | None = Header(None),

    db: Session = Depends(get_db),

):

    if not x_device_id or not DEVICE_ID_PATTERN.match(x_device_id):
        raise HTTPException(status_code=400, detail="شناسه دستگاه نامعتبر است.")

    is_valid, error_message = validate_request_signature(
        device_id=x_device_id,
        timestamp=x_timestamp,
        signature=x_signature,
        secret=settings.HMAC_SECRET_KEY,
    )

    if not is_valid:
        raise HTTPException(status_code=401, detail=error_message)

    user = crud.get_user_by_device_id(db, x_device_id)

    if not user:
        raise HTTPException(status_code=404, detail="گزارشی یافت نشد.")

    report = crud.get_lab_report(db, report_id)

    if not report or report.user_id != user.id:
        raise HTTPException(status_code=404, detail="گزارشی یافت نشد.")

    crud.delete_lab_report(db, report)

    logger.info(f"Report deleted report={report_id} user={user.public_id}")

    return {"success": True, "message": "گزارش حذف شد."}