// پروفایل اسکرین
package com.avina.health.screen.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.avina.health.data.AppLanguageManager
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import com.avina.health.utils.AppStrings
import kotlinx.coroutines.launch
import java.util.Locale
import com.avina.health.screen.onboarding.NumberWheelPicker

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel = viewModel(),
    userName: String = "کاربر",
    onLogoutClick: () -> Unit = {},
    onSubscriptionClick: () -> Unit = {},
    onManageSubscriptionClick: () -> Unit = {},
    onHistoryClick: () -> Unit = {},
    onSupportClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val languageManager = remember { AppLanguageManager(context) }
    val currentLang by languageManager.currentLanguage.collectAsState(initial = "fa")

    CompositionLocalProvider(
        LocalLayoutDirection provides if (currentLang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl
    ) {
        val profileImageUriString by viewModel.profileImageUri.collectAsState()
        val profileImage = remember(profileImageUriString) { profileImageUriString?.let { Uri.parse(it) } }
        var weight by remember { mutableStateOf("78") }
        var height by remember { mutableStateOf("180") }
        var age by remember { mutableStateOf("34") }
        var showLanguageDialog by remember { mutableStateOf(false) }

        val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let { viewModel.updateProfileImage(it) }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AppTheme.colors.pageBackground)
                .statusBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp)
                    .padding(top = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(105.dp).clickable { galleryLauncher.launch("image/*") }) {
                        Box(modifier = Modifier.size(100.dp).clip(CircleShape).background(AppTheme.colors.cardBackground), contentAlignment = Alignment.Center) {
                            if (profileImage != null) AsyncImage(model = profileImage, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            else Icon(Icons.Default.Person, null, tint = AppTheme.colors.textSecondary, modifier = Modifier.size(48.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(userName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
                        Text(if (currentLang == "en") "Your health is always with you" else "سلامت شما همیشه همراه شماست", fontSize = 12.sp, color = AppTheme.colors.textSecondary)
                    }
                }

                HealthStatusCard(weight, height, age, currentLang, { weight = it }, { height = it }, { age = it })
                PremiumCard(currentLang = currentLang, onClick = onSubscriptionClick)
                ProfileOptionsCard(
                    currentLang = currentLang,
                    onSubscriptionClick = onManageSubscriptionClick,
                    onHistoryClick = onHistoryClick,
                    onSupportClick = onSupportClick,
                    onLanguageClick = { showLanguageDialog = true }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 20.dp, top = 10.dp)
            ) {
                LogoutButton(currentLang, onLogoutClick)
            }
        }

        if (showLanguageDialog) {
            AlertDialog(
                onDismissRequest = { showLanguageDialog = false },
                containerColor = AppTheme.colors.cardBackground,
                shape = RoundedCornerShape(24.dp),
                title = {
                    Text(
                        text = if (currentLang == "en") "Select App Language" else "انتخاب زبان برنامه",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppTheme.colors.textPrimary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                coroutineScope.launch { languageManager.setLanguage("fa"); showLanguageDialog = false }
                            }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = currentLang == "fa", onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "فارسی (آوین طب)", color = AppTheme.colors.textPrimary, fontWeight = FontWeight.Medium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                coroutineScope.launch { languageManager.setLanguage("en"); showLanguageDialog = false }
                            }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = currentLang == "en", onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "English (Avin Med)", color = AppTheme.colors.textPrimary, fontWeight = FontWeight.Medium)
                        }
                    }
                },
                confirmButton = {}
            )
        }
    }
}

@Composable
private fun HealthStatusCard(
    weight: String, height: String, age: String, currentLang: String,
    onWeightChange: (String) -> Unit, onHeightChange: (String) -> Unit, onAgeChange: (String) -> Unit
) {
    // متغیر برای کنترل اینکه کدوم دیالوگ باز بشه
    var activePickerField by remember { mutableStateOf<String?>(null) }

    val bmiValue = remember(weight, height) {
        val w = weight.toFloatOrNull() ?: 78f
        val hCm = height.toFloatOrNull() ?: 180f
        if (hCm > 0f) w / ((hCm / 100f) * (hCm / 100f)) else 24.1f
    }
    val formattedBmi = String.format(Locale.US, "%.1f", bmiValue)
    val bmiStatusText = remember(bmiValue) {
        when {
            bmiValue < 18.5f -> if (currentLang == "en") "Underweight" else "کم‌وزن"
            bmiValue < 25f -> if (currentLang == "en") "Normal" else "نرمال"
            bmiValue < 30f -> if (currentLang == "en") "Overweight" else "اضافه وزن"
            else -> if (currentLang == "en") "Obese" else "چاق"
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = AppTheme.colors.cardBackground,
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Surface(shape = RoundedCornerShape(12.dp), color = PrimaryBlue.copy(alpha = 0.12f)) {
                    Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (currentLang == "en") "Body Fitness" else "وضعیت تناسب اندام", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                    }
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                // اضافه شدن قابلیت کلیک برای وزن
                HealthMetric(
                    modifier = Modifier.weight(1f).clickable { activePickerField = "weight" },
                    title = if (currentLang == "en") "Weight" else "وزن",
                    value = weight, unit = "kg", icon = Icons.Default.MonitorWeight
                )
                MetricDivider()
                // اضافه شدن قابلیت کلیک برای قد
                HealthMetric(
                    modifier = Modifier.weight(1f).clickable { activePickerField = "height" },
                    title = if (currentLang == "en") "Height" else "قد",
                    value = height, unit = "cm", icon = Icons.Default.Height
                )
                MetricDivider()
                // اضافه شدن قابلیت کلیک برای سن
                HealthMetric(
                    modifier = Modifier.weight(1f).clickable { activePickerField = "age" },
                    title = if (currentLang == "en") "Age" else "سن",
                    value = age, unit = if (currentLang == "en") "yrs" else "سال", icon = Icons.Default.Person
                )
                MetricDivider()
                BmiHealthMetric(modifier = Modifier.weight(1f), title = "BMI", value = formattedBmi, statusText = bmiStatusText)
            }
        }
    }

    // دیالوگ‌های انتخاب‌گر که با کلیک روی هر متریک باز میشن
    when (activePickerField) {
        "weight" -> NumberPickerDialog(
            title = if (currentLang == "en") "Select Weight (kg)" else "انتخاب وزن (کیلوگرم)",
            initialValue = weight.toIntOrNull() ?: 78, range = 30..200,
            onDismiss = { activePickerField = null }
        ) { onWeightChange(it.toString()); activePickerField = null }

        "height" -> NumberPickerDialog(
            title = if (currentLang == "en") "Select Height (cm)" else "انتخاب قد (سانتی‌متر)",
            initialValue = height.toIntOrNull() ?: 180, range = 100..230,
            onDismiss = { activePickerField = null }
        ) { onHeightChange(it.toString()); activePickerField = null }

        "age" -> NumberPickerDialog(
            title = if (currentLang == "en") "Select Age" else "انتخاب سن",
            initialValue = age.toIntOrNull() ?: 34, range = 10..120,
            onDismiss = { activePickerField = null }
        ) { onAgeChange(it.toString()); activePickerField = null }
    }
}

// کامپوننت دیالوگ چرخشی اعداد
@Composable
private fun NumberPickerDialog(title: String, initialValue: Int, range: IntRange, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var currentValue by remember { mutableStateOf(initialValue) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AppTheme.colors.cardBackground,
        shape = RoundedCornerShape(24.dp),
        title = { Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        text = {
            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                // فرض بر این است که NumberWheelPicker در پروژه موجود است
                NumberWheelPicker(title = "", value = currentValue, range = range, onValueChange = { currentValue = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(currentValue) },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "تایید", fontSize = 14.sp, color = Color.White)
            }
        }
    )
}

@Composable
private fun HealthMetric(modifier: Modifier = Modifier, title: String, value: String, unit: String, icon: ImageVector) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(modifier = Modifier.size(42.dp), shape = RoundedCornerShape(12.dp), color = PrimaryBlue.copy(alpha = 0.12f)) {
            Box(contentAlignment = Alignment.Center) { Icon(imageVector = icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(22.dp)) }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, fontSize = 12.sp, color = AppTheme.colors.textSecondary)
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
            Spacer(modifier = Modifier.width(2.dp))
            Text(text = unit, fontSize = 9.sp, color = AppTheme.colors.textSecondary, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}

@Composable
private fun BmiHealthMetric(modifier: Modifier = Modifier, title: String, value: String, statusText: String) {
    val (bgColor, textColor) = when (statusText) {
        "کم‌وزن", "Underweight" -> Pair(Color(0xFFFFF8D6), Color(0xFFB38F00))
        "نرمال", "Normal" -> Pair(Color(0xFFA9EBCB), Color(0xFF15966A))
        "اضافه وزن", "Overweight" -> Pair(Color(0xFFFFEAD0), Color(0xFFD36B00))
        else -> Pair(Color(0xFFFFCDD2), Color(0xFFD84B4B))
    }
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(modifier = Modifier.size(42.dp), shape = RoundedCornerShape(12.dp), color = PrimaryBlue.copy(alpha = 0.12f)) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = "BMI", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, fontSize = 12.sp, color = AppTheme.colors.textSecondary)
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
            Spacer(modifier = Modifier.width(2.dp))
            Surface(shape = RoundedCornerShape(6.dp), color = bgColor) {
                Text(text = statusText, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp), fontSize = 8.sp, fontWeight = FontWeight.Bold, color = textColor)
            }
        }
    }
}

@Composable
private fun MetricDivider() {
    Box(
        modifier = Modifier
            .height(84.dp)
            .width(1.dp)
            .background(PrimaryBlue.copy(alpha = 0.15f))
    )
}

@Composable
private fun PremiumCard(currentLang: String, onClick: () -> Unit = {}) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        shadowElevation = 4.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF011640),
                            Color(0xFF0B2D78),
                            Color(0xFF2857C3)
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(60.dp), contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                    Text(
                        text = AppStrings.get("app_name", currentLang) + " Premium",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLang == "en") "Special version for professional health care" else "نسخه ویژه برای مراقبت حرفه‌ای‌تر از سلامت شما",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PremiumFeature(if (currentLang == "en") "AI Smart Analysis" else "تحلیل هوشمند AI")
                        PremiumFeature(if (currentLang == "en") "Lab History" else "تاریخچه آزمایش‌ها")
                        PremiumFeature(if (currentLang == "en") "Chart Trend Analysis" else "تحلیل روند آزمایش‌ها روی نمودار")
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumFeature(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFFFFD700),
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.9f),
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun ProfileOptionsCard(
    currentLang: String,
    onSubscriptionClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSupportClick: () -> Unit,
    onLanguageClick: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = AppTheme.colors.cardBackground, shadowElevation = 1.dp) {
        Column {
            Spacer(modifier = Modifier.height(14.dp))
            ProfileOption(
                icon = Icons.Default.CardMembership,
                title = if (currentLang == "en") "Subscription Management" else "مدیریت اشتراک‌ها",
                subtitle = if (currentLang == "en") "View premium plans" else "مشاهده پلن‌های ویژه پرمیوم",
                currentLang = currentLang,
                onClick = onSubscriptionClick
            )
            ProfileOptionDivider()
            ProfileOption(
                icon = Icons.Default.Description,
                title = AppStrings.get("history_title", currentLang),
                subtitle = if (currentLang == "en") "View all results and reports" else "مشاهده همه نتایج و گزارش‌ها",
                currentLang = currentLang,
                onClick = onHistoryClick
            )
            ProfileOptionDivider()
            ProfileOption(
                icon = Icons.Default.SupportAgent,
                title = if (currentLang == "en") "Support & Help" else "پشتیبانی و راهنما",
                subtitle = if (currentLang == "en") "Contact us for help" else "ارتباط با ما برای دریافت راهنمایی",
                currentLang = currentLang,
                onClick = onSupportClick
            )
            ProfileOptionDivider()
            ProfileOption(
                icon = Icons.Default.Language,
                title = AppStrings.get("language_title", currentLang),
                subtitle = AppStrings.get("language_subtitle", currentLang),
                currentLang = currentLang,
                onClick = onLanguageClick
            )
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
private fun ProfileOption(
    icon: ImageVector, title: String, subtitle: String, currentLang: String,
    onClick: () -> Unit = {}
) {
    Row(modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(modifier = Modifier.size(42.dp), shape = RoundedCornerShape(12.dp), color = PrimaryBlue.copy(alpha = 0.12f)) {
            Box(contentAlignment = Alignment.Center) { Icon(imageVector = icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(22.dp)) }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 11.sp, color = AppTheme.colors.textSecondary)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Icon(imageVector = if (currentLang == "en") Icons.Default.KeyboardArrowRight else Icons.Default.KeyboardArrowLeft, contentDescription = null, tint = AppTheme.colors.textSecondary, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun ProfileOptionDivider() {
    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = PrimaryBlue.copy(alpha = 0.08f))
}

@Composable
private fun LogoutButton(currentLang: String, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(18.dp), color = Color(
        0xFFE3112C
    ), border = BorderStroke(1.dp, Color(0xFFE3112C))) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.ExitToApp, contentDescription = null, tint = Color(
                0xFFCCCCCC
            ), modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = AppStrings.get("logout", currentLang), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(
                0xFFDEDEDE
            )
            )
        }
    }
}