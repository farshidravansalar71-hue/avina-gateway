# =========================================================
# GEMINI MEDICAL TEST SELECTOR
# AVINA HEALTH
# =========================================================


# ---------------------------------------------------------
# HIGH VALUE MEDICAL TESTS
# فقط چیزهایی که واقعا برای AI مهم هستند
# ---------------------------------------------------------

IMPORTANT_KEYWORDS = [

    # Diabetes
    "glucose",
    "fasting blood sugar",
    "fbs",
    "hba1c",
    "a1c",

    # Lipid
    "cholesterol",
    "cholestrol",
    "ldl",
    "hdl",
    "triglyceride",
    "tg",

    # Kidney
    "creatinine",
    "egfr",
    "bun",
    "urea",

    # Liver
    "ast",
    "alt",
    "sgpt",
    "sgot",
    "bilirubin",
    "alkaline phosphatase",
    "alkaline",

    # Thyroid
    "tsh",
    "free t4",
    "ft4",
    "free t3",
    "ft3",

    # Vitamins
    "vitamin d",
    "vit d",
    "b12",
    "ferritin",
    "iron",
    "fe",

    # Inflammation
    "crp",
    "esr",


    # Urine important
    "blood",
    "rbc",
    "wbc",
    "protein",
    "nitrite",
    "bacteria",
    "keton",
    "ketone"

]



# ---------------------------------------------------------
# Tests that usually have low AI value
# ---------------------------------------------------------

IGNORE_KEYWORDS = [

    "color",
    "appearance",
    "appereance",
    "clarity",
    "aspect",

    "ph",
    "specific gravity",

    "pt patient",
    "ptt patient",
    "inr",

    "calcium",
    "phosphorus",

    "wright",
    "agglutination",

    "urobilinogen"

]



# ---------------------------------------------------------
# Abnormal flags
# ---------------------------------------------------------

ABNORMAL_FLAGS = {

    "H",
    "L",
    "HH",
    "LL",
    "*"

}



# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def normalize(text):

    return (
        str(text)
        .lower()
        .replace(".", "")
        .replace("-", " ")
        .replace("_", " ")
        .strip()
    )



def is_numeric_value(value):

    try:

        float(
            str(value)
            .strip()
        )

        return True

    except:

        return False



def is_ignored_test(name):

    name = normalize(name)

    for item in IGNORE_KEYWORDS:

        if item in name:

            return True


    return False




def is_important_test(name):

    name = normalize(name)

    for item in IMPORTANT_KEYWORDS:

        if item in name:

            return True


    return False




def is_positive_value(value):

    value = normalize(value)


    positives = [

        "positive",
        "pos",
        "reactive",
        "detected",
        "+",
        "+1",
        "+2",
        "+3"

    ]


    for p in positives:

        if p in value:

            return True


    return False




def has_abnormal_flag(flag):

    flag = normalize(flag).upper()


    return flag in ABNORMAL_FLAGS




# ---------------------------------------------------------
# MAIN DECISION
# ---------------------------------------------------------

def should_send_to_gemini(test):


    name = test.get(
        "name",
        ""
    )


    value = test.get(
        "value",
        ""
    )


    flag = test.get(
        "flag",
        ""
    )



    if not name:

        return False



    # remove useless
    if is_ignored_test(name):

        return False



    # abnormal always
    if has_abnormal_flag(flag):

        return True



    # important medical test
    if is_important_test(name):

        return True



    # positive urine/infection results
    if is_positive_value(value):

        return True



    return False




# ---------------------------------------------------------
# CREATE GEMINI INPUT
# ---------------------------------------------------------

def select_tests_for_analysis(clean_lab_json):


    selected = []


    for test in clean_lab_json.get(
        "tests",
        []
    ):


        if should_send_to_gemini(test):

            selected.append(
                test
            )



    return {

        "tests": selected

    }