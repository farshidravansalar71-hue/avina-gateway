package com.avina.health.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import kotlin.math.abs

private val GreenImprovement = Color(0xFF059669)

data class ChartData(
    val name: String,
    val unit: String,
    val minVal: Float,
    val maxVal: Float,
    val lastValue: Float,
    val statusText: String,
    val values: List<Float>,
    val dates: List<String>
)

@Composable
fun TrendChartSection(
    modifier: Modifier = Modifier,
    onSeeAllClick: () -> Unit = {}
) {
    val sampleTestData = remember {
        listOf(
            ChartData(
                name = "قند خون",
                unit = "mg/dL",
                minVal = 40f,
                maxVal = 200f,
                lastValue = 92f,
                statusText = "رو به بهبود",
                values = listOf(155f, 130f, 145f, 120f, 92f),
                dates = listOf("خرداد ۱۴۰۲", "مهر ۱۴۰۲", "دی ۱۴۰۳", "فروردین ۱۴۰۴", "مهر ۱۴۰۵")
            ),
            ChartData(
                name = "ویتامین D",
                unit = "ng/mL",
                minVal = 0f,
                maxVal = 60f,
                lastValue = 28f,
                statusText = "افزایش مناسب",
                values = listOf(12f, 16f, 20f, 24f, 28f),
                dates = listOf("آزمایش ۱", "آزمایش ۲", "آزمایش ۳", "آزمایش ۴", "آزمایش ۵")
            ),
            ChartData(
                name = "کلسترول",
                unit = "mg/dL",
                minVal = 100f,
                maxVal = 300f,
                lastValue = 185f,
                statusText = "در محدوده نرمال",
                values = listOf(220f, 210f, 195f, 190f, 185f),
                dates = listOf("2023/01", "2023/06", "2024/02", "2024/09", "2025/03")
            )
        )
    }

    var selectedTest by remember { mutableStateOf(sampleTestData.first()) }
    var expanded by remember { mutableStateOf(false) }

    var selectedPointIndex by remember(selectedTest) { mutableStateOf<Int?>(null) }
    val textMeasurer = rememberTextMeasurer()

    val yLevels = remember(selectedTest) {
        val step = (selectedTest.maxVal - selectedTest.minVal) / 4f
        List(5) { i -> selectedTest.maxVal - (i * step) }
    }

    // رنگ‌ها باید اینجا (تو context کامپوزبل) گرفته بشن، نه داخل Canvas
    val gridLineColor = AppTheme.colors.textSecondary
    val pointBgColor = AppTheme.colors.cardBackground

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PrimaryBlue.copy(alpha = 0.12f),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.ShowChart,
                                    contentDescription = null,
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = "روند تغییرات شاخص‌ها",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppTheme.colors.textPrimary
                        )
                    }

                    Box {
                        Surface(
                            onClick = { expanded = true },
                            shape = RoundedCornerShape(12.dp),
                            color = AppTheme.colors.pageBackground,
                            modifier = Modifier.height(32.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = selectedTest.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AppTheme.colors.textPrimary
                                )
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.background(AppTheme.colors.cardBackground)
                        ) {
                            for (test in sampleTestData) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = test.name,
                                            fontSize = 12.sp,
                                            fontWeight = if (test.name == selectedTest.name) FontWeight.Bold else FontWeight.Normal,
                                            color = if (test.name == selectedTest.name) PrimaryBlue else AppTheme.colors.textPrimary
                                        )
                                    },
                                    onClick = {
                                        selectedTest = test
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    val horizontalPadding = 16.dp

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(125.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(28.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.End
                        ) {
                            for (level in yLevels) {
                                Text(
                                    text = if (level >= 10f) "${level.toInt()}" else String.format("%.1f", level),
                                    fontSize = 9.sp,
                                    color = AppTheme.colors.textSecondary,
                                    maxLines = 1
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Canvas(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .pointerInput(selectedTest) {
                                    detectTapGestures { tapOffset ->
                                        val width = size.width
                                        val padPx = horizontalPadding.toPx()
                                        val usableWidth = width - (2 * padPx)
                                        val count = selectedTest.values.size

                                        if (count > 0) {
                                            val pointsX = List(count) { index ->
                                                if (count > 1) padPx + index * (usableWidth / (count - 1)) else width / 2f
                                            }

                                            val closestIndex = pointsX.indices.minByOrNull { abs(pointsX[it] - tapOffset.x) }

                                            if (closestIndex != null) {
                                                selectedPointIndex = if (selectedPointIndex == closestIndex) null else closestIndex
                                            }
                                        }
                                    }
                                }
                        ) {
                            val width = size.width
                            val height = size.height
                            val padPx = horizontalPadding.toPx()
                            val usableWidth = width - (2 * padPx)

                            val minVal = selectedTest.minVal
                            val maxVal = selectedTest.maxVal

                            for (level in yLevels) {
                                val yPos = height - ((level - minVal) / (maxVal - minVal) * height)
                                drawLine(
                                    color = gridLineColor.copy(alpha = 0.2f),
                                    start = Offset(0f, yPos),
                                    end = Offset(width, yPos),
                                    strokeWidth = 1f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                                )
                            }

                            val points = selectedTest.values.mapIndexed { index, value ->
                                val x = if (selectedTest.values.size > 1) {
                                    padPx + index * (usableWidth / (selectedTest.values.size - 1))
                                } else width / 2f
                                val y = height - ((value - minVal) / (maxVal - minVal) * height)
                                Offset(x, y.coerceIn(0f, height))
                            }

                            if (points.size > 1) {
                                val curvePath = Path().apply {
                                    moveTo(points.first().x, points.first().y)
                                    for (i in 0 until points.size - 1) {
                                        val p1 = points[i]
                                        val p2 = points[i + 1]
                                        val controlPoint1 = Offset(p1.x + (p2.x - p1.x) / 2f, p1.y)
                                        val controlPoint2 = Offset(p1.x + (p2.x - p1.x) / 2f, p2.y)
                                        cubicTo(
                                            controlPoint1.x, controlPoint1.y,
                                            controlPoint2.x, controlPoint2.y,
                                            p2.x, p2.y
                                        )
                                    }
                                }

                                val fillPath = Path().apply {
                                    addPath(curvePath)
                                    lineTo(points.last().x, height)
                                    lineTo(points.first().x, height)
                                    close()
                                }
                                drawPath(
                                    path = fillPath,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(PrimaryBlue.copy(alpha = 0.25f), Color.Transparent)
                                    )
                                )

                                drawPath(
                                    path = curvePath,
                                    color = PrimaryBlue,
                                    style = Stroke(width = 2.5f)
                                )
                            }

                            points.forEachIndexed { index, point ->
                                val isSelected = (index == selectedPointIndex)

                                if (isSelected) {
                                    drawCircle(color = PrimaryBlue.copy(alpha = 0.25f), radius = 12f, center = point)
                                    drawCircle(color = pointBgColor, radius = 6f, center = point)
                                    drawCircle(color = PrimaryBlue, radius = 6f, center = point, style = Stroke(width = 2.5f))

                                    val valStr = if (selectedTest.values[index] % 1f == 0f)
                                        "${selectedTest.values[index].toInt()}"
                                    else
                                        "${selectedTest.values[index]}"
                                    val labelText = "$valStr ${selectedTest.unit}"

                                    val textLayoutResult = textMeasurer.measure(
                                        text = labelText,
                                        style = TextStyle(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )

                                    val bubblePaddingH = 12f
                                    val bubblePaddingV = 6f
                                    val bubbleWidth = textLayoutResult.size.width + (bubblePaddingH * 2)
                                    val bubbleHeight = textLayoutResult.size.height + (bubblePaddingV * 2)

                                    val bubbleX = (point.x - bubbleWidth / 2f).coerceIn(0f, width - bubbleWidth)
                                    val bubbleY = (point.y - bubbleHeight - 10f).coerceAtLeast(0f)

                                    drawRoundRect(
                                        color = PrimaryBlue,
                                        topLeft = Offset(bubbleX, bubbleY),
                                        size = Size(bubbleWidth, bubbleHeight),
                                        cornerRadius = CornerRadius(8f, 8f)
                                    )

                                    drawText(
                                        textLayoutResult = textLayoutResult,
                                        topLeft = Offset(
                                            bubbleX + bubblePaddingH,
                                            bubbleY + bubblePaddingV
                                        )
                                    )
                                } else {
                                    drawCircle(color = pointBgColor, radius = 5f, center = point)
                                    drawCircle(color = PrimaryBlue, radius = 5f, center = point, style = Stroke(width = 2f))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 34.dp + horizontalPadding, end = horizontalPadding)
                            .height(18.dp)
                    ) {
                        val totalWidth = maxWidth
                        val count = selectedTest.dates.size
                        val datesList = selectedTest.dates

                        for (index in datesList.indices) {
                            val date = datesList[index]
                            val fraction = if (count > 1) index.toFloat() / (count - 1) else 0.5f
                            val xOffset = totalWidth * fraction

                            Text(
                                text = date,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = AppTheme.colors.textSecondary,
                                maxLines = 1,
                                modifier = Modifier.layout { measurable, constraints ->
                                    val placeable = measurable.measure(constraints)
                                    layout(placeable.width, placeable.height) {
                                        val x = (xOffset.toPx() - placeable.width / 2f).toInt()
                                        placeable.placeRelative(x, 0)
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = AppTheme.colors.pageBackground
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = PrimaryBlue.copy(alpha = 0.12f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.WaterDrop,
                                            contentDescription = null,
                                            tint = PrimaryBlue,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(
                                        text = "آخرین مقدار",
                                        fontSize = 9.5.sp,
                                        color = AppTheme.colors.textSecondary
                                    )
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = if (selectedTest.lastValue % 1f == 0f)
                                                "${selectedTest.lastValue.toInt()}"
                                            else
                                                "${selectedTest.lastValue}",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PrimaryBlue
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = selectedTest.unit,
                                            fontSize = 9.5.sp,
                                            color = AppTheme.colors.textSecondary,
                                            modifier = Modifier.padding(bottom = 1.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Divider(
                            modifier = Modifier
                                .height(26.dp)
                                .width(1.dp),
                            color = AppTheme.colors.textSecondary.copy(alpha = 0.2f)
                        )

                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.TrendingUp,
                                        contentDescription = null,
                                        tint = GreenImprovement,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = selectedTest.statusText,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GreenImprovement
                                    )
                                }
                                Text(
                                    text = "نسبت به آزمایش قبل",
                                    fontSize = 9.5.sp,
                                    color = AppTheme.colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}