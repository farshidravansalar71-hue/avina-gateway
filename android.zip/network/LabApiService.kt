package com.avina.health.network

import okhttp3.MultipartBody
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.GET
import retrofit2.http.DELETE
import retrofit2.http.Path
/**
 * ارتباط AVINA با سرور تحلیل آزمایش
 *
 * مسئولیت این کلاس:
 * فقط ارسال تصویر و دریافت JSON
 *
 * تحلیل پزشکی، Health Score، پیشنهاد آوین و
 * ساخت چارت در سرور انجام می‌شود.
 */
interface LabApiService {

    /**
     * ارسال تصویر آزمایش برای تحلیل
     *
     * Endpoint:
     * POST /api/v1/lab/analyze
     *
     * Content-Type:
     * multipart/form-data
     */
    @GET("api/v1/lab/status")
    suspend fun getUserStatus(): UserStatusResponse
    @Multipart
    @POST("api/v1/lab/analyze")
    suspend fun analyzeLabImage(
        @Part image: MultipartBody.Part
    ): LabAnalysisResponse

    /**
     * لیست خلاصه‌ی گزارش‌های قبلی کاربر (برای تب/دکمه‌ی «گزارش PDF»)
     *
     * Endpoint:
     * GET /api/v1/lab/reports
     */
    @GET("api/v1/lab/reports")
    suspend fun getUserReports(): LabReportListResponse

    /**
     * جزئیات کامل یک گزارش خاص (فیلترشده طبق سطح دسترسی کاربر، سمت سرور)
     *
     * Endpoint:
     * GET /api/v1/lab/reports/{reportId}
     */
    @GET("api/v1/lab/reports/{reportId}")
    suspend fun getUserReport(
        @Path("reportId") reportId: String
    ): LabAnalysisResponse

    /**
     * حذف یک گزارش
     *
     * Endpoint:
     * DELETE /api/v1/lab/reports/{reportId}
     */
    @DELETE("api/v1/lab/reports/{reportId}")
    suspend fun deleteUserReport(
        @Path("reportId") reportId: String
    ): DeleteReportResponse
}