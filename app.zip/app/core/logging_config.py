import logging
import os

from logging.handlers import RotatingFileHandler
from pythonjsonlogger import jsonlogger


LOG_DIR = "logs"


def setup_logging():

    os.makedirs(
        LOG_DIR,
        exist_ok=True
    )


    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s"
    )


    app_handler = RotatingFileHandler(
        f"{LOG_DIR}/app.log",
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8"
    )


    app_handler.setFormatter(
        formatter
    )


    error_handler = RotatingFileHandler(
        f"{LOG_DIR}/error.log",
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8"
    )


    error_handler.setLevel(
        logging.ERROR
    )


    error_handler.setFormatter(
        formatter
    )


    root_logger = logging.getLogger()

    root_logger.setLevel(
        logging.INFO
    )


    root_logger.addHandler(
        app_handler
    )


    root_logger.addHandler(
        error_handler
    )


    logging.info(
        "Logging initialized"
    )