from app.database.database import Base, engine

# مهم:
# باعث می‌شود SQLAlchemy مدل‌ها را بشناسد
from app.database import models


def init_db():

    Base.metadata.create_all(
        bind=engine
    )