package com.avina.health.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [NotificationEntity::class], version = 1, exportSchema = false)
abstract class AvinaDatabase : RoomDatabase() {

    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AvinaDatabase? = null

        fun getDatabase(context: Context): AvinaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AvinaDatabase::class.java,
                    "avina_database"
                )
                    .fallbackToDestructiveMigration() // برای رفع مشکل عدم نمایش داده‌ها در تغییرات ساختاری
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}