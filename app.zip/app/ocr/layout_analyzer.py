from dataclasses import dataclass
from typing import List, Optional
import re


# =========================================================
# OCR DATA MODELS
# =========================================================

@dataclass
class OCRToken:
    text: str
    left: int
    top: int
    right: int
    bottom: int
    center_x: float
    center_y: float

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return self.bottom - self.top


@dataclass
class OCRCell:
    tokens: List[OCRToken]

    @property
    def left(self) -> int:
        return min(token.left for token in self.tokens)

    @property
    def right(self) -> int:
        return max(token.right for token in self.tokens)

    @property
    def top(self) -> int:
        return min(token.top for token in self.tokens)

    @property
    def bottom(self) -> int:
        return max(token.bottom for token in self.tokens)

    @property
    def center_x(self) -> float:
        return (self.left + self.right) / 2

    @property
    def text(self) -> str:
        return " ".join(
            token.text.strip()
            for token in self.tokens
            if token.text.strip()
        )


@dataclass
class OCRRow:
    tokens: List[OCRToken]

    @property
    def top(self) -> int:
        return min(token.top for token in self.tokens)

    @property
    def bottom(self) -> int:
        return max(token.bottom for token in self.tokens)

    @property
    def cells(self) -> List[OCRCell]:
        return []


@dataclass
class StructuredRow:
    cells: List[OCRCell]

    @property
    def top(self) -> int:
        return min(cell.top for cell in self.cells)

    @property
    def bottom(self) -> int:
        return max(cell.bottom for cell in self.cells)


# =========================================================
# LAYOUT ANALYZER
# =========================================================

class LayoutAnalyzer:
    """
    تحلیل ساختار Layout خروجی PaddleOCR.

    Pipeline:

        PaddleOCR
            ↓
        OCRToken
            ↓
        Row grouping
            ↓
        Cell grouping
            ↓
        Logical column detection
            ↓
        Structured rows

    این کلاس عمداً وابسته به X ثابت نیست.
    """

    ROW_OVERLAP_THRESHOLD = 0.40

    # فاصله‌ای که معمولاً بین دو سلول یک جدول دیده می‌شود.
    CELL_GAP_MIN = 35

    # اگر فاصله خیلی بزرگ باشد تقریباً حتماً مرز ستون است.
    COLUMN_GAP = 120

    # =====================================================
    # PUBLIC API
    # =====================================================

    def analyze(self, ocr_result) -> List[OCRRow]:
        tokens = self._extract_tokens(ocr_result)

        if not tokens:
            return []

        return self._group_into_rows(tokens)

    def build_structured_rows(
        self,
        rows: List[OCRRow],
    ) -> List[StructuredRow]:

        structured: List[StructuredRow] = []

        for row in rows:
            cells = self._build_cells(row.tokens)

            if not cells:
                continue

            structured.append(
                StructuredRow(cells=cells)
            )

        return structured

    # =====================================================
    # TOKEN EXTRACTION
    # =====================================================

    def _extract_tokens(
        self,
        ocr_result,
    ) -> List[OCRToken]:

        result = self._unwrap_result(ocr_result)

        texts = result.get("rec_texts", [])
        boxes = result.get("rec_boxes", [])

        tokens: List[OCRToken] = []

        for text, box in zip(texts, boxes):

            text = str(text).strip()

            if not text:
                continue

            try:
                left = int(box[0])
                top = int(box[1])
                right = int(box[2])
                bottom = int(box[3])
            except (IndexError, TypeError, ValueError):
                continue

            if right <= left or bottom <= top:
                continue

            tokens.append(
                OCRToken(
                    text=text,
                    left=left,
                    top=top,
                    right=right,
                    bottom=bottom,
                    center_x=(left + right) / 2,
                    center_y=(top + bottom) / 2,
                )
            )

        return sorted(
            tokens,
            key=lambda token: (
                token.top,
                token.left,
            ),
        )

    # =====================================================
    # RESULT NORMALIZATION
    # =====================================================

    def _unwrap_result(
        self,
        ocr_result,
    ) -> dict:

        if isinstance(ocr_result, dict):
            return ocr_result.get(
                "res",
                ocr_result,
            )

        if hasattr(ocr_result, "json"):

            data = ocr_result.json

            if callable(data):
                data = data()

            if isinstance(data, dict):
                return data.get(
                    "res",
                    data,
                )

        if hasattr(ocr_result, "res"):

            data = ocr_result.res

            if isinstance(data, dict):
                return data

        raise TypeError(
            "ساختار خروجی PaddleOCR قابل شناسایی نیست."
        )

    # =====================================================
    # ROW GROUPING
    # =====================================================

    def _group_into_rows(
        self,
        tokens: List[OCRToken],
    ) -> List[OCRRow]:

        rows: List[List[OCRToken]] = []

        for token in sorted(
            tokens,
            key=lambda item: item.top,
        ):

            placed = False

            for row in rows:

                row_top = min(
                    item.top
                    for item in row
                )

                row_bottom = max(
                    item.bottom
                    for item in row
                )

                overlap = self._vertical_overlap(
                    row_top,
                    row_bottom,
                    token.top,
                    token.bottom,
                )

                token_height = token.height
                row_height = row_bottom - row_top

                min_height = min(
                    row_height,
                    token_height,
                )

                if (
                    min_height > 0
                    and overlap / min_height
                    >= self.ROW_OVERLAP_THRESHOLD
                ):
                    row.append(token)
                    placed = True
                    break

            if not placed:
                rows.append([token])

        normalized_rows = [
            OCRRow(
                tokens=sorted(
                    row,
                    key=lambda item: item.left,
                )
            )
            for row in rows
            if row
        ]

        return sorted(
            normalized_rows,
            key=lambda row: row.top,
        )

    # =====================================================
    # VERTICAL OVERLAP
    # =====================================================

    @staticmethod
    def _vertical_overlap(
        top1: int,
        bottom1: int,
        top2: int,
        bottom2: int,
    ) -> int:

        return max(
            0,
            min(bottom1, bottom2)
            - max(top1, top2),
        )

    # =====================================================
    # CELL GROUPING
    # =====================================================

    def _build_cells(
        self,
        tokens: List[OCRToken],
    ) -> List[OCRCell]:

        if not tokens:
            return []

        sorted_tokens = sorted(
            tokens,
            key=lambda token: token.left,
        )

        cells: List[List[OCRToken]] = []

        current_cell = [
            sorted_tokens[0]
        ]

        for token in sorted_tokens[1:]:

            previous = current_cell[-1]

            gap = (
                token.left
                - previous.right
            )

            if self._should_start_new_cell(
                previous,
                token,
                gap,
            ):

                cells.append(
                    current_cell
                )

                current_cell = [token]

            else:
                current_cell.append(token)

        if current_cell:
            cells.append(current_cell)

        return [
            OCRCell(tokens=cell)
            for cell in cells
        ]

    # =====================================================
    # CELL BOUNDARY DECISION
    # =====================================================

    def _should_start_new_cell(
        self,
        previous: OCRToken,
        current: OCRToken,
        gap: int,
    ) -> bool:

        # فاصله منفی یعنی overlap افقی داریم.
        if gap < 0:
            return False

        # فاصله خیلی بزرگ → سلول جدید
        if gap >= self.COLUMN_GAP:
            return True

        # الگوهای خاص آزمایشگاهی
        previous_text = previous.text.strip()
        current_text = current.text.strip()

        # -------------------------------------------------
        # عدد → واحد
        # -------------------------------------------------

        if self._looks_like_number(previous_text):
            if self._looks_like_unit(current_text):
                return True

        # -------------------------------------------------
        # واحد → Reference
        # -------------------------------------------------

        if self._looks_like_unit(previous_text):
            if self._looks_like_reference(current_text):
                return True

        # -------------------------------------------------
        # Method → Reference
        # -------------------------------------------------

        if self._looks_like_method(previous_text):
            if self._looks_like_reference(current_text):
                return True

        # -------------------------------------------------
        # متن → عدد
        # -------------------------------------------------

        if (
            not self._looks_like_number(previous_text)
            and self._looks_like_number(current_text)
            and gap >= self.CELL_GAP_MIN
        ):
            return True

        # -------------------------------------------------
        # عدد → متن غیر واحد
        # -------------------------------------------------

        if (
            self._looks_like_number(previous_text)
            and not self._looks_like_unit(current_text)
            and gap >= self.CELL_GAP_MIN
        ):
            return True

        # -------------------------------------------------
        # واحدهای چسبیده
        # -------------------------------------------------

        if self._looks_like_unit(previous_text):
            return True

        # -------------------------------------------------
        # Reference داخل متن
        # -------------------------------------------------

        if self._looks_like_reference(current_text):
            return True

        # فاصله عادی بزرگ
        if gap >= self.CELL_GAP_MIN:
            return True

        return False

    # =====================================================
    # TEXT CLASSIFIERS
    # =====================================================

    @staticmethod
    def _looks_like_number(
        text: str,
    ) -> bool:

        clean = (
            text
            .strip()
            .replace(",", "")
            .replace("−", "-")
            .replace("–", "-")
        )

        return bool(
            re.fullmatch(
                r"[+-]?\d+(?:\.\d+)?",
                clean,
            )
        )

    @staticmethod
    def _looks_like_unit(
        text: str,
    ) -> bool:

        clean = (
            text
            .strip()
            .lower()
            .replace(" ", "")
        )

        units = {
            "mg/dl",
            "ng/dl",
            "pg/ml",
            "pg/dl",
            "g/dl",
            "mmol/l",
            "µmol/l",
            "umol/l",
            "miu/l",
            "iu/l",
            "u/l",
            "fl",
            "pg",
            "%",
            "pmol/l",
            "ng/ml",
            "ug/dl",
            "µg/dl",
            "mg/l",
            "g/l",
        }

        if clean in units:
            return True

        return (
            clean.endswith("/l")
            or clean.endswith("/dl")
            or clean.endswith("/ml")
        )

    @staticmethod
    def _looks_like_reference(
        text: str,
    ) -> bool:

        clean = text.strip()

        patterns = [
            r"^\d+(?:\.\d+)?-\d+(?:\.\d+)?$",
            r"^[<>]=?\s*\d+(?:\.\d+)?$",
            r"^\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?$",
            r"^(male|female)\s*:",
        ]

        return any(
            re.search(pattern, clean, re.IGNORECASE)
            for pattern in patterns
        )

    @staticmethod
    def _looks_like_method(
        text: str,
    ) -> bool:

        clean = text.strip().lower()

        return clean in {
            "ecl",
            "elisa",
            "colorimetry",
            "chemiluminescence",
            "immunoassay",
        }

    # =====================================================
    # DEBUG
    # =====================================================

    def debug_rows(
        self,
        rows: List[OCRRow],
    ) -> List[str]:

        output: List[str] = []

        for index, row in enumerate(rows):

            text = " | ".join(
                token.text
                for token in row.tokens
            )

            output.append(
                f"ROW {index + 1}: {text}"
            )

        return output

    def debug_cells(
        self,
        structured_rows: List[StructuredRow],
    ) -> List[str]:

        output: List[str] = []

        for row_index, row in enumerate(
            structured_rows,
            start=1,
        ):

            output.append(
                f"ROW {row_index}"
            )

            for cell_index, cell in enumerate(
                row.cells,
                start=1,
            ):

                output.append(
                    f"  CELL {cell_index}: "
                    f"'{cell.text}' "
                    f"[x={cell.left}-{cell.right}, "
                    f"y={cell.top}-{cell.bottom}]"
                )

        return output

    def debug_structured_rows(
        self,
        structured_rows: List[StructuredRow],
    ) -> List[str]:

        output: List[str] = []

        for index, row in enumerate(
            structured_rows,
            start=1,
        ):

            text = " | ".join(
                cell.text
                for cell in row.cells
            )

            output.append(
                f"STRUCTURED ROW {index}: {text}"
            )

        return output