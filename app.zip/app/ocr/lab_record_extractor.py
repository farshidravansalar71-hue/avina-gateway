from dataclasses import dataclass, asdict
from typing import List, Optional
import re

from app.ocr.table_structure import LogicalTable, TableRow, TableCell


# =========================================================
# LAB RECORD
# =========================================================

@dataclass
class LabRecord:
    testName: str
    result: Optional[str] = None
    unit: Optional[str] = None
    method: Optional[str] = None
    reference: Optional[str] = None
    category: Optional[str] = None

    def to_dict(self):
        return asdict(self)


# =========================================================
# EXTRACTOR
# =========================================================

class LabRecordExtractor:

    # -----------------------------------------------------
    # Common non-result words
    # -----------------------------------------------------

    IGNORE_VALUES = {
        "test",
        "tests",
        "result",
        "results",
        "unit",
        "units",
        "method",
        "reference",
        "reference range",
        "reference range:",
        "referenceRange",
    }

    # -----------------------------------------------------
    # Section/category aliases
    # -----------------------------------------------------

    CATEGORY_ALIASES = {
        "hormones": "hormones",
        "thyroid function test": "thyroid",
        "thyroid panel": "thyroid",
        "urine analysis": "urine",
        "urinalysis": "urine",
        "urine examination": "urine",
        "blood biochemistry": "biochemistry",
        "blood biochemistry continue": "biochemistry",
        "biochemistry": "biochemistry",
    }

    # -----------------------------------------------------
    # Public API
    # -----------------------------------------------------

    def extract(
        self,
        tables: List[LogicalTable],
    ) -> List[LabRecord]:

        records: List[LabRecord] = []

        for table in tables:

            category = self._detect_category(
                table
            )

            if table.table_type == "urine":
                table_records = self._extract_urine(
                    table,
                    category,
                )

            else:
                table_records = self._extract_standard_table(
                    table,
                    category,
                )

            records.extend(
                table_records
            )

        return self._deduplicate(
            records
        )

    # =====================================================
    # CATEGORY
    # =====================================================

    def _detect_category(
        self,
        table: LogicalTable,
    ) -> Optional[str]:

        title = self._normalize(
            table.title or ""
        )

        if title in self.CATEGORY_ALIASES:
            return self.CATEGORY_ALIASES[
                title
            ]

        return None

    # =====================================================
    # STANDARD TABLE
    # =====================================================

    def _extract_standard_table(
        self,
        table: LogicalTable,
        category: Optional[str],
    ) -> List[LabRecord]:

        records = []

        columns = self._resolve_columns(
            table
        )

        for row in table.rows:

            if self._is_header_row(
                row
            ):
                continue

            if not row.cells:
                continue

            record = self._parse_standard_row(
                row,
                columns,
                category,
            )

            if record is not None:
                records.append(
                    record
                )

        return records

    # =====================================================
    # COLUMN RESOLUTION
    # =====================================================

    def _resolve_columns(
        self,
        table: LogicalTable,
    ) -> List[str]:

        if table.columns:
            return [
                self._normalize_column(
                    column
                )
                for column in table.columns
            ]

        # Fallback for tables without header.
        return [
            "test",
            "result",
            "unit",
            "method",
            "reference",
        ]

    # =====================================================
    # STANDARD ROW PARSER
    # =====================================================

    def _parse_standard_row(
        self,
        row: TableRow,
        columns: List[str],
        category: Optional[str],
    ) -> Optional[LabRecord]:

        cells = [
            cell
            for cell in row.cells
            if cell.text.strip()
        ]

        if len(cells) < 2:
            return None

        values = [
            cell.text.strip()
            for cell in cells
        ]

        # -------------------------------------------------
        # Find numeric / qualitative result
        # -------------------------------------------------

        result_index = self._find_result_index(
            values
        )

        if result_index is None:
            return None

        if result_index == 0:
            return None

        test_name = " ".join(
            values[:result_index]
        ).strip()

        if not self._is_valid_test_name(
            test_name
        ):
            return None

        result = values[
            result_index
        ]

        remaining = values[
            result_index + 1:
        ]

        unit = None
        method = None
        reference = None

        # -------------------------------------------------
        # Assign remaining values
        # -------------------------------------------------

        for value in remaining:

            if not value:
                continue

            if (
                unit is None
                and self._looks_like_unit(
                    value
                )
            ):
                unit = value
                continue

            if (
                reference is None
                and self._looks_like_reference(
                    value
                )
            ):
                reference = value
                continue

            if (
                method is None
                and self._looks_like_method(
                    value
                )
            ):
                method = value
                continue

            # Unknown remaining text:
            # Prefer reference because lab
            # references are usually last.
            if reference is None:
                reference = value

        return LabRecord(
            testName=self._clean_test_name(
                test_name
            ),
            result=self._normalize_result(
                result
            ),
            unit=self._normalize_unit(
                unit
            ),
            method=self._clean_optional(
                method
            ),
            reference=self._normalize_reference(
                reference
            ),
            category=category,
        )

    # =====================================================
    # RESULT DETECTION
    # =====================================================

    def _find_result_index(
        self,
        values: List[str],
    ) -> Optional[int]:

        for index, value in enumerate(
            values
        ):

            if self._looks_like_result(
                value
            ):
                return index

        return None

    def _looks_like_result(
        self,
        value: str,
    ) -> bool:

        clean = value.strip()

        normalized = self._normalize(
            clean
        )

        qualitative = {
            "positive",
            "negative",
            "pos",
            "neg",
            "present",
            "absent",
            "clear",
            "cloudy",
            "yellow",
            "many",
            "few",
            "none",
            "not seen",
        }

        if normalized in qualitative:
            return True

        # Numeric result
        numeric = re.fullmatch(
            r"""
            [+-]?
            (?:
                \d+(?:[.,]\d+)?
                |
                [.,]\d+
            )
            (?:\s*[a-zA-Z%]+)?
            """,
            clean,
            re.VERBOSE,
        )

        return numeric is not None

    # =====================================================
    # UNIT DETECTION
    # =====================================================

    def _looks_like_unit(
        self,
        value: str,
    ) -> bool:

        normalized = (
            value
            .lower()
            .replace(" ", "")
        )

        common_units = {
            "mg/dl",
            "g/dl",
            "ng/ml",
            "ng/dl",
            "pg/ml",
            "pg/dl",
            "ug/dl",
            "µg/dl",
            "mg/l",
            "g/l",
            "mmol/l",
            "mol/l",
            "µmol/l",
            "umol/l",
            "miu/l",
            "iu/l",
            "iu/ml",
            "u/l",
            "u/ml",
            "pmol/l",
            "nmol/l",
            "fl",
            "pg",
            "ng",
            "mg",
            "%",
            "sec",
            "s",
            "min",
        }

        if normalized in common_units:
            return True

        if (
            "/" in normalized
            and len(normalized) <= 20
        ):
            return True

        return False

    # =====================================================
    # REFERENCE DETECTION
    # =====================================================

    def _looks_like_reference(
        self,
        value: str,
    ) -> bool:

        value = value.strip()

        # Numeric ranges
        if re.search(
            r"\d\s*[-–—]\s*\d",
            value,
        ):
            return True

        # Inequality ranges
        if re.search(
            r"[<>≤≥]\s*\d",
            value,
        ):
            return True

        # Male/Female references
        lower = value.lower()

        if (
            "male" in lower
            or "female" in lower
        ):
            return True

        # "less than", "more than"
        if (
            "less than" in lower
            or "more than" in lower
        ):
            return True

        return False

    # =====================================================
    # METHOD DETECTION
    # =====================================================

    def _looks_like_method(
        self,
        value: str,
    ) -> bool:

        normalized = self._normalize(
            value
        )

        methods = {
            "ecl",
            "elisa",
            "clia",
            "hplc",
            "colorimetry",
            "chemiluminescence",
            "immunoassay",
            "spectrophotometry",
            "photometry",
        }

        return normalized in methods

    # =====================================================
    # URINE
    # =====================================================

    def _extract_urine(
        self,
        table: LogicalTable,
        category: Optional[str],
    ) -> List[LabRecord]:

        records = []

        for row in table.rows:

            cells = row.cells

            if not cells:
                continue

            # Header:
            # Macroscopy | Microscopy
            if self._is_urine_header(
                cells
            ):
                continue

            # -------------------------------------------------
            # Standard urine layout:
            #
            # Test | Result | Test | Result
            # -------------------------------------------------

            if len(cells) >= 4:

                left = self._parse_key_value(
                    cells[0],
                    cells[1],
                    category,
                )

                right = self._parse_key_value(
                    cells[2],
                    cells[3],
                    category,
                )

                if left:
                    records.append(
                        left
                    )

                if right:
                    records.append(
                        right
                    )

                continue

            # -------------------------------------------------
            # Remaining single-side rows
            # -------------------------------------------------

            if len(cells) >= 2:

                record = self._parse_key_value(
                    cells[0],
                    cells[1],
                    category,
                )

                if record:
                    records.append(
                        record
                    )

        return records

    # =====================================================
    # URINE HEADER
    # =====================================================

    def _is_urine_header(
        self,
        cells: List[TableCell],
    ) -> bool:

        text = [
            self._normalize(
                cell.text
            )
            for cell in cells
        ]

        return (
            "macroscopy" in text
            and "microscopy" in text
        )

    # =====================================================
    # KEY / VALUE
    # =====================================================

    def _parse_key_value(
        self,
        key_cell: TableCell,
        value_cell: TableCell,
        category: Optional[str],
    ) -> Optional[LabRecord]:

        test_name = key_cell.text.strip()
        result = value_cell.text.strip()

        if not self._is_valid_test_name(
            test_name
        ):
            return None

        if not result:
            return None

        return LabRecord(
            testName=self._clean_test_name(
                test_name
            ),
            result=self._normalize_result(
                result
            ),
            unit=None,
            method=None,
            reference=None,
            category=category,
        )

    # =====================================================
    # HEADER DETECTION
    # =====================================================

    def _is_header_row(
        self,
        row: TableRow,
    ) -> bool:

        values = [
            self._normalize(
                cell.text
            )
            for cell in row.cells
        ]

        normalized = {
            self._normalize_column(
                value
            )
            for value in values
        }

        return (
            "test" in normalized
            and "result" in normalized
        )

    # =====================================================
    # TEST NAME VALIDATION
    # =====================================================

    def _is_valid_test_name(
        self,
        value: str,
    ) -> bool:

        value = value.strip()

        if not value:
            return False

        normalized = self._normalize(
            value
        )

        if normalized in self.IGNORE_VALUES:
            return False

        if len(value) < 2:
            return False

        # Pure number cannot be test name
        if re.fullmatch(
            r"[+-]?\d+(?:[.,]\d+)?",
            value,
        ):
            return False

        # Obvious explanatory text
        blocked = (
            "risk:",
            "low risk",
            "moderate risk",
            "high risk",
            "less than",
            "more than",
        )

        if normalized.startswith(
            blocked
        ):
            return False

        return True

    # =====================================================
    # NORMALIZATION
    # =====================================================

    @staticmethod
    def _normalize(
        value: str,
    ) -> str:

        value = value.strip().lower()

        value = re.sub(
            r"\s+",
            " ",
            value,
        )

        return value

    @staticmethod
    def _normalize_column(
        value: str,
    ) -> str:

        normalized = (
            value
            .strip()
            .lower()
        )

        normalized = re.sub(
            r"\s+",
            " ",
            normalized,
        )

        aliases = {
            "tests": "test",
            "test name": "test",
            "parameter": "test",
            "investigation": "test",

            "results": "result",
            "value": "result",
            "values": "result",

            "units": "unit",

            "reference range": "reference",
            "referencerange": "reference",
            "reference interval": "reference",
            "normal range": "reference",
        }

        return aliases.get(
            normalized,
            normalized,
        )

    @staticmethod
    def _normalize_result(
        value: str,
    ) -> str:

        return (
            value
            .strip()
            .replace("۰", "0")
            .replace("۱", "1")
            .replace("۲", "2")
            .replace("۳", "3")
            .replace("۴", "4")
            .replace("۵", "5")
            .replace("۶", "6")
            .replace("۷", "7")
            .replace("۸", "8")
            .replace("۹", "9")
        )

    @staticmethod
    def _normalize_unit(
        value: Optional[str],
    ) -> Optional[str]:

        if not value:
            return None

        value = value.strip()

        value = re.sub(
            r"\s*/\s*",
            "/",
            value,
        )

        value = value.replace(
            "ug/di",
            "ug/dL",
        )

        value = value.replace(
            "mg/di",
            "mg/dL",
        )

        return value

    @staticmethod
    def _normalize_reference(
        value: Optional[str],
    ) -> Optional[str]:

        if not value:
            return None

        value = value.strip()

        return (
            value
            .replace("–", "-")
            .replace("—", "-")
            .replace("−", "-")
            .replace("≤", "<=")
            .replace("≥", ">=")
        )

    @staticmethod
    def _clean_test_name(
        value: str,
    ) -> str:

        return re.sub(
            r"\s+",
            " ",
            value,
        ).strip(
            " :|-/"
        )

    @staticmethod
    def _clean_optional(
        value: Optional[str],
    ) -> Optional[str]:

        if not value:
            return None

        value = value.strip()

        return value or None

    # =====================================================
    # DEDUPLICATION
    # =====================================================

    def _deduplicate(
        self,
        records: List[LabRecord],
    ) -> List[LabRecord]:

        result = []

        seen = set()

        for record in records:

            key = (
                self._normalize(
                    record.testName
                ),
                self._normalize(
                    record.result or ""
                ),
                self._normalize(
                    record.category or ""
                ),
            )

            if key in seen:
                continue

            seen.add(key)

            result.append(
                record
            )

        return result

    # =====================================================
    # DEBUG
    # =====================================================

    def debug_records(
        self,
        records: List[LabRecord],
    ) -> List[str]:

        output = []

        for index, record in enumerate(
            records,
            start=1,
        ):

            output.append(
                f"{index}. "
                f"{record.testName} | "
                f"{record.result} | "
                f"{record.unit} | "
                f"{record.method} | "
                f"{record.reference} | "
                f"category={record.category}"
            )

        return output