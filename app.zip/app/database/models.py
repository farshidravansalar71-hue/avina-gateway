from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Text,
    ForeignKey,
    Numeric
)

from sqlalchemy.orm import relationship

from app.database.database import Base


class User(Base):
    """
    حساب کاربری آوین طب
    """

    __tablename__ = "users"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    public_id = Column(
        String(50),
        unique=True,
        index=True,
        nullable=False
    )

    # حساب کاربری
    email = Column(
        String(255),
        unique=True,
        index=True,
        nullable=True
    )

    password_hash = Column(
        String(255),
        nullable=True
    )

    is_premium = Column(
        Boolean,
        default=False
    )
    
    # --- فیلدهای جدید برای پنل ادمین و وضعیت کاربر ---
    is_admin = Column(
        Boolean,
        default=False
    )
    
    is_active = Column(
        Boolean,
        default=True
    )
    
    last_login = Column(
        DateTime,
        nullable=True
    )
    
    # --- فیلدهای جدید برای اطلاعات Premium ---
    premium_plan = Column(
        String(50),
        nullable=True
    )
    
    premium_started_at = Column(
        DateTime,
        nullable=True
    )
    
    premium_expires_at = Column(
        DateTime,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    devices = relationship(
        "Device",
        back_populates="user",
        cascade="all, delete"
    )

    reports = relationship(
        "LabReport",
        back_populates="user",
        cascade="all, delete"
    )
    
    subscriptions = relationship(
        "Subscription",
        back_populates="user",
        cascade="all, delete"
    )


class Subscription(Base):
    """
    جدول خریدهای کاربران
    """
    __tablename__ = "subscriptions"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )
    
    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )
    
    plan = Column(
        String(50),
        nullable=False
    )
    
    price = Column(
        Numeric(10, 2),
        nullable=False
    )
    
    status = Column(
        String(20),
        default="active"
    )
    
    started_at = Column(
        DateTime,
        default=datetime.utcnow
    )
    
    expires_at = Column(
        DateTime,
        nullable=False
    )
    
    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    user = relationship(
        "User",
        back_populates="subscriptions"
    )


class Device(Base):
    """
    دستگاه کاربر
    """

    __tablename__ = "devices"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # UUID ساخته شده توسط اپ
    device_id = Column(
        String(100),
        unique=True,
        index=True,
        nullable=False
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )

    model = Column(
        String(100),
        nullable=True
    )

    manufacturer = Column(
        String(100),
        nullable=True
    )

    os_version = Column(
        String(50),
        nullable=True
    )

    app_version = Column(
        String(50),
        nullable=True
    )

    last_seen = Column(
        DateTime,
        default=datetime.utcnow
    )

    user = relationship(
        "User",
        back_populates="devices"
    )

    usage = relationship(
        "DeviceUsage",
        back_populates="device",
        cascade="all, delete"
    )


class DeviceUsage(Base):
    """
    محدودیت مصرف رایگان دستگاه
    """

    __tablename__ = "device_usage"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    device_id = Column(
        Integer,
        ForeignKey("devices.id"),
        unique=True
    )

    free_analysis_count = Column(
        Integer,
        default=0
    )

    last_analysis_at = Column(
        DateTime,
        nullable=True
    )

    device = relationship(
        "Device",
        back_populates="usage"
    )


class LabReport(Base):
    """
    گزارش آزمایش کاربر
    """

    __tablename__ = "lab_reports"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    report_id = Column(
        String(100),
        unique=True,
        index=True,
        nullable=False
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )

    lab_results_json = Column(
        Text,
        nullable=True
    )

    analysis_json = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    user = relationship(
        "User",
        back_populates="reports"
    )
    
    
class LabTestDictionary(Base):
    """
    دیکشنری و کش اطلاعات تست‌های آزمایشگاهی
    """

    __tablename__ = "lab_test_dictionary"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    test_key = Column(
        String(150),
        unique=True,
        index=True,
        nullable=False
    )

    persian_name = Column(
        String(255),
        nullable=False
    )

    description = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )