import os
os.environ["FLAGS_use_onednn"] = "0"
os.environ["FLAGS_enable_onednn"] = "0"
os.environ["FLAGS_use_mkldnn"] = "0"

from pathlib import Path
from typing import List, Dict, Any


class PaddleTableEngine:
    def __init__(self):
        self.pipeline = None
        self._load_model()

    def _load_model(self):
        try:
            from paddleocr import PaddleOCR

            try:
                # تلاش اول: غیرفعال کردن صریح mkldnn/onednn هنگام ساخت پایپ‌لاین
                self.pipeline = PaddleOCR(
                    lang="en",
                    use_doc_orientation_classify=False,
                    use_doc_unwarping=False,
                    use_textline_orientation=False,
                    enable_mkldnn=False,
                )
            except TypeError:
                # اگر این نسخه از API پارامتر enable_mkldnn را قبول نکرد،
                # بدون آن دوباره تلاش می‌کنیم (env varهای بالا همچنان فعال هستند)
                print("[PADDLE] enable_mkldnn param not supported, retrying without it")
                self.pipeline = PaddleOCR(
                    lang="en",
                    use_doc_orientation_classify=False,
                    use_doc_unwarping=False,
                    use_textline_orientation=False,
                )

            print("[PADDLE] OCR engine loaded")

        except Exception as e:
            raise RuntimeError(f"Paddle load failed: {e}")

    def analyze(self, image_path: str) -> List[Dict[str, Any]]:
        image = Path(image_path)
        if not image.exists():
            raise FileNotFoundError(image_path)

        print("[PADDLE] Processing:", image.name)

        result = self.pipeline.predict(str(image))

        output = []
        for page in result:
            try:
                data = page.json
            except Exception:
                data = str(page)
            output.append({"raw": data})

        return output