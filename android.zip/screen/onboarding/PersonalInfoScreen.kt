//ایجاد حساب
package com.avina.health.screen.onboarding

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.R
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun PersonalInfoScreen(
    onNextClick: (String, String, Int) -> Unit,
    onSendCodeClick: (String) -> Unit = {}
) {
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailCode by remember { mutableStateOf("") }

    var codeSent by remember { mutableStateOf(false) }
    var codeVerified by remember { mutableStateOf(false) }
    var remainingSeconds by remember { mutableIntStateOf(0) }

    var gender by remember { mutableStateOf("آقا") }
    var age by remember { mutableIntStateOf(25) }
    var height by remember { mutableIntStateOf(175) }
    var weight by remember { mutableIntStateOf(70) }

    LaunchedEffect(remainingSeconds) {
        if (remainingSeconds > 0) {
            delay(1000)
            remainingSeconds--
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            AppTheme.colors.cardBackground,
                            AppTheme.colors.cardBackground.copy(alpha = 0.8f)
                        )
                    )
                )
                .imePadding()
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 382.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ShinyLogo()

                    Spacer(modifier = Modifier.height(8.dp))

                    SectionLabel(text = "نام کاربری")
                    CustomInputField(
                        value = username,
                        onValueChange = { username = it },
                        placeholder = "نام کاربری خود را وارد کنید",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SectionLabel(text = "ایمیل")
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CustomInputField(
                                value = email,
                                onValueChange = {
                                    email = it
                                    codeSent = false
                                    codeVerified = false
                                },
                                placeholder = "example@email.com",
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Start,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )

                            Button(
                                onClick = {
                                    codeSent = true
                                    remainingSeconds = 120
                                    codeVerified = false
                                    onSendCodeClick(email.trim())
                                },
                                enabled = email.isNotBlank() && remainingSeconds == 0,
                                modifier = Modifier
                                    .width(110.dp)
                                    .height(46.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PrimaryBlue.copy(alpha = 0.1f),
                                    disabledContainerColor = AppTheme.colors.cardBackground
                                )
                            ) {
                                Text(
                                    text = when {
                                        remainingSeconds > 0 ->
                                            String.format("%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)

                                        codeSent ->
                                            "ارسال مجدد"

                                        else ->
                                            "ارسال کد"
                                    },
                                    color = PrimaryBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    if (codeSent) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ارسال شد.",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End,
                            fontSize = 9.5.sp,
                            color = AppTheme.colors.textSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    SectionLabel(text = "رمز عبور")
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        CustomInputField(
                            value = password,
                            onValueChange = { password = it },
                            placeholder = "رمز عبور خود را وارد کنید",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Right,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    SectionLabel(text = "تاییدیه کد ایمیل")
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CustomInputField(
                                value = emailCode,
                                onValueChange = {
                                    emailCode = it
                                    codeVerified = false
                                },
                                placeholder = "کد ارسال شده را وارد کنید",
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Right,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )

                            Button(
                                onClick = {
                                    if (emailCode.isNotBlank()) {
                                        codeVerified = true
                                    }
                                },
                                enabled = codeSent && emailCode.isNotBlank() && !codeVerified,
                                modifier = Modifier
                                    .width(92.dp)
                                    .height(46.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (codeVerified) Color(0xFF2DBE7E) else PrimaryBlue.copy(alpha = 0.1f),
                                    disabledContainerColor = if (codeVerified) Color(0xFF2DBE7E) else AppTheme.colors.cardBackground
                                )
                            ) {
                                Text(
                                    text = if (codeVerified) "تأیید شد" else "تأیید کد",
                                    color = if (codeVerified) Color.White else PrimaryBlue,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    CompactGenderSelector(
                        selected = gender,
                        onSelected = { gender = it }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "سن",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Right,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppTheme.colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            CompactWheelPicker(
                                value = age,
                                range = 1..120,
                                unit = "سال",
                                onValueChange = { age = it }
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "قد",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Right,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppTheme.colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            CompactWheelPicker(
                                value = height,
                                range = 50..250,
                                unit = "cm",
                                onValueChange = { height = it }
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "وزن",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Right,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppTheme.colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            CompactWheelPicker(
                                value = weight,
                                range = 20..300,
                                unit = "kg",
                                onValueChange = { weight = it }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val finalUsername = username.trim().ifEmpty { "کاربر" }
                            onNextClick(
                                finalUsername,
                                gender,
                                age
                            )
                        },
                        enabled = username.isNotBlank() &&
                                email.isNotBlank() &&
                                password.isNotBlank() &&
                                emailCode.isNotBlank() &&
                                codeSent &&
                                codeVerified,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryBlue,
                            disabledContainerColor = PrimaryBlue.copy(alpha = 0.4f)
                        )
                    ) {
                        Text(
                            text = "ادامه",
                            fontSize = 16.sp,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }
}

@Composable
private fun CustomInputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    textAlign: TextAlign = TextAlign.Right,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .height(48.dp)
            .background(AppTheme.colors.cardBackground, RoundedCornerShape(16.dp))
            .border(1.dp, PrimaryBlue.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp),
        singleLine = true,
        textStyle = TextStyle(
            color = AppTheme.colors.textPrimary,
            fontSize = 14.sp,
            textAlign = textAlign,
            platformStyle = PlatformTextStyle(includeFontPadding = false)
        ),
        cursorBrush = SolidColor(PrimaryBlue),
        visualTransformation = visualTransformation,
        keyboardOptions = keyboardOptions,
        decorationBox = { innerTextField ->
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.CenterStart
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = placeholder,
                        color = AppTheme.colors.textSecondary,
                        fontSize = 13.5.sp,
                        textAlign = textAlign,
                        modifier = Modifier.fillMaxWidth(),
                        style = TextStyle(
                            platformStyle = PlatformTextStyle(includeFontPadding = false)
                        )
                    )
                }
                innerTextField()
            }
        }
    )
}

@Composable
private fun ShinyLogo() {
    val transition = rememberInfiniteTransition(label = "logo_shine")
    val shineProgress by transition.animateFloat(
        initialValue = -0.45f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2200,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "shine_progress"
    )

    val density = LocalDensity.current
    val travelPx = with(density) { 110.dp.toPx() }
    val translatePx = (shineProgress * travelPx) - (travelPx / 2f)

    Box(
        modifier = Modifier
            .size(62.dp)
            .clip(CircleShape)
            .background(PrimaryBlue.copy(alpha = 0.1f))
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.register_logo),
            contentDescription = "لوگوی آوین طب",
            modifier = Modifier.size(48.dp),
            contentScale = ContentScale.Fit
        )

        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(18.dp)
                .graphicsLayer {
                    translationX = translatePx
                    rotationZ = 24f
                }
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.08f),
                            Color.White.copy(alpha = 0.90f),
                            Color.White.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Right,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = AppTheme.colors.textPrimary
    )
}

@Composable
private fun CompactGenderSelector(
    selected: String,
    onSelected: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "جنسیت",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Right,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = AppTheme.colors.textPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CompactGenderCard(
                modifier = Modifier.weight(1f),
                emoji = "👨",
                title = "آقا",
                selected = selected == "آقا",
                onClick = { onSelected("آقا") }
            )

            CompactGenderCard(
                modifier = Modifier.weight(1f),
                emoji = "👩",
                title = "خانم",
                selected = selected == "خانم",
                onClick = { onSelected("خانم") }
            )
        }
    }
}

@Composable
private fun CompactGenderCard(
    modifier: Modifier = Modifier,
    emoji: String,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (selected) PrimaryBlue else PrimaryBlue.copy(alpha = 0.2f)
    val backgroundColor = if (selected) PrimaryBlue.copy(alpha = 0.1f) else AppTheme.colors.cardBackground
    val titleColor = if (selected) PrimaryBlue else AppTheme.colors.textPrimary

    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(1.3.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = emoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = title,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
                color = titleColor
            )
        }
    }
}

@Composable
private fun CompactWheelPicker(
    modifier: Modifier = Modifier,
    value: Int,
    range: IntRange,
    unit: String,
    onValueChange: (Int) -> Unit
) {
    val numbers = remember(range) { range.toList() }
    val selectedIndex = (value - range.first).coerceIn(0, numbers.lastIndex)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = selectedIndex)
    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedIndex) {
        listState.scrollToItem(selectedIndex)
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collectLatest { scrolling ->
            if (!scrolling) {
                val layoutInfo = listState.layoutInfo
                val visibleItems = layoutInfo.visibleItemsInfo

                if (visibleItems.isNotEmpty()) {
                    val viewportCenter =
                        (layoutInfo.viewportStartOffset + layoutInfo.viewportEndOffset) / 2

                    val closest = visibleItems.minByOrNull { item ->
                        abs((item.offset + item.size / 2) - viewportCenter)
                    }

                    if (closest != null) {
                        val index = closest.index.coerceIn(0, numbers.lastIndex)
                        val picked = numbers[index]

                        if (picked != value) {
                            onValueChange(picked)
                        }

                        scope.launch {
                            listState.animateScrollToItem(index)
                        }
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, PrimaryBlue.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            .background(AppTheme.colors.cardBackground),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(numbers.size) { index ->
                val item = numbers[index]
                val selected = item == value

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.toString(),
                        fontSize = if (selected) 17.sp else 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) PrimaryBlue else AppTheme.colors.textSecondary
                    )

                    if (selected) {
                        Text(
                            text = unit,
                            fontSize = 9.sp,
                            color = PrimaryBlue,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 6.dp)
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .height(18.dp)
                .background(PrimaryBlue.copy(alpha = 0.08f))
        )

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(12.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(AppTheme.colors.cardBackground, Color.Transparent)
                    )
                )
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(12.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, AppTheme.colors.cardBackground)
                    )
                )
        )
    }
}