from dataclasses import dataclass, field
from typing import List, Optional
import re

from app.ocr.layout_analyzer import StructuredRow


# =========================================================
# DATA MODELS
# =========================================================


@dataclass
class TableCell:

    text: str

    left: int
    right: int

    top: int
    bottom: int

    @property
    def center_x(self):
        return (self.left + self.right) / 2

    @property
    def center_y(self):
        return (self.top + self.bottom) / 2

    @property
    def width(self):
        return self.right - self.left



@dataclass
class TableRow:

    cells: List[TableCell] = field(default_factory=list)

    @property
    def top(self):
        if not self.cells:
            return 0
        return min(c.top for c in self.cells)

    @property
    def bottom(self):
        if not self.cells:
            return 0
        return max(c.bottom for c in self.cells)



@dataclass
class LogicalTable:

    rows: List[TableRow] = field(default_factory=list)

    columns: List[str] = field(default_factory=list)

    table_type: str = "unknown"

    title: Optional[str] = None



# =========================================================
# ANALYZER
# =========================================================


class TableStructureAnalyzer:


    HEADER_ALIASES = {

        "test": "test",
        "tests": "test",
        "parameter": "test",
        "investigation": "test",

        "result": "result",
        "results": "result",
        "value": "result",

        "unit": "unit",
        "units": "unit",

        "reference": "reference",
        "reference range": "reference",
        "reference interval": "reference",
        "normal range": "reference",
    }


    SECTION_TITLES = {

        "blood biochemistry",
        "blood biochemistry continue",
        "hormones",
        "thyroid function test",
        "urine analysis",
        "lipids",
        "lipid profile",

    }



    # =====================================================
    # PUBLIC
    # =====================================================


    def analyze(
        self,
        rows: List[StructuredRow]
    ) -> List[LogicalTable]:


        if not rows:
            return []


        rows = self._sort_rows(rows)


        sections = self._split_sections(rows)


        # ⭐ اضافه شده
        sections = self._split_parallel_tables(sections)


        tables = []


        for title, group in sections:


            if not group:
                continue


            converted = []


            for row in group:

                converted.append(
                    self._convert_row(row)
                )


            tables.append(

                LogicalTable(

                    rows=converted,

                    columns=self._detect_columns(
                        converted
                    ),

                    table_type=self._detect_table_type(
                        title,
                        converted
                    ),

                    title=title

                )

            )


        return tables



    # =====================================================
    # PARALLEL TABLE SPLITTER
    # =====================================================


    def _split_parallel_tables(self, sections):

        result = []


        for title, rows in sections:


            split_row = None


            for row in rows:

                cells = row.cells


                if len(cells) == 2:

                    gap = (
                        cells[1].left
                        -
                        cells[0].right
                    )


                    if gap > 300:

                        split_row = row
                        break



            if not split_row:

                result.append(
                    (title, rows)
                )

                continue



            split_x = (

                split_row.cells[0].right

                +

                split_row.cells[1].left

            ) / 2



            left_rows = []
            right_rows = []



            for row in rows:


                left_cells = []
                right_cells = []



                for cell in row.cells:


                    if cell.center_x < split_x:

                        left_cells.append(cell)

                    else:

                        right_cells.append(cell)



                if left_cells:

                    left_rows.append(

                        StructuredRow(
                            cells=left_cells
                        )

                    )



                if right_cells:

                    right_rows.append(

                        StructuredRow(
                            cells=right_cells
                        )

                    )



            result.append(

                (
                    title + " Left",
                    left_rows
                )

            )


            result.append(

                (
                    title + " Right",
                    right_rows
                )

            )



        return result




    # =====================================================
    # SORTING
    # =====================================================


    def _sort_rows(self, rows):

        return sorted(
            rows,
            key=lambda r:
            min(c.top for c in r.cells)
        )


    def _sort_cells(self, cells):

        return sorted(
            cells,
            key=lambda c:c.left
        )



    # =====================================================
    # SECTION SPLIT
    # =====================================================


    def _split_sections(self, rows):

        sections=[]

        current=[]
        title=None


        for row in rows:


            text=self._normalize_text(
                self._row_text(row)
            )


            if self._is_section_title(text):


                if current:

                    sections.append(
                        (
                            title,
                            current
                        )
                    )


                title=self._row_text(row)

                current=[]

                continue



            current.append(row)



        if current:

            sections.append(
                (
                    title,
                    current
                )
            )


        return sections



    # =====================================================
    # HELPERS
    # =====================================================


    def _is_section_title(self,text):

        return any(
            item in text
            for item in self.SECTION_TITLES
        )



    def _convert_row(self,row):

        cells=[]


        for cell in self._sort_cells(row.cells):

            text=cell.text.strip()


            if not text:
                continue


            cells.append(

                TableCell(

                    text=text,

                    left=cell.left,

                    right=cell.right,

                    top=cell.top,

                    bottom=cell.bottom

                )

            )


        return TableRow(
            cells=cells
        )



    def _detect_columns(self,rows):

        for row in rows:

            names=[]


            for cell in row.cells:

                value=self._normalize_text(
                    cell.text
                )


                names.append(

                    self.HEADER_ALIASES.get(
                        value,
                        value
                    )

                )



            if (
                "test" in names
                and
                "result" in names
            ):

                return names



        return []



    def _detect_table_type(self,title,rows):

        text=" ".join(

            self._normalize_text(
                self._row_text(r)
            )

            for r in rows

        )


        if "urine" in text:

            return "urine"



        if (
            "test" in text
            and
            "result" in text
        ):

            return "laboratory"



        return "unknown"



    @staticmethod
    def _row_text(row):

        return " ".join(
            c.text
            for c in row.cells
        ).strip()



    @staticmethod
    def _normalize_text(text):

        text=text.lower().strip()

        text=re.sub(
            r"\s+",
            " ",
            text
        )

        return text



    # =====================================================
    # DEBUG
    # =====================================================


    def debug_tables(self,tables):

        out=[]


        for i,table in enumerate(tables,start=1):

            out.append(
                f"\nTABLE {i}"
            )


            out.append(
                f"TYPE: {table.table_type}"
            )


            if table.title:

                out.append(
                    f"TITLE: {table.title}"
                )



            for j,row in enumerate(
                table.rows,
                start=1
            ):

                out.append(

                    f"ROW {j}: "

                    +

                    " | ".join(
                        c.text
                        for c in row.cells
                    )

                )


        return out