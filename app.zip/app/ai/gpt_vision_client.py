import os
import json
import base64
import logging

from dotenv import load_dotenv
from openai import OpenAI


logger = logging.getLogger(__name__)


load_dotenv()


class GPTVisionClient:
    """
    AVINA GPT Vision Client

    Flow:

    Image
      |
      v
    GPT Vision
      |
      v
    Raw Lab JSON

    فقط استخراج
    بدون تحلیل پزشکی
    """



    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None
    ):


        self.api_key = (
            api_key
            or os.getenv(
                "OPENAI_API_KEY"
            )
        )


        if not self.api_key:

            raise ValueError(
                "OPENAI_API_KEY پیدا نشد"
            )



        self.base_url = (
            base_url
            or os.getenv(
                "OPENAI_BASE_URL",
                "https://api.bluesminds.com/v1"
            )
        )


        self.model = (
            model
            or os.getenv(
                "OPENAI_MODEL",
                "gpt-5.5-mini"
            )
        )



        self.client = OpenAI(

            api_key=self.api_key,

            base_url=self.base_url

        )



        self.total_tokens = 0



    # =====================================================
    # EXTRACT IMAGE
    # =====================================================

    def extract_lab(
        self,
        image_path: str
    ) -> dict:



        print(
            "\n========== STEP 1: GPT VISION ==========\n"
        )



        with open(
            image_path,
            "rb"
        ) as f:


            image_base64 = base64.b64encode(
                f.read()
            ).decode()



        prompt = """

این تصویر برگه آزمایش پزشکی است.

فقط JSON استخراج کن.


ساختار خروجی:

{
 "tests":[
  {
   "name":"",
   "value":"",
   "unit":"",
   "reference":"",
   "flag":""
  }
 ]
}


قوانین:

- فقط استخراج انجام بده.
- تحلیل پزشکی انجام نده.
- اطلاعات شخصی حذف شود.
- نام بیمار، پزشک و مرکز درمانی حذف شود.
- نام آزمایش و مقدار دقیق حفظ شود.
- H,L,HH,LL,* داخل value نباشند.
- این علائم فقط داخل flag قرار بگیرند.
- مقدار را حدس نزن.
- جدول را تشخیص بده.
- هر ردیف جداگانه پردازش شود.
- ردیف‌ها را ترکیب نکن.
- فقط JSON معتبر برگردان.
"""



        response = (
            self.client
            .chat
            .completions
            .create(

                model=self.model,

                messages=[

                    {
                        "role": "user",

                        "content":[

                            {
                                "type":"text",
                                "text":prompt
                            },


                            {
                                "type":"image_url",

                                "image_url":{

                                    "url":
                                    f"data:image/jpeg;base64,{image_base64}"

                                }

                            }

                        ]

                    }

                ],

                temperature=0

            )
        )



        # ==============================
        # TOKEN USAGE
        # ==============================


        if response.usage:


            tokens = (
                response
                .usage
                .total_tokens
                or 0
            )


            self.total_tokens += tokens



            print(
                "GPT tokens:",
                tokens
            )



        raw = (
            response
            .choices[0]
            .message
            .content
        )



        return self._parse_json(
            raw
        )




    # =====================================================
    # JSON CLEANER
    # =====================================================


    def _parse_json(
        self,
        text: str
    ) -> dict:


        text = (
            text
            .strip()
        )



        if text.startswith(
            "```json"
        ):

            text = text[7:]



        elif text.startswith(
            "```"
        ):

            text = text[3:]



        if text.endswith(
            "```"
        ):

            text = text[:-3]



        text = text.strip()



        start = text.find(
            "{"
        )


        end = text.rfind(
            "}"
        )



        if start != -1 and end != -1:

            text = text[
                start:end+1
            ]



        return json.loads(
            text
        )