package com.avina.health.ocr

data class LabResult(
    val testName: String,
    val result: String?,
    val unit: String?,
    val reference: String?
)