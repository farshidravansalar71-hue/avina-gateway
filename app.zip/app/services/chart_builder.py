import logging

from decimal import Decimal, InvalidOperation


logger = logging.getLogger(__name__)





# =====================================================
# NUMERIC CHECK
# بررسی مقدار عددی برای نمودار
# =====================================================

def is_scalar_numeric_value(value):

    if (
        not isinstance(
            value,
            str
        )
        or not value.strip()
    ):

        return False


    try:

        Decimal(
            value.strip()
        )

        return True


    except (
        InvalidOperation,
        ValueError
    ):

        return False







# =====================================================
# BUILD CHART DATA
# داده نمودار
# آماده برای Android + PDF
# =====================================================

def build_chart_data(
    clean_lab_json
):


    charts = []



    for test in clean_lab_json.get(
        "tests",
        []
    ):


        if not isinstance(
            test,
            dict
        ):

            continue



        value = test.get(
            "value",
            ""
        )



        if not is_scalar_numeric_value(
            value
        ):

            continue




        charts.append({

            "test_name": test.get(
                "name",
                ""
            ),

            "persian_name": test.get(
                "persian_name",
                ""
            ),

            "value": value,


            "unit": test.get(
                "unit",
                ""
            ),



            "history": []

        })



    return charts










# =====================================================
# BUILD LAB RESULTS
# جدول کامل آزمایش
# برای نمایش اپ و PDF
# =====================================================

def build_lab_results(
    clean_lab_json
):


    results = []



    for test in clean_lab_json.get(
        "tests",
        []
    ):


        if not isinstance(
            test,
            dict
        ):

            continue




        results.append({

            "name": test.get(
                "name",
                ""
            ),

            "persian_name": test.get(
                "persian_name",
                ""
            ),

            "description": test.get(
                "description",
                ""
            ),

            "value": test.get(
                "value",
                ""
            ),


            "unit": test.get(
                "unit",
                ""
            ),


            "reference": test.get(
                "reference",
                ""
            ),


            "flag": test.get(
                "flag",
                ""
            )

        })



    return results










# =====================================================
# BUILD HEALTH SUMMARY
# کارت اصلی سلامت
# =====================================================

def build_health_summary(
    validated_analysis
):


    return {


        "health_score":

        validated_analysis.get(
            "health_score",
            {}
        ),



        "overall_status":

        validated_analysis.get(
            "overall_status",
            {}
        )

    }









# =====================================================
# BUILD FINDINGS
# بخش نیازمند توجه
# =====================================================

def build_findings(
    validated_analysis
):


    findings = []



    for item in validated_analysis.get(
        "important_findings",
        []
    ):


        if not isinstance(
            item,
            dict
        ):

            continue




        findings.append({

            "title": item.get(
                "test_name",
                ""
            ),



            "test_name": item.get(
                "test_name",
                ""
            ),



            "value": item.get(
                "value",
                ""
            ),



            "status": item.get(
                "status",
                ""
            ),



            "description": item.get(
                "description",
                item.get("explanation", "")
            )

        })



    return findings



# =====================================================
# BUILD SMART RECOMMENDATIONS
# پیشنهاد هوشمند
# =====================================================

def build_recommendations(
    validated_analysis
):


    recommendations = []


    for item in validated_analysis.get(
        "smart_recommendations",
        []
    ):


        if isinstance(
            item,
            str
        ):


            recommendations.append({

                "title": item,

                "description": "",

                "priority": "medium"

            })


        elif isinstance(
            item,
            dict
        ):


            recommendations.append(
                item
            )


    return recommendations


# =====================================================
# BUILD CHART CONTAINER
# ساختار مخصوص PDF و Android
# =====================================================

def build_chart_container(
    clean_lab_json
):


    return {


        "available_tests":

        build_chart_data(
            clean_lab_json
        )

    }









# =====================================================
# BUILD REPORT INFO
# اطلاعات نسخه گزارش
# =====================================================

def build_report_info():

    return {


        "type":

        "laboratory_report",



        "version":

        "1.0"

    }









# =====================================================
# FINAL AVINA JSON
# خروجی اصلی سیستم
# Android + PDF + History
# =====================================================

def build_final_avina_json(
    clean_lab_json,
    validated_analysis
):


    print(
        "\n========== BUILD FINAL AVINA JSON ==========\n"
    )



    final_json = {


        "report_info":

        build_report_info(),





        "health_summary":

        build_health_summary(
            validated_analysis
        ),





        "important_findings":

        build_findings(
            validated_analysis
        ),





        "smart_recommendations":

        build_recommendations(
            validated_analysis
        ),





        "charts":

        build_chart_container(
            clean_lab_json
        ),





        "lab_results":

        build_lab_results(
            clean_lab_json
        )

    }

    print("######## FINAL JSON TEST ########")
    print(final_json)

    return final_json