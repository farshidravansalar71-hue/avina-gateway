from dataclasses import dataclass
from typing import List, Optional
import re

from app.ocr.lab_result_parser import LabResult


# =========================================================
# FILTERED RESULT
# =========================================================

@dataclass
class FilteredLabResult:

    raw_name: str

    test_name: str

    result: Optional[str]

    flag: Optional[str]

    unit: Optional[str]

    reference: Optional[str]

    category: Optional[str]



# =========================================================
# LAB RESULT FILTER
# =========================================================

class LabResultFilter:


    IGNORE_EXACT = {

        "test",
        "tests",
        "result",
        "results",
        "flag",
        "unit",
        "units",
        "method",
        "reference",
        "reference range",
        "reference interval",

        "lipids",
        "hormones",
        "thyroid",
        "thyroid function test",
        "urine analysis",

        "clinical consideration",
        "sub-class information",
        "sub class information",

        "probable metabolic syndrome",

        "ldl density pattern",
        "pattern",
        "pattern a",
        "pattern b",

        "small, dense ldl",

    }



    IGNORE_NAME_PATTERNS = [

        r"^blood biochemistry",

        r"^blood chemistry",

        r"^biochemistry$",

        r"^lipids?$",

        r"^hormones?$",

        r"^thyroid",

        r"^urine analysis$",

        r"^macroscopy$",

        r"^microscopy$",

        r"^clinical consideration$",

        r"^sub[- ]class information$",

        r"^reference",

        r"^test(s)?$",

        r"^result(s)?$",

    ]



    GARBAGE_PATTERNS = [

        r"^\[+$",

        r"^\]+$",

        r"^[\[\]\|\*\-_]+$",

        r"^[^a-zA-Z0-9]+$",

    ]



    VALID_TEXT_RESULTS = {

        "positive",
        "negative",
        "pos",
        "neg",
        "trace",
        "normal",
        "abnormal",
        "present",
        "absent",
        "none",
        "no",
        "yes",
        "not seen",
        "yellow",
        "clear",
        "cloudy",
        "turbid",
        "a",
        "b",
        "a/b",

    }




    # =====================================================
    # PUBLIC
    # =====================================================

    def filter(
        self,
        results: List[LabResult],
    ) -> List[LabResult]:


        filtered = []


        for result in results:


            if not self._is_valid_result(
                result
            ):
                continue



            cleaned = self._clean_result(
                result
            )



            if cleaned:

                filtered.append(
                    cleaned
                )



        return self._remove_duplicates(
            filtered
        )





    # =====================================================
    # VALIDATION
    # =====================================================

    def _is_valid_result(
        self,
        result: LabResult,
    ) -> bool:


        if not result:

            return False



        test_name = self._normalize(
            result.test_name
        )


        value = self._normalize(
            result.result or ""
        )



        if not test_name or not value:

            return False



        if test_name in self.IGNORE_EXACT:

            return False



        if self._matches_name_pattern(
            test_name
        ):

            return False



        if self._looks_like_garbage(
            test_name
        ):

            return False



        if self._looks_like_garbage(
            value
        ):

            return False



        if not self._looks_like_valid_result(
            value
        ):

            return False



        if not re.search(
            r"[a-zA-Z]",
            test_name
        ):

            return False



        return True






    # =====================================================
    # CLEAN
    # =====================================================

    def _clean_result(
        self,
        result: LabResult,
    ) -> Optional[LabResult]:


        raw_name = (
            result.raw_name
        )


        test_name = self._clean_text(
            result.test_name
        )


        value = self._clean_text(
            result.result
        )


        flag = self._clean_text(
            result.flag
        )


        unit = self._clean_text(
            result.unit
        )


        reference = self._clean_text(
            result.reference
        )



        if not test_name or not value:

            return None



        flag = self._normalize_flag(
            flag
        )


        unit = self._normalize_unit(
            unit
        )


        reference = self._normalize_reference(
            reference
        )



        return LabResult(

            raw_name=raw_name,

            test_name=test_name,

            result=value,

            flag=flag,

            unit=unit,

            reference=reference,

            category=result.category,

        )






    # =====================================================
    # DUPLICATES
    # =====================================================

    def _remove_duplicates(
        self,
        results: List[LabResult],
    ) -> List[LabResult]:


        unique = []

        seen = set()



        for result in results:


            key = (

                self._normalize(
                    result.test_name
                ),

                self._normalize(
                    result.result or ""
                ),

                self._normalize(
                    result.unit or ""
                ),

            )



            if key in seen:

                continue



            seen.add(
                key
            )


            unique.append(
                result
            )



        return unique






    # =====================================================
    # RESULT CHECK
    # =====================================================

    def _looks_like_valid_result(
        self,
        value:str
    ):


        if re.fullmatch(
            r"[+-]?\d+(\.\d+)?",
            value
        ):

            return True



        if value in self.VALID_TEXT_RESULTS:

            return True



        if re.fullmatch(
            r"[<>]=?\s*\d+(\.\d+)?",
            value
        ):

            return True



        return False






    # =====================================================
    # GARBAGE
    # =====================================================

    def _looks_like_garbage(
        self,
        text:str
    ):


        clean = text.strip()


        if not clean:

            return True



        for pattern in self.GARBAGE_PATTERNS:


            if re.fullmatch(
                pattern,
                clean
            ):

                return True



        return False






    # =====================================================
    # NAME PATTERN
    # =====================================================

    def _matches_name_pattern(
        self,
        name:str
    ):


        for pattern in self.IGNORE_NAME_PATTERNS:


            if re.search(
                pattern,
                name,
                re.IGNORECASE
            ):

                return True



        return False






    # =====================================================
    # TEXT CLEAN
    # =====================================================

    @staticmethod
    def _clean_text(
        text
    ):


        if text is None:

            return None


        text = str(text).strip()


        if not text:

            return None



        return re.sub(
            r"\s+",
            " ",
            text
        )






    @staticmethod
    def _normalize(
        text:str
    ):


        return re.sub(
            r"\s+",
            " ",
            text.strip().lower()
        )






    # =====================================================
    # FLAG
    # =====================================================

    @staticmethod
    def _normalize_flag(
        flag
    ):


        if not flag:

            return None



        value = flag.lower()



        if value in ["high","h"]:

            return "High"



        if value in ["low","l"]:

            return "Low"



        return flag






    # =====================================================
    # UNIT
    # =====================================================

    @staticmethod
    def _normalize_unit(
        unit
    ):


        if not unit:

            return None



        clean = unit.replace(
            " ",
            ""
        ).lower()



        mapping = {

            "mg/dl":"mg/dL",

            "ng/ml":"ng/mL",

            "iu/l":"IU/L",

            "u/l":"U/L",

        }



        return mapping.get(
            clean,
            unit
        )






    # =====================================================
    # REFERENCE
    # =====================================================

    @staticmethod
    def _normalize_reference(
        reference
    ):


        if not reference:

            return None



        return re.sub(
            r"\s+",
            " ",
            reference.strip()
        )