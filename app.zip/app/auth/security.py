import hmac
import hashlib
import time
from typing import Optional


# =========================================================
# HMAC SIGNATURE GENERATION / VERIFICATION
# =========================================================

def generate_signature(
    device_id: str,
    timestamp: str,
    secret: str
) -> str:
    message = f"{device_id}:{timestamp}"
    signature = hmac.new(
        secret.encode(),
        message.encode(),
        hashlib.sha256
    ).hexdigest()
    return signature


def verify_signature(
    device_id: str,
    timestamp: str,
    signature: str,
    secret: str
) -> bool:
    if not device_id or not timestamp or not signature:
        return False

    expected = generate_signature(
        device_id,
        timestamp,
        secret
    )

    return hmac.compare_digest(expected, signature)


# =========================================================
# TIMESTAMP FRESHNESS CHECK (Anti-Replay)
# =========================================================

def is_timestamp_fresh(
    timestamp: str,
    max_age_seconds: int = 300  # 5 دقیقه
) -> bool:
    try:
        request_time = int(timestamp)
    except (ValueError, TypeError):
        return False

    current_time = int(time.time())
    diff = abs(current_time - request_time)

    return diff <= max_age_seconds


# =========================================================
# COMBINED VALIDATION
# =========================================================

def validate_request_signature(
    device_id: Optional[str],
    timestamp: Optional[str],
    signature: Optional[str],
    secret: str,
    max_age_seconds: int = 300
) -> tuple[bool, str]:
    """
    اعتبارسنجی کامل امضای درخواست.
    خروجی: (is_valid, error_message)
    """

    if not device_id:
        return False, "شناسه دستگاه ارسال نشده است."

    if not timestamp:
        return False, "Timestamp ارسال نشده است."

    if not signature:
        return False, "امضای درخواست ارسال نشده است."

    if not is_timestamp_fresh(timestamp, max_age_seconds):
        return False, "درخواست منقضی شده یا timestamp نامعتبر است."

    if not verify_signature(device_id, timestamp, signature, secret):
        return False, "امضای درخواست نامعتبر است."

    return True, ""