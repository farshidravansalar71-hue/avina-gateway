// تنظیمات حساب کاربری
package com.avina.health.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class UserPreferencesManager(private val context: Context) {

    companion object {
        val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_EMAIL = stringPreferencesKey("user_email")
        // کلید جدید برای آدرس عکس پروفایل
        val PROFILE_IMAGE_URI = stringPreferencesKey("profile_image_uri")

        // کلیدهای جدید برای وضعیت اشتراک/پرمیوم
        val IS_PREMIUM = booleanPreferencesKey("is_premium")
        val REMAINING_FREE_TESTS = intPreferencesKey("remaining_free_tests")
        val TOTAL_FREE_TESTS = intPreferencesKey("total_free_tests")
    }

    val isLoggedIn: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[IS_LOGGED_IN] ?: false
    }

    val userName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[USER_NAME] ?: "کاربر"
    }

    val userEmail: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[USER_EMAIL] ?: ""
    }

    // جریان (Flow) برای خواندن زنده‌ی آدرس عکس پروفایل
    val profileImageUri: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[PROFILE_IMAGE_URI]
    }

    // جریان (Flow) برای خواندن زنده‌ی وضعیت Premium
    val isPremium: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[IS_PREMIUM] ?: false
    }

    // جریان (Flow) برای تعداد آزمایش‌های رایگان باقی‌مانده
    val remainingFreeTests: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[REMAINING_FREE_TESTS] ?: 3 // مطابق FREE_ANALYSIS_LIMIT سمت سرور
    }

    val totalFreeTests: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[TOTAL_FREE_TESTS] ?: 3
    }

    // تابع ذخیره آدرس عکس در DataStore
    suspend fun saveProfileImageUri(uriString: String) {
        context.dataStore.edit { prefs ->
            prefs[PROFILE_IMAGE_URI] = uriString
        }
    }

    suspend fun saveUserName(name: String) {
        val displayName = name.ifBlank { "کاربر" }.trim()
        context.dataStore.edit { prefs ->
            prefs[USER_NAME] = displayName
        }
    }

    suspend fun saveUserSession(name: String?, email: String) {
        val displayName = when {
            !name.isNullOrBlank() -> name.trim()
            email.isNotBlank() -> email.substringBefore("@")
            else -> "کاربر"
        }

        context.dataStore.edit { prefs ->
            prefs[IS_LOGGED_IN] = true
            prefs[USER_NAME] = displayName
            prefs[USER_EMAIL] = email
        }
    }

    // تنظیم وضعیت Premium (مثلاً بعد از پرداخت موفق)
    suspend fun setPremiumStatus(isPremium: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_PREMIUM] = isPremium
        }
    }

    // به‌روزرسانی تعداد آزمایش رایگان باقی‌مانده (مثلاً بعد از هر تحلیل موفق)
    suspend fun updateRemainingFreeTests(remaining: Int) {
        context.dataStore.edit { prefs ->
            prefs[REMAINING_FREE_TESTS] = remaining
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }

    suspend fun clearUserSession() {
        clearSession()
    }
}