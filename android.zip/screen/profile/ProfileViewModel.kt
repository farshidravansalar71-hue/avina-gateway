// مدیریت تاریخچه آزمایش‌ها، تصویر پروفایل و اعلان‌های متصل به Room
package com.avina.health.screen.profile

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.avina.health.data.AvinaDatabase
import com.avina.health.data.NotificationEntity
import com.avina.health.data.UserPreferencesManager
import com.avina.health.network.LabApiClient
import com.avina.health.network.LabAnalysisResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

// مدل داده برای تاریخچه آزمایش‌ها
data class LabTestItem(
    val id: String,
    val date: String,
    val title: String,
    val reportJson: String = "" // JSON کامل گزارش برای PDF
)

class ProfileViewModel(application: Application) : AndroidViewModel(application) {
    private val userPreferencesManager = UserPreferencesManager(application)

    // اتصال به دیتابیس Room برای مدیریت یکپارچه اعلان‌ها
    private val notificationDao = AvinaDatabase.getDatabase(application).notificationDao()

    // خواندن زنده آدرس عکس از DataStore
    val profileImageUri: StateFlow<String?> = userPreferencesManager.profileImageUri
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    // وضعیت نوتیفیکیشن‌های خوانده‌نشده برای زنگوله هوم‌اسکرین
    private val _hasUnreadNotifications = MutableStateFlow(false)
    val hasUnreadNotifications: StateFlow<Boolean> = _hasUnreadNotifications.asStateFlow()

    // لیست تاریخچه آزمایش‌ها — منبع واقعی الان سرور است (GET /api/v1/lab/reports)،
    // نه چیزی که محلی روی گوشی ساخته می‌شود.
    private val _labHistoryList = MutableStateFlow<List<LabTestItem>>(emptyList())
    val labHistoryList: StateFlow<List<LabTestItem>> = _labHistoryList.asStateFlow()

    // وضعیت لودینگ/خطا برای نمایش در LabHistoryScreen (اختیاری برای UI)
    private val _isHistoryLoading = MutableStateFlow(false)
    val isHistoryLoading: StateFlow<Boolean> = _isHistoryLoading.asStateFlow()

    private val _historyErrorMessage = MutableStateFlow<String?>(null)
    val historyErrorMessage: StateFlow<String?> = _historyErrorMessage.asStateFlow()

    // لیست اعلان‌ها به صورت زنده از دیتابیس Room
    val notifications: StateFlow<List<NotificationEntity>> = notificationDao.getAllNotifications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        addNotification(
            title = "تست سیستم اعلان",
            message = "اگر این پیام را می‌بینید، یعنی ارتباط با دیتابیس Room کاملاً برقرار است."
        )
        loadLabHistory()
    }

    // =========================================================
    // بارگذاری تاریخچه از سرور
    // =========================================================

    /**
     * لیست خلاصه‌ی گزارش‌ها را از سرور می‌گیرد و labHistoryList را پر می‌کند.
     * توجه: خود لیست فقط خلاصه است (عنوان/تاریخ) — reportJson اینجا خالی
     * می‌ماند؛ برای گزارش کامل (مثلاً موقع ساخت PDF) باید fetchReportDetail
     * صدا زده شود.
     */
    fun loadLabHistory() {
        viewModelScope.launch {
            _isHistoryLoading.value = true
            _historyErrorMessage.value = null
            try {
                val response = LabApiClient.service.getUserReports()

                _labHistoryList.value = response.reports.map { summary ->
                    LabTestItem(
                        id = summary.report_id,
                        date = summary.created_at,
                        title = summary.overall_status_title?.takeIf { it.isNotBlank() }
                            ?: "گزارش آزمایش",
                        reportJson = ""
                    )
                }
            } catch (e: Exception) {
                _historyErrorMessage.value = "دریافت تاریخچه با خطا مواجه شد."
            } finally {
                _isHistoryLoading.value = false
            }
        }
    }

    /**
     * گزارش کامل یک آیتم خاص را از سرور می‌گیرد (فیلترشده طبق سطح دسترسی
     * کاربر، چون سرور خودش تصمیم می‌گیرد نه اپ). برای نمایش جزئیات یا
     * ساخت PDF از این استفاده کن؛ کالبک onResult روی همان کوروتین صدا
     * زده می‌شود، پس مستقیم قابل استفاده در UI است.
     */
    fun fetchReportDetail(
        reportId: String,
        onResult: (LabAnalysisResponse?) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val response = LabApiClient.service.getUserReport(reportId)
                onResult(response)
            } catch (e: Exception) {
                onResult(null)
            }
        }
    }

    // متد حذف آزمایش از تاریخچه — واقعاً سمت سرور هم حذف می‌کند،
    // نه فقط از لیست محلی (طبق درخواست: مثل دکمه‌ی حذف نوتیفیکیشن رفتار کند).
    fun deleteLabTestItem(id: String) {
        viewModelScope.launch {
            // خوش‌بینانه از UI حذفش می‌کنیم تا حس سریع بودن بدهد؛
            // اگر سرور خطا داد، لیست را دوباره از سرور می‌خوانیم تا
            // حالت واقعی جایگزین حالت خوش‌بینانه‌ی غلط شود.
            val previousList = _labHistoryList.value
            _labHistoryList.value = previousList.filter { it.id != id }

            try {
                LabApiClient.service.deleteUserReport(id)
            } catch (e: Exception) {
                _historyErrorMessage.value = "حذف گزارش با خطا مواجه شد."
                loadLabHistory()
            }
        }
    }

    // متد اضافه کردن آزمایش ساده (بدون گزارش JSON)
    fun addLabTestItem(title: String, date: String) {
        addLabTestWithReport(title, date, "")
    }

    // متد اضافه کردن آزمایش با گزارش کامل JSON (برای PDF)
    //
    // نکته: از وقتی labHistoryList به سرور وصل شده، معمولاً لازم نیست این
    // متد را دستی صدا بزنی — بعد از هر تحلیل موفق (OcrTestScreen)، همان
    // گزارش از قبل توی دیتابیس سرور ذخیره شده و با loadLabHistory() دوباره
    // می‌آید. این متد را فقط برای درج آنی/محلی (مثلاً قبل از رفرش از سرور)
    // نگه داشتم.
    fun addLabTestWithReport(title: String, date: String, reportJson: String) {
        val newItem = LabTestItem(
            id = System.currentTimeMillis().toString(),
            date = date,
            title = title,
            reportJson = reportJson
        )
        _labHistoryList.value = listOf(newItem) + _labHistoryList.value

        _hasUnreadNotifications.value = true

        addNotification(
            title = "آزمایش جدید ثبت شد",
            message = "آزمایش '$title' با موفقیت ثبت و تحلیل شد."
        )
    }

    // متد اضافه کردن اعلان جدید به دیتابیس Room
    fun addNotification(title: String, message: String) {
        viewModelScope.launch {
            val entity = NotificationEntity(
                title = title,
                message = message,
                timestamp = System.currentTimeMillis()
            )
            notificationDao.insertNotification(entity)
            _hasUnreadNotifications.value = true
        }
    }

    // حذف اعلان از دیتابیس Room
    fun deleteNotification(notification: NotificationEntity) {
        viewModelScope.launch {
            notificationDao.deleteNotification(notification)
        }
    }

    // وقتی کاربر روی زنگوله کلیک کرد، نقطه قرمز پاک می‌شود
    fun markNotificationsAsRead() {
        _hasUnreadNotifications.value = false
    }

    fun updateProfileImage(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.filesDir, "profile_image.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()

                val permanentUriString = Uri.fromFile(file).toString()
                userPreferencesManager.saveProfileImageUri(permanentUriString)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}