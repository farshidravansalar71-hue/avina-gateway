from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database.session import get_db
from app.database.models import User, Subscription
from app.auth.dependencies import get_current_admin

class UserUpdateRequest(BaseModel):
    email: Optional[str] = None
    is_active: Optional[bool] = None
    is_premium: Optional[bool] = None
    premium_plan: Optional[str] = None
    

router = APIRouter(prefix="/api/v1/admin/users", tags=["Admin Users"])


@router.get("/")
def get_all_users(
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    """
    دریافت لیست کلیه کاربران سیستم (مختص ادمین)
    """
    total = db.query(User).count()
    users = db.query(User).offset(skip).limit(limit).all()

    return {
        "total_count": total,
        "users": [
            {
                "id": u.id,
                "public_id": u.public_id,
                "email": u.email,
                "is_admin": u.is_admin,
                "is_active": u.is_active,
                "is_premium": u.is_premium,
                "premium_plan": u.premium_plan,
                "premium_expires_at": u.premium_expires_at,
                "created_at": u.created_at
            }
            for u in users
        ]
    }


@router.get("/{user_id}")
def get_user_detail(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    """
    دریافت جزئیات یک کاربر توسط ادمین
    """

    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="کاربر یافت نشد"
        )

    return {
        "id": user.id,
        "public_id": user.public_id,
        "email": user.email,
        "is_admin": user.is_admin,
        "is_active": user.is_active,
        "is_premium": user.is_premium,
        "premium_plan": user.premium_plan,
        "premium_started_at": user.premium_started_at,
        "premium_expires_at": user.premium_expires_at,
        "created_at": user.created_at
    }


@router.post("/{user_id}/grant-premium")
def grant_premium_access(
    user_id: int,
    plan_name: str = "monthly",
    days: int = 30,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    
    """
    اعطای اشتراک پریمیوم دستی به کاربر مشخص
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد.")

    now = datetime.utcnow()
    expires = now + timedelta(days=days)

    user.is_premium = True
    user.premium_plan = plan_name
    user.premium_started_at = now
    user.premium_expires_at = expires

    # ثبت در سابقه اشتراک‌ها
    subscription = Subscription(
        user_id=user.id,
        plan=plan_name,
        price=0.00,
        status="active",
        started_at=now,
        expires_at=expires
    )
    db.add(subscription)
    db.commit()

    return {
        "message": f"اشتراک پریمیوم با موفقیت برای کاربر {user.public_id} فعال شد.",
        "expires_at": expires
    }

@router.patch("/{user_id}/toggle-active")
def toggle_user_active(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="کاربر یافت نشد"
        )

    user.is_active = not user.is_active

    db.commit()
    db.refresh(user)

    return {
        "message": "وضعیت کاربر تغییر کرد",
        "user_id": user.id,
        "is_active": user.is_active
    }



@router.delete("/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):

    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="کاربر یافت نشد"
        )

    if user.is_admin is True:
        raise HTTPException(
            status_code=403,
            detail="حذف ادمین مجاز نیست"
        )

    db.delete(user)
    db.commit()

    return {
        "message": "کاربر حذف شد",
        "user_id": user_id
    }
    


@router.patch("/{user_id}")
def update_user(
    user_id: int,
    data: UserUpdateRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):

    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="کاربر یافت نشد"
        )

    if data.email is not None:
        user.email = data.email

    if data.is_active is not None:
        user.is_active = data.is_active

    if data.is_premium is not None:
        user.is_premium = data.is_premium

    if data.premium_plan is not None:
        user.premium_plan = data.premium_plan

    db.commit()
    db.refresh(user)

    return {
        "message": "اطلاعات کاربر بروزرسانی شد",
        "user_id": user.id
    }