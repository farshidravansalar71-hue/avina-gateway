package com.avina.health.ocr

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.network.ChartItemDto
import com.avina.health.network.ImageCompressor
import com.avina.health.network.ImportantFindingDto
import com.avina.health.network.LabAnalysisResponse
import com.avina.health.network.LabApiClient
import com.avina.health.network.LabResultDto
import com.avina.health.network.SmartRecommendationDto
import com.avina.health.ui.theme.AppTheme
import com.avina.health.screen.profile.ProfileViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import androidx.compose.foundation.Image
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.scale
import com.avina.health.R

@Composable
fun OcrTestScreen(
    onBackClick: () -> Unit,
    profileViewModel: ProfileViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var analysisResponse by remember {
        mutableStateOf<LabAnalysisResponse?>(null)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var isProcessing by remember {
        mutableStateOf(false)
    }

    var hasStartedPicker by remember {
        mutableStateOf(false)
    }

    fun processImage(uri: Uri) {

        if (isProcessing) {
            return
        }

        scope.launch {

            isProcessing = true
            errorMessage = ""
            analysisResponse = null

            try {

                val imageBytes =
                    withContext(Dispatchers.IO) {
                        ImageCompressor.compress(
                            context = context,
                            uri = uri
                        )
                    }

                if (imageBytes.isEmpty()) {
                    throw IllegalStateException(
                        "تصویر فشرده‌شده خالی است."
                    )
                }

                val requestBody =
                    imageBytes.toRequestBody(
                        contentType = "image/jpeg".toMediaType()
                    )

                val imagePart =
                    MultipartBody.Part.createFormData(
                        name = "image",
                        filename = "lab_image.jpg",
                        body = requestBody
                    )

                val response =
                    withContext(Dispatchers.IO) {
                        LabApiClient.service.analyzeLabImage(
                            image = imagePart
                        )
                    }

                analysisResponse = response

                if (!response.success) {
                    errorMessage =
                        response.message ?: "تحلیل تصویر انجام نشد."
                } else {
                    // گزارش تازه از قبل روی سرور ذخیره شده (create_lab_report در
                    // /analyze) — کافیست تاریخچه را دوباره از سرور بخوانیم تا
                    // اگر کاربر بعداً به تب تاریخچه برود، همین آزمایش آنجا هم باشد.
                    profileViewModel.loadLabHistory()
                }

            } catch (exception: Exception) {

                errorMessage =
                    buildErrorMessage(
                        title = "خطا در ارسال و تحلیل تصویر",
                        exception = exception
                    )

            } finally {
                isProcessing = false
            }
        }
    }

    val imagePicker =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->

            if (uri == null) {
                errorMessage = "تصویری انتخاب نشد."
            } else {
                processImage(uri)
            }
        }

    LaunchedEffect(Unit) {
        if (!hasStartedPicker) {
            hasStartedPicker = true
            imagePicker.launch("image/*")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {

        if (isProcessing) {
            AnalysisLoadingContent()
        } else {
            AnalysisResultContent(
                response = analysisResponse,
                errorMessage = errorMessage,
                onRetryClick = {
                    errorMessage = ""
                    hasStartedPicker = false
                    imagePicker.launch("image/*")
                }
            )
        }
    }
}
@Composable
private fun AnalysisResultContent(
    response: LabAnalysisResponse?,
    errorMessage: String,
    onRetryClick: () -> Unit
) {

    val report = response?.report

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        // امتیاز سلامت + وضعیت کلی
        //
        // نکته: بعد از فیکس سمت سرور (report_access.py)، برای کاربر رایگان
        // آبجکت health_score دیگر null نمی‌شود — فقط فیلد score داخلش
        // null می‌شود (label و description همچنان می‌مانند طبق تصمیم
        // محصولی: "رایگان باید وضعیت کلی را ببیند، نه عدد دقیق را").
        // پس شرط درست، چک‌کردن healthScore?.score است، نه خودِ healthScore.
        report?.health_summary?.let { summary ->

            val healthScore = summary.health_score

            if (healthScore != null && healthScore.score != null) {

                // کاربر Premium — عدد دقیق نمایش داده می‌شود
                HealthScoreCard(
                    score = healthScore.score,
                    label = healthScore.label,
                    description = healthScore.description ?: "",
                    overallTitle = summary.overall_status.title,
                    overallDescription = summary.overall_status.description
                )

            } else {

                // کاربر Free — فقط برچسب کلی، بدون عدد جعلی یا صفر
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        Text(
                            text = "وضعیت کلی سلامت",
                            color = AppTheme.colors.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        healthScore?.label?.takeIf { it.isNotBlank() }?.let { label ->
                            Text(
                                text = label,
                                color = AppTheme.colors.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (summary.overall_status.title.isNotBlank()) {
                            Text(
                                text = summary.overall_status.title,
                                color = AppTheme.colors.textPrimary,
                                fontSize = 16.sp
                            )
                        }

                        Text(
                            text = "امتیاز سلامت و تحلیل کامل در نسخه Pro فعال است.",
                            color = AppTheme.colors.textPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // موارد نیازمند توجه
        if (report != null && report.important_findings.isNotEmpty()) {
            AttentionSection(items = report.important_findings)
        }

        // نتایج آزمایش (جدول کامل)
        if (report != null && report.lab_results.isNotEmpty()) {

            Text(
                text = "نتایج آزمایش",
                color = AppTheme.colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            report.lab_results.forEach { test ->
                LabTestCard(test = test)
            }
        }

        // پیشنهادهای هوشمند
        if (report != null && report.smart_recommendations.isNotEmpty()) {
            RecommendationsSection(items = report.smart_recommendations)
        }

        // چارت‌ها
        if (report != null && report.charts.available_tests.isNotEmpty()) {
            ChartsSection(charts = report.charts.available_tests)
        }

        // خطا
        if (errorMessage.isNotBlank()) {

            Text(
                text = errorMessage,
                color = AppTheme.colors.textPrimary,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )

            Button(
                onClick = onRetryClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "انتخاب تصویر دیگر")
            }
        }

        // پاسخ خالی (بدون نتایج و بدون خطا)
        if (
            report != null &&
            report.lab_results.isEmpty() &&
            response.message != null &&
            errorMessage.isBlank()
        ) {

            Text(
                text = response.message,
                color = AppTheme.colors.textPrimary,
                fontSize = 15.sp
            )

            Button(
                onClick = onRetryClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "انتخاب تصویر دیگر")
            }
        }

        if (report != null) {
            Spacer(modifier = Modifier.height(10.dp))

            val context = androidx.compose.ui.platform.LocalContext.current
            val scope = rememberCoroutineScope()
            var isPremiumUser by remember { mutableStateOf(false) }

            LaunchedEffect(Unit) {
                try {
                    val status = com.avina.health.network.LabApiClient.service.getUserStatus()
                    isPremiumUser = status.isPremium
                } catch (e: Exception) {
                    // در صورت خطا، فرض می‌کنیم کاربر رایگان است
                }
            }

            Button(
                onClick = {
                    scope.launch {
                        try {
                            com.avina.health.pdf.PdfGenerator.init(context)
                            val file = withContext(Dispatchers.IO) {
                                com.avina.health.pdf.PdfGenerator.generateReport(
                                    context = context,
                                    report = report,
                                    userName = "کاربر",
                                    isPremium = isPremiumUser
                                )
                            }

                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                file
                            )

                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "application/pdf")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }

                            context.startActivity(intent)

                        } catch (e: Exception) {
                            android.widget.Toast.makeText(
                                context,
                                "خطا در ساخت PDF: ${e.message}",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "دریافت گزارش PDF")
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun HealthScoreCard(
    score: Int,
    label: String,
    description: String,
    overallTitle: String,
    overallDescription: String
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Text(
                text = "امتیاز سلامت",
                color = AppTheme.colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "$score از 100 ($label)",
                color = AppTheme.colors.textPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            if (description.isNotBlank()) {
                Text(
                    text = description,
                    color = AppTheme.colors.textPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }

            if (overallTitle.isNotBlank()) {
                Text(
                    text = overallTitle,
                    color = AppTheme.colors.textPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (overallDescription.isNotBlank()) {
                Text(
                    text = overallDescription,
                    color = AppTheme.colors.textPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        }
    }
}

@Composable
private fun AttentionSection(
    items: List<ImportantFindingDto>
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

        Text(
            text = "موارد نیازمند توجه",
            color = AppTheme.colors.textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        items.forEach { item ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {

                    Text(
                        text = item.test_name.ifBlank { item.title },
                        color = AppTheme.colors.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    item.value?.let { v ->
                        Text(
                            text = "مقدار: $v",
                            color = AppTheme.colors.textPrimary,
                            fontSize = 14.sp
                        )
                    }

                    item.description?.takeIf { it.isNotBlank() }?.let { desc ->
                        Text(
                            text = desc,
                            color = AppTheme.colors.textPrimary,
                            fontSize = 14.sp,
                            lineHeight = 21.sp
                        )
                    }

                    item.status?.let { status ->
                        Text(
                            text = "وضعیت: $status",
                            color = AppTheme.colors.textPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LabTestCard(
    test: LabResultDto
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {

            // اسم فارسی اگه موجود بود نمایش داده بشه، وگرنه اسم انگلیسی
            Text(
                text = test.persian_name?.takeIf { it.isNotBlank() } ?: test.name,
                color = AppTheme.colors.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )

            // اسم انگلیسی رو زیر اسم فارسی کوچیک‌تر نشون بده
            if (!test.persian_name.isNullOrBlank()) {
                Text(
                    text = test.name,
                    color = AppTheme.colors.textSecondary,
                    fontSize = 12.sp
                )
            }

            Text(
                text = "نتیجه: ${test.value ?: "-"}",
                color = AppTheme.colors.textPrimary,
                fontSize = 15.sp
            )

            Text(
                text = "واحد: ${test.unit?.takeIf { it.isNotBlank() } ?: "-"}",
                color = AppTheme.colors.textPrimary,
                fontSize = 14.sp
            )

            Text(
                text = "محدوده مرجع: ${test.reference?.takeIf { it.isNotBlank() } ?: "-"}",
                color = AppTheme.colors.textPrimary,
                fontSize = 14.sp
            )
            // توضیح آموزشی فارسی (اگه موجود بود)
            test.description?.takeIf { it.isNotBlank() }?.let { desc ->
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = AppTheme.colors.textSecondary.copy(alpha = 0.2f)
                )
                Text(
                    text = desc,
                    color = AppTheme.colors.textSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
            test.flag?.takeIf { it.isNotBlank() }?.let { flag ->
                Text(
                    text = "پرچم: $flag",
                    color = AppTheme.colors.textPrimary,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun RecommendationsSection(
    items: List<SmartRecommendationDto>
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

        Text(
            text = "پیشنهاد هوشمند",
            color = AppTheme.colors.textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        items.forEach { item ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {

                    Text(
                        text = item.title,
                        color = AppTheme.colors.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (item.description.isNotBlank()) {
                        Text(
                            text = item.description,
                            color = AppTheme.colors.textPrimary,
                            fontSize = 14.sp,
                            lineHeight = 21.sp
                        )
                    }

                    Text(
                        text = "اولویت: ${item.priority}",
                        color = AppTheme.colors.textPrimary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ChartsSection(
    charts: List<ChartItemDto>
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

        HorizontalDivider()

        Text(
            text = "روند آزمایش‌ها",
            color = AppTheme.colors.textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        charts.forEach { chart ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {

                    Text(
                        text = chart.test_name,
                        color = AppTheme.colors.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "مقدار: ${chart.value ?: "-"} ${chart.unit ?: ""}",
                        color = AppTheme.colors.textPrimary,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

private fun buildErrorMessage(
    title: String,
    exception: Throwable
): String {
    val message =
        exception.message?.takeIf { it.isNotBlank() } ?: "خطای نامشخص"

    return "$title:\n\n$message"
}