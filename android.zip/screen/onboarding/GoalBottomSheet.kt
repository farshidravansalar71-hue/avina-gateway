package com.avina.health.screen.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


@Composable
fun GoalSelector(
    goal: String,
    onClick: () -> Unit
) {

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {

        Text(
            text = "هدف استفاده",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF13294B)
        )


        Spacer(
            modifier = Modifier.height(8.dp)
        )


        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .background(
                    Color(0xFFF8FAFF),
                    RoundedCornerShape(18.dp)
                )
                .border(
                    1.dp,
                    Color(0xFFD9E2F2),
                    RoundedCornerShape(18.dp)
                )
                .clickable {
                    onClick()
                }
                .padding(horizontal = 16.dp),

            contentAlignment = Alignment.CenterEnd
        ) {

            Text(
                text = goal,
                color = Color(0xFF13294B),
                fontSize = 15.sp
            )

        }

    }

}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalBottomSheet(

    onDismiss: () -> Unit,

    onSelected: (String) -> Unit

) {


    ModalBottomSheet(

        onDismissRequest = onDismiss,

        containerColor = Color.White,

        shape = RoundedCornerShape(
            topStart = 28.dp,
            topEnd = 28.dp
        )

    ) {


        Column(

            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),

            verticalArrangement = Arrangement.spacedBy(12.dp)

        ) {


            Text(

                text = "هدف استفاده از آوین طب",

                fontSize = 20.sp,

                fontWeight = FontWeight.Bold,

                color = Color(0xFF13294B)

            )


            Text(

                text = "یکی از گزینه‌ها را انتخاب کنید",

                fontSize = 14.sp,

                color = Color.Gray

            )


            Spacer(
                modifier = Modifier.height(8.dp)
            )


            GoalItem(
                text = "تحلیل آزمایش خون",
                onClick = {
                    onSelected("تحلیل آزمایش خون")
                }
            )


            GoalItem(
                text = "پیگیری روند سلامتی",
                onClick = {
                    onSelected("پیگیری روند سلامتی")
                }
            )


            GoalItem(
                text = "دریافت پیشنهادهای هوشمند",
                onClick = {
                    onSelected("دریافت پیشنهادهای هوشمند")
                }
            )


            Spacer(
                modifier = Modifier.height(20.dp)
            )

        }

    }

}



@Composable
private fun GoalItem(

    text: String,

    onClick: () -> Unit

) {


    Box(

        modifier = Modifier
            .fillMaxWidth()
            .height(55.dp)
            .background(
                Color(0xFFF8FAFF),
                RoundedCornerShape(16.dp)
            )
            .border(
                1.dp,
                Color(0xFFD9E2F2),
                RoundedCornerShape(16.dp)
            )
            .clickable {
                onClick()
            }
            .padding(horizontal = 16.dp),

        contentAlignment = Alignment.CenterEnd

    ) {


        Text(

            text = text,

            fontSize = 15.sp,

            color = Color(0xFF13294B)

        )

    }

}