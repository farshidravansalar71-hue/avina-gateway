package com.avina.health.ocr

import android.content.Context
import android.net.Uri
import android.util.Log
import com.avina.health.network.ImageCompressor
import com.avina.health.network.LabAnalysisResponse
import com.avina.health.network.LabApiClient
import com.avina.health.network.LabApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Repository مربوط به تحلیل آزمایش.
 *
 * مسیر:
 *
 * Uri
 * ↓
 * ImageCompressor
 * ↓
 * ByteArray
 * ↓
 * Multipart
 * ↓
 * LabApiService
 * ↓
 * Server
 */
class LabRepository(
    private val context: Context,
    private val api: LabApiService = LabApiClient.service
) {

    suspend fun analyzeImage(
        uri: Uri
    ): Result<LabAnalysisResponse> {

        return withContext(Dispatchers.IO) {

            try {

                Log.d(
                    "AVINA_API",
                    "Starting image analysis..."
                )

                /*
                 * فشرده‌سازی تصویر
                 */
                val compressedImage =
                    ImageCompressor.compress(
                        context = context,
                        uri = uri
                    )

                Log.d(
                    "AVINA_API",
                    "Image compressed. Size=${compressedImage.size} bytes"
                )

                if (compressedImage.isEmpty()) {

                    throw IllegalStateException(
                        "تصویر فشرده‌شده خالی است."
                    )
                }

                /*
                 * تبدیل ByteArray به RequestBody
                 */
                val requestBody =
                    compressedImage.toRequestBody(
                        contentType =
                            "image/jpeg".toMediaType()
                    )

                /*
                 * ساخت Multipart
                 */
                val imagePart =
                    MultipartBody.Part.createFormData(
                        name = "image",
                        filename =
                            "lab_${System.currentTimeMillis()}.jpg",
                        body = requestBody
                    )

                Log.d(
                    "AVINA_API",
                    "Multipart created. Sending request to server..."
                )

                /*
                 * ارسال به سرور
                 */
                val response =
                    api.analyzeLabImage(
                        image = imagePart
                    )

                Log.d(
                    "AVINA_API",
                    "Server response received. " +
                            "success=${response.success}, " +
                            "reportId=${response.reportId}"
                )

                Result.success(response)

            } catch (exception: Exception) {

                Log.e(
                    "AVINA_API",
                    "Upload failed",
                    exception
                )

                Result.failure(
                    exception
                )
            }
        }
    }
}