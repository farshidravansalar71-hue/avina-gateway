package com.avina.health.network

import kotlinx.serialization.Serializable

/**
 * خلاصه‌ی یک گزارش برای نمایش در لیست تاریخچه.
 * معادل کلاینت LabReportSummary سمت سرور (app/models/lab_models.py).
 */
@Serializable
data class LabReportSummaryDto(
    val report_id: String,
    val created_at: String,
    val overall_status_title: String? = null,
    val tests_count: Int = 0
)

/**
 * پاسخ GET /api/v1/lab/reports
 */
@Serializable
data class LabReportListResponse(
    val success: Boolean = true,
    val reports: List<LabReportSummaryDto> = emptyList()
)

/**
 * پاسخ DELETE /api/v1/lab/reports/{reportId}
 */
@Serializable
data class DeleteReportResponse(
    val success: Boolean,
    val message: String? = null
)