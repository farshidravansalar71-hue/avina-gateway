package com.avina.health.screen.pdf

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.avina.health.network.AvinaReportDto
import com.avina.health.pdf.PdfGenerator
import com.avina.health.screen.profile.LabTestItem
import com.avina.health.screen.profile.ProfileViewModel
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

@Composable
fun PdfHistoryScreen(
    profileViewModel: ProfileViewModel = viewModel(),
    isPremium: Boolean = false,
    userName: String = "کاربر"
) {
    val testHistoryList by profileViewModel.labHistoryList.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isGenerating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    if (testHistoryList.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = null,
                    tint = AppTheme.colors.textSecondary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "هنوز آزمایشی ثبت نشده است",
                    fontSize = 16.sp,
                    color = AppTheme.colors.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "بعد از ارسال تصویر آزمایش، گزارش اینجا نمایش داده می‌شود",
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary
                )
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {

            if (isGenerating) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = PrimaryBlue
                )
            }

            if (errorMessage.isNotBlank()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                items(testHistoryList, key = { it.id }) { test ->
                    PdfHistoryCard(
                        test = test,
                        onPdfClick = {
                            if (test.reportJson.isBlank()) {
                                errorMessage = "این آزمایش گزارش PDF ندارد."
                                return@PdfHistoryCard
                            }

                            scope.launch {
                                isGenerating = true
                                errorMessage = ""
                                try {
                                    val report = Json {
                                        ignoreUnknownKeys = true
                                    }.decodeFromString(
                                        AvinaReportDto.serializer(),
                                        test.reportJson
                                    )

                                    PdfGenerator.init(context)

                                    val file = withContext(Dispatchers.IO) {
                                        PdfGenerator.generateReport(
                                            context = context,
                                            report = report,
                                            userName = userName,
                                            isPremium = isPremium
                                        )
                                    }

                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )

                                    val intent = android.content.Intent(
                                        android.content.Intent.ACTION_VIEW
                                    ).apply {
                                        setDataAndType(uri, "application/pdf")
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }

                                    context.startActivity(intent)

                                } catch (e: Exception) {
                                    errorMessage = "خطا در ساخت PDF: ${e.message}"
                                } finally {
                                    isGenerating = false
                                }
                            }
                        }
                    )
                }

                item { Spacer(modifier = Modifier.height(20.dp)) }
            }
        }
    }
}

@Composable
private fun PdfHistoryCard(
    test: LabTestItem,
    onPdfClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(12.dp),
                color = PrimaryBlue.copy(alpha = 0.15f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = test.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppTheme.colors.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = test.date,
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // دکمه PDF
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(
                        enabled = test.reportJson.isNotBlank(),
                        onClick = onPdfClick
                    ),
                shape = RoundedCornerShape(10.dp),
                color = if (test.reportJson.isNotBlank())
                    PrimaryBlue.copy(alpha = 0.12f)
                else
                    AppTheme.colors.textSecondary.copy(alpha = 0.1f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "دریافت PDF",
                        tint = if (test.reportJson.isNotBlank())
                            PrimaryBlue
                        else
                            AppTheme.colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "PDF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (test.reportJson.isNotBlank())
                            PrimaryBlue
                        else
                            AppTheme.colors.textSecondary
                    )
                }
            }
        }
    }
}