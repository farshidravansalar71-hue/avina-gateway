package com.avina.health.utils

import androidx.compose.runtime.compositionLocalOf

// این یک متغیر سراسریه که توی کل اپلیکیشن در دسترس خواهد بود
val LocalLanguage = compositionLocalOf { "fa" }