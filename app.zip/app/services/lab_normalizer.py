import re
from decimal import Decimal, InvalidOperation


ALLOWED_FLAGS = {
    "",
    "H",
    "L",
    "HH",
    "LL",
    "*"
}



def normalize_spaces(value):
    return re.sub(
        r"\s+",
        " ",
        str(value).strip()
    )



def clean_string(value):

    if value is None:
        return ""

    return normalize_spaces(
        value
    )



def is_scalar_numeric_value(value):

    if (
        not isinstance(value, str)
        or not value.strip()
    ):
        return False

    try:

        Decimal(
            value.strip()
        )

        return True

    except (
        InvalidOperation,
        ValueError
    ):

        return False



def extract_flag_and_value(
    raw_value,
    raw_flag=""
):

    value = clean_string(
        raw_value
    )

    flag = clean_string(
        raw_flag
    ).upper()


    flag_map = {

        "HIGH": "H",
        "LOW": "L",

        "H": "H",
        "L": "L",

        "HH": "HH",
        "LL": "LL",

        "*": "*"

    }


    flag = flag_map.get(
        flag,
        ""
    )


    if not value:

        return "", flag



    match = re.match(
        r"^(HH|LL|H|L)\s+(.+)$",
        value,
        re.I
    )


    if match:

        return (
            match.group(2).strip(),
            match.group(1).upper()
        )



    match = re.match(
        r"^(HIGH|LOW)\s+(.+)$",
        value,
        re.I
    )


    if match:

        detected = (
            "H"
            if match.group(1).upper() == "HIGH"
            else "L"
        )


        return (
            match.group(2).strip(),
            detected
        )



    match = re.match(
        r"^(.+?)\s+(HH|LL|H|L)$",
        value,
        re.I
    )


    if (
        match
        and is_scalar_numeric_value(
            match.group(1).strip()
        )
    ):

        return (
            match.group(1).strip(),
            match.group(2).upper()
        )



    match = re.match(
        r"^(.+?)\s*\*$",
        value
    )


    if (
        match
        and is_scalar_numeric_value(
            match.group(1).strip()
        )
    ):

        return (
            match.group(1).strip(),
            "*"
        )



    return value, flag




def normalize_test(
    test
):

    value, flag = extract_flag_and_value(
        test.get(
            "value",
            ""
        ),
        test.get(
            "flag",
            ""
        )
    )


    if flag not in ALLOWED_FLAGS:

        flag = ""



    return {

        "name": clean_string(
            test.get(
                "name",
                ""
            )
        ),

        "value": value,

        "unit": clean_string(
            test.get(
                "unit",
                ""
            )
        ),

        "reference": clean_string(
            test.get(
                "reference",
                ""
            )
        ),

        "flag": flag

    }




def normalize_lab_json(
    raw_lab_json
):

    print(
        "\n========== SERVER NORMALIZER ==========\n"
    )


    if (
        not isinstance(
            raw_lab_json,
            dict
        )
        or
        not isinstance(
            raw_lab_json.get("tests"),
            list
        )
    ):

        raise ValueError(
            "RAW LAB JSON معتبر نیست"
        )



    clean_tests = []



    for test in raw_lab_json["tests"]:

        if not isinstance(
            test,
            dict
        ):

            continue



        normalized = normalize_test(
            test
        )


        if normalized["name"]:

            clean_tests.append(
                normalized
            )



    print(
        "Clean tests:",
        len(clean_tests)
    )


    return {

        "tests": clean_tests

    }