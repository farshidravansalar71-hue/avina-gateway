package com.avina.health.network

import kotlinx.serialization.Serializable

@Serializable
data class LabResultDto(
    val name: String,
    val persian_name: String? = null,
    val description: String? = null,
    val value: String? = null,
    val unit: String? = null,
    val reference: String? = null,
    val flag: String? = null
)

@Serializable
data class HealthScoreDto(
    val score: Int? = null,
    val label: String = "",
    val description: String? = null
)

@Serializable
data class OverallStatusDto(
    val status: String = "",
    val title: String = "",
    val description: String = ""
)

@Serializable
data class HealthSummaryDto(
    val health_score: HealthScoreDto? = null,
    val overall_status: OverallStatusDto = OverallStatusDto()
)

@Serializable
data class ImportantFindingDto(
    val title: String = "",
    val test_name: String = "",
    val value: String? = null,
    val status: String? = null,
    val description: String? = null
)

@Serializable
data class SmartRecommendationDto(
    val title: String = "",
    val description: String = "",
    val priority: String = "medium"
)

@Serializable
data class ChartItemDto(
    val test_name: String = "",
    val value: String? = null,
    val unit: String? = null,
    val history: List<Map<String, String>> = emptyList()
)

@Serializable
data class ChartContainerDto(
    val available_tests: List<ChartItemDto> = emptyList()
)

@Serializable
data class ReportInfoDto(
    val type: String = "laboratory_report",
    val version: String = "1.0"
)

@Serializable
data class AvinaReportDto(
    val report_info: ReportInfoDto = ReportInfoDto(),
    val health_summary: HealthSummaryDto = HealthSummaryDto(),
    val important_findings: List<ImportantFindingDto> = emptyList(),
    val smart_recommendations: List<SmartRecommendationDto> = emptyList(),
    val charts: ChartContainerDto = ChartContainerDto(),
    val lab_results: List<LabResultDto> = emptyList()
)

@Serializable
data class LabAnalysisResponse(
    val success: Boolean,
    val reportId: String? = null,
    val report: AvinaReportDto? = null,
    val message: String? = null,
    val remainingFreeTests: Int? = null,
    val isPremium: Boolean? = null
)
@Serializable
data class UserStatusResponse(
    val isPremium: Boolean = false,
    val remainingFreeTests: Int? = null,
    val totalFreeTests: Int = 3
)