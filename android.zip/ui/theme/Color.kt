package com.avina.health.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
// رنگ بک‌گراند اصلی (آبی بسیار ملایم و روشن)
val SoftBackground = Color(0xFFF4F7FC)

// رنگ کارت‌ها و المان‌های روی صفحه
val CardWhite = Color(0xFFFFFFFF)

// رنگ‌های اصلی و برند (آبی پزشکی و ملایم)
val PrimaryBlue = Color(0xFF2A65F0)       // رنگ دکمه اصلی و دکمه +
val SecondarySoftBlue = Color(0xFFE8EEFF) // بک‌گراند آیکون‌ها و بخش‌های متایزی
val PrimaryBlueDark = Color(0xFF1E3A8A)   // برای متن‌های مهم و هدرها

// رنگ وضعیت نتایج آزمایش
val StatusGreen = Color(0xFF10B981)  // برای وضعیت خوب/نرمال
val StatusRed = Color(0xFFEF4444)    // برای وضعیت غیرطبیعی/خطر
val StatusYellow = Color(0xFFF59E0B) // برای وضعیت مرزی

// رنگ متن‌ها
val TextPrimary = Color(0xFF1F2937)
val TextSecondary = Color(0xFF6B7280)