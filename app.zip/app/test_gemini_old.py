import sys
import os

# اضافه کردن مسیر پروژه به پایتون
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.ai.gemini_client import GeminiClient

def main():
    print("در حال اتصال به جمینی...")
    try:
        client = GeminiClient()
        
        # نمونه دیتای آزمایش برای تست
        sample_lab = {
            "patient_age": 30,
            "tests": [
                {"name": "WBC", "value": "11.5", "unit": "10^3/uL", "ref_range": "4.5-11.0"},
                {"name": "Hb", "value": "13.2", "unit": "g/dL", "ref_range": "13.5-17.5"}
            ]
        }
        
        print("در حال ارسال درخواست تحلیل آزمایش...")
        analysis = client.analyze_lab(sample_lab)
        
        print("\n--- پاسخ هوش مصنوعی ---")
        print(analysis)
        print("-----------------------")
        
    except Exception as e:
        print(f"خطا در اجرا: {e}")

if __name__ == "__main__":
    main()