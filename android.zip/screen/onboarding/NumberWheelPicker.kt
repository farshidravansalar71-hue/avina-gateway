package com.avina.health.screen.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest


@Composable
fun NumberWheelPicker(

    title: String,

    value: Int,

    range: IntRange,

    onValueChange: (Int) -> Unit

) {


    Column(
        modifier = Modifier.fillMaxWidth()
    ) {


        Text(

            text = title,

            fontSize = 15.sp,

            fontWeight = FontWeight.Bold,

            color = Color(0xFF13294B)

        )


        Spacer(
            modifier = Modifier.height(8.dp)
        )


        val numbers = remember {
            range.toList()
        }


        val startIndex =
            numbers.indexOf(value)
                .coerceAtLeast(0)



        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = startIndex
        )



        LaunchedEffect(listState) {

            snapshotFlow {

                listState.firstVisibleItemIndex

            }
                .collectLatest { index ->

                    val newValue =
                        numbers.getOrNull(index)


                    if(newValue != null &&
                        newValue != value
                    ){

                        onValueChange(newValue)

                    }

                }

        }



        Box(

            modifier = Modifier

                .fillMaxWidth()

                .height(105.dp)

                .clip(
                    RoundedCornerShape(18.dp)
                )

                .border(

                    1.dp,

                    Color(0xFFD9E2F2),

                    RoundedCornerShape(18.dp)

                )

                .background(
                    Color(0xFFF8FAFF)
                ),

            contentAlignment = Alignment.Center

        ){



            LazyColumn(

                state = listState,

                modifier = Modifier.fillMaxSize(),

                horizontalAlignment = Alignment.CenterHorizontally,

                contentPadding = PaddingValues(
                    vertical = 35.dp
                )

            ){


                items(numbers){ item ->


                    Box(

                        modifier = Modifier

                            .fillMaxWidth()

                            .height(34.dp),

                        contentAlignment = Alignment.Center

                    ){

                        Text(

                            text = item.toString(),

                            fontSize = if(item == value)
                                28.sp
                            else
                                18.sp,


                            fontWeight =
                                if(item == value)
                                    FontWeight.Bold
                                else
                                    FontWeight.Normal,


                            color =
                                if(item == value)
                                    Color(0xFF2E6BFF)
                                else
                                    Color(0xFF9AA8BC)

                        )

                    }

                }


            }


        }

    }

}