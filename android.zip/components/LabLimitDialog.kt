//لیمیت تعداد آزمایش
package com.avina.health.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
// دیالوگ اتمام سهمیه رایگان آزمایش‌ها و پیشنهاد خرید اشتراک / پرداخت تک‌تست
@Composable
fun LabLimitDialog(
    onDismiss: () -> Unit,
    onBuySingleTest: () -> Unit,
    onBuyPremium: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = AppTheme.colors.cardBackground, // هماهنگ با رنگ کارت‌ها در دارک و لایت
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "🧪",
                    fontSize = 42.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "پایان آزمایش‌های رایگان",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = AppTheme.colors.textPrimary // هماهنگ با رنگ متن اصلی
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "شما ۵ آزمایش رایگان خود را استفاده کرده‌اید. برای تحلیل این برگه آزمایش، می‌توانید یکی از گزینه‌های زیر را انتخاب کنید:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppTheme.colors.textSecondary, // هماهنگ با رنگ متن ثانویه
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onBuySingleTest,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryBlue // استفاده از رنگ اصلی اپ
                    )
                ) {
                    Text(
                        text = "تحلیل این آزمایش - ۵۰,۰۰۰ تومان",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onBuyPremium,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = PrimaryBlue
                    )
                ) {
                    Text(
                        text = "خرید اشتراک پرمیوم (دسترسی نامحدود)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = onDismiss) {
                    Text(
                        text = "انصراف",
                        color = AppTheme.colors.textSecondary
                    )
                }
            }
        }
    }
}