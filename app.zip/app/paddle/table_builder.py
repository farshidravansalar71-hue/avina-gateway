from typing import List, Dict, Any, Optional
from statistics import mean

# کلمات هدر رایج در برگه‌های آزمایش (برای تشخیص شروع هر بخش/جدول)
HEADER_KEYWORDS = {
    "test": "Test",
    "result": "Result",
    "unit": "Unit",
    "method": "Method",
    "referencerange": "ReferenceRange",
    "reference range": "ReferenceRange",
    "normal range": "ReferenceRange",
}

# پرچم‌های رایج نتیجه (برای علامت‌گذاری خارج از محدوده)
FLAG_TOKENS = {"h", "high", "l", "low", "positive", "pos", "negative", "neg", "abnormal"}


def get_center(box: List[int]) -> tuple[float, float]:
    x1, y1, x2, y2 = box
    return (x1 + x2) / 2, (y1 + y2) / 2


def get_height(box: List[int]) -> float:
    return box[3] - box[1]


def cluster_rows(
    items: List[Dict[str, Any]],
    y_tolerance_ratio: float = 0.6
) -> List[List[Dict[str, Any]]]:
    """گروه‌بندی آیتم‌ها بر اساس مرکز Y به ردیف‌های افقی."""
    if not items:
        return []

    avg_height = mean(i["h"] for i in items)
    y_tol = avg_height * y_tolerance_ratio

    items_sorted = sorted(items, key=lambda i: i["cy"])

    rows: List[List[Dict[str, Any]]] = []
    for item in items_sorted:
        placed = False
        for row in rows:
            row_cy = mean(r["cy"] for r in row)
            if abs(item["cy"] - row_cy) <= y_tol:
                row.append(item)
                placed = True
                break
        if not placed:
            rows.append([item])

    for row in rows:
        row.sort(key=lambda i: i["cx"])

    rows.sort(key=lambda row: mean(r["cy"] for r in row))
    return rows


def normalize_header_text(text: str) -> str:
    return text.strip().lower().replace(" ", "")


def find_header_rows(rows: List[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """
    ردیف‌هایی که حداقل ۲ کلمه‌ی هدر شناخته‌شده (Test/Result/Unit/...) در خودشون دارند
    را به‌عنوان "هدر یک بخش جدید" شناسایی می‌کند و موقعیت هر ستون را برمی‌گرداند.
    """
    header_rows = []
    for row_index, row in enumerate(rows):
        matched_columns = []
        for item in row:
            norm = normalize_header_text(item["text"])
            if norm in HEADER_KEYWORDS:
                matched_columns.append({
                    "name": HEADER_KEYWORDS[norm],
                    "cx": item["cx"]
                })
        if len(matched_columns) >= 2:
            header_rows.append({
                "row_index": row_index,
                "columns": matched_columns,
                "cy": mean(r["cy"] for r in row)
            })
    return header_rows


def assign_row_to_header(
    row: List[Dict[str, Any]],
    header: Dict[str, Any]
) -> Dict[str, str]:
    """هر آیتم یک ردیف را به نزدیک‌ترین ستون تعریف‌شده در هدر مربوطه نسبت می‌دهد."""
    columns = header["columns"]
    result: Dict[str, str] = {}

    for item in row:
        closest = min(columns, key=lambda c: abs(item["cx"] - c["cx"]))
        col_name = closest["name"]
        existing = result.get(col_name, "")
        result[col_name] = (existing + " " + item["text"]).strip()

    return result


def detect_flag(result_text: str, unit_text: str = "") -> Optional[str]:
    """
    تشخیص می‌دهد آیا مقدار نتیجه به‌صورت صریح دارای پرچم خارج از محدوده است
    (مثل حروف H/L چسبیده به عدد، یا کلمات Positive/Negative).
    """
    lower = result_text.strip().lower()
    tokens = lower.replace("(", " ").replace(")", " ").split()
    for token in tokens:
        cleaned = token.strip("+-.,")
        if cleaned in FLAG_TOKENS:
            return cleaned.upper()
    return None


def build_lab_table(paddle_result: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    نقطه‌ی ورود اصلی.
    خروجی خام PaddleOCR (لیست صفحات) را می‌گیرد و لیستی از بخش‌ها را برمی‌گرداند؛
    هر بخش شامل عنوان بخش (در صورت وجود) و لیست ردیف‌های جدول آن بخش است.
    """
    all_sections: List[Dict[str, Any]] = []

    for page in paddle_result:
        raw = page.get("raw", {})
        res = raw.get("res", raw)

        texts = res.get("rec_texts", [])
        boxes = res.get("rec_boxes", [])

        if not texts or not boxes or len(texts) != len(boxes):
            continue

        items = [
            {
                "text": t,
                "box": b,
                "cx": get_center(b)[0],
                "cy": get_center(b)[1],
                "h": get_height(b),
            }
            for t, b in zip(texts, boxes)
        ]

        rows = cluster_rows(items)
        header_rows = find_header_rows(rows)

        if not header_rows:
            # اگر هیچ هدری پیدا نشد، همه را به‌عنوان یک بخش بدون‌عنوان با ستون‌بندی حدسی برمی‌گردانیم
            continue

        for h_idx, header in enumerate(header_rows):
            start = header["row_index"] + 1
            end = (
                header_rows[h_idx + 1]["row_index"]
                if h_idx + 1 < len(header_rows)
                else len(rows)
            )

            section_title = None
            # عنوان بخش معمولاً در ردیف(های) بلافاصله قبل از هدر قرار دارد
            if header["row_index"] > 0:
                prev_row = rows[header["row_index"] - 1]
                prev_text = " ".join(i["text"] for i in prev_row)
                # اگر ردیف قبلی خودش هدر بخش دیگری نبود، به‌عنوان تیتر بخش در نظر می‌گیریم
                if not any(
                    normalize_header_text(t) in HEADER_KEYWORDS
                    for t in prev_text.split()
                ):
                    section_title = prev_text

            section_rows = []
            for row in rows[start:end]:
                row_dict = assign_row_to_header(row, header)
                if "Test" not in row_dict or "Result" not in row_dict:
                    continue  # ردیف ناقص/نویز را نادیده می‌گیریم

                flag = detect_flag(row_dict.get("Result", ""), row_dict.get("Unit", ""))
                if flag:
                    row_dict["Flag"] = flag

                section_rows.append(row_dict)

            if section_rows:
                all_sections.append({
                    "section": section_title,
                    "columns": [c["name"] for c in header["columns"]],
                    "rows": section_rows,
                })

    return all_sections


if __name__ == "__main__":
    import json
    # from app.paddle.paddle_table_engine import PaddleTableEngine
    # engine = PaddleTableEngine()
    # result = engine.analyze("test_images/lab1.jpg")
    # sections = build_lab_table(result)
    # print(json.dumps(sections, ensure_ascii=False, indent=2))
    pass