from dataclasses import dataclass
from typing import List, Optional
import re

from app.ocr.table_structure import LogicalTable


# =========================================================
# DATA MODEL
# =========================================================


@dataclass
class LabResult:
    raw_name: str
    test_name: str
    result: Optional[str]
    flag: Optional[str]
    unit: Optional[str]
    method: Optional[str]
    reference: Optional[str]
    comment: Optional[str]
    category: Optional[str]


# =========================================================
# PARSER
# =========================================================


class LabResultParser:

    IGNORE_WORDS = {
        "test", "tests", "result", "results", "flag",
        "unit", "units", "reference",
        "reference range",
        "reference interval",
        "reference range",
        "clinical consideration",
        "sub class information",
        "sub-class information",
        "pattern",
        "pattern a",
        "pattern b",
        "macroscopy",
        "microscopy",
    }


    CATEGORY_KEYWORDS = {

        "thyroid": [
            "tsh",
            "free t4",
            "free t3",
            "thyroid",
        ],

        "lipid": [
            "ldl",
            "hdl",
            "cholesterol",
            "cholestrol",
            "triglyceride",
            "apob",
            "vldl",
            "lpa",
            "lipid",
        ],

        "hormone": [
            "ferritin",
            "insulin",
            "cortisol",
            "hormone",
        ],

        "urine": [
            "protein",
            "glucose",
            "blood",
            "nitrite",
            "ketone",
            "keton",
            "bilirubin",
            "urobilinogen",
            "wbc",
            "rbc",
            "epithelial",
            "mucous",
            "bacteria",
            "casts",
            "crystals",
            "yeast",
            "color",
            "appearance",
            "appereance",
            "ph",
            "specific gravity",
        ],
    }


    UNITS = {
        "mg/dl",
        "ng/ml",
        "ng/dl",
        "iu/l",
        "u/l",
        "mmol/l",
        "µg/dl",
        "ug/dl",
        "pg/ml",
        "pg/dl",
        "g/dl",
        "pmol/l",
        "mg/l",
        "g/l",
        "fl",
        "pg",
        "%",
        "miu/l",
    }


    METHOD_WORDS = {
        "ecl",
        "elisa",
        "colorimetry",
        "chemiluminescence",
        "immunoassay",
        "biochemistry",
    }


    FLAG_WORDS = {
        "high": "High",
        "h": "High",
        "low": "Low",
        "l": "Low",
    }


    # =====================================================
    # PUBLIC
    # =====================================================


    def parse(
        self,
        tables: List[LogicalTable]
    ) -> List[LabResult]:

        results = []

        for table in tables:

            table_category = self._detect_category(
                table.title or ""
            )

            for row in table.rows:

                item = self._parse_row(
                    row.cells,
                    fallback_category=table_category
                )

                if item:
                    results.append(item)

        return results



    # =====================================================
    # ROW PARSER
    # =====================================================


    def _parse_row(
        self,
        cells,
        fallback_category=None
    ) -> Optional[LabResult]:


        texts = [
            c.text.strip()
            for c in cells
            if c.text.strip()
        ]


        if len(texts) < 2:
            return None


        raw_name = texts[0]

        test_name = raw_name


        if self._should_ignore(test_name):
            return None



        remaining = texts[1:]



        if len(remaining) == 1:

            return LabResult(

                raw_name=raw_name,

                test_name=test_name,

                result=remaining[0],

                flag=None,

                unit=None,

                method=None,

                reference=None,

                comment=None,

                category=
                    self._detect_category(test_name)
                    or fallback_category,
            )



        result = None
        unit = None
        method = None
        reference = None
        flag = None

        comments = []



        for token in remaining:


            if (
                reference is None
                and
                self._looks_like_reference(token)
            ):

                reference = token
                continue



            if (
                unit is None
                and
                self._looks_like_unit(token)
            ):

                unit = token
                continue



            if (
                method is None
                and
                self._looks_like_method(token)
            ):

                method = token
                continue



            if result is None:

                result = token
                continue



            token_flag = self._extract_flag_from_token(token)


            if token_flag:

                flag = token_flag

            else:

                comments.append(token)



        if result is None:
            return None



        return LabResult(

            raw_name=raw_name,

            test_name=test_name,

            result=result,

            flag=flag,

            unit=unit,

            method=method,

            reference=reference,

            comment=
                " | ".join(comments)
                if comments
                else None,

            category=
                self._detect_category(test_name)
                or fallback_category,
        )



    # =====================================================
    # CLASSIFIERS
    # =====================================================


    @staticmethod
    def _normalize_micro(
        text: str
    ) -> str:

        return text.replace(
            "μ",
            "µ"
        )



    def _looks_like_unit(
        self,
        text: str
    ) -> bool:


        clean = (
            self._normalize_micro(text)
            .strip()
            .lower()
            .replace(" ", "")
        )


        if clean in self.UNITS:
            return True


        return (
            clean.endswith("/l")
            or clean.endswith("/dl")
            or clean.endswith("/ml")
        )



    @staticmethod
    def _looks_like_reference(
        text: str
    ) -> bool:


        clean = text.strip()


        patterns = [

            r"^\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?$",

            r"^[<>]=?\s*\d+(?:\.\d+)?$",

            r"(male|female)\s*:\s*\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?",

        ]


        return any(
            re.search(
                p,
                clean,
                re.IGNORECASE
            )
            for p in patterns
        )



    def _looks_like_method(
        self,
        text: str
    ) -> bool:

        return (
            text.strip()
            .lower()
            in self.METHOD_WORDS
        )



    # =====================================================
    # FLAG
    # =====================================================


    def _extract_flag_from_token(
        self,
        token: str
    ) -> Optional[str]:


        clean = token.strip().lower()


        if len(clean.split()) > 2:
            return None


        stripped = clean.strip(
            ":.*"
        )


        if stripped in self.FLAG_WORDS:

            return self.FLAG_WORDS[stripped]



        if re.fullmatch(
            r"\*+",
            token.strip()
        ):

            return "High"



        return None



    # =====================================================
    # IGNORE / CATEGORY
    # =====================================================


    def _should_ignore(
        self,
        text: str
    ) -> bool:


        clean = (
            text.lower()
            .strip()
        )


        if clean in self.IGNORE_WORDS:
            return True


        if len(clean) <= 1:
            return True


        return False



    def _detect_category(
        self,
        name: str
    ) -> Optional[str]:


        text = name.lower()


        for category, keys in self.CATEGORY_KEYWORDS.items():

            for key in keys:

                if key in text:

                    return category


        return None