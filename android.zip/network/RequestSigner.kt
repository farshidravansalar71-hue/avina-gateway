package com.avina.health.network

import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object RequestSigner {

    private const val HMAC_ALGORITHM = "HmacSHA256"

    fun generateSignature(
        deviceId: String,
        timestamp: String,
        secret: String
    ): String {
        return try {
            val message = "$deviceId:$timestamp"
            val secretKeySpec = SecretKeySpec(
                secret.toByteArray(Charsets.UTF_8),
                HMAC_ALGORITHM
            )
            val mac = Mac.getInstance(HMAC_ALGORITHM)
            mac.init(secretKeySpec)
            val hashBytes = mac.doFinal(message.toByteArray(Charsets.UTF_8))
            hashBytes.joinToString("") { "%02x".format(it) }
        } catch (e: NoSuchAlgorithmException) {
            throw IllegalStateException("HMAC algorithm not available", e)
        } catch (e: InvalidKeyException) {
            throw IllegalStateException("Invalid HMAC key", e)
        }
    }

    fun currentTimestamp(): String {
        return (System.currentTimeMillis() / 1000).toString()
    }
}