//تاریخچه آزمایش‌ها (تم مشکی هماهنگ با اپلیکیشن) — شامل حذف و دریافت PDF
package com.avina.health.screen.profile

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.avina.health.network.LabApiClient
import com.avina.health.pdf.PdfGenerator
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabHistoryScreen(
    viewModel: ProfileViewModel = viewModel(),
    userName: String = "کاربر",
    onBackClick: () -> Unit,
    onTestClick: (String) -> Unit = {}
) {
    val testHistoryList by viewModel.labHistoryList.collectAsState()
    val isLoading by viewModel.isHistoryLoading.collectAsState()
    val errorMessage by viewModel.historyErrorMessage.collectAsState()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // برای اینکه PDF محتوای درست (رایگان/پرمیوم) بسازد، باید بدانیم
    // کاربر فعلی پرمیوم است یا نه — همان الگویی که در OcrTestScreen هست.
    var isPremiumUser by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        try {
            val status = LabApiClient.service.getUserStatus()
            isPremiumUser = status.isPremium
        } catch (e: Exception) {
            // در صورت خطا، فرض می‌کنیم کاربر رایگان است
        }
    }

    // آیدی گزارشی که الان دارد PDF‌اش ساخته می‌شود (برای نمایش لودینگ فقط
    // روی همان کارت، نه کل صفحه) و پیام خطای مخصوص PDF (جدا از خطای لیست).
    var generatingReportId by remember { mutableStateOf<String?>(null) }
    var pdfErrorMessage by remember { mutableStateOf<String?>(null) }

    fun onPdfClick(reportId: String) {
        if (generatingReportId != null) return // یک PDF در حال ساخت کافی است

        generatingReportId = reportId
        pdfErrorMessage = null

        // برخلاف تلاش قبلی (PdfHistoryScreen) که به test.reportJson از قبل
        // پرشده تکیه می‌کرد، اینجا همیشه گزارش کامل را تازه از سرور می‌گیریم —
        // چون GET /reports فقط خلاصه برمی‌گرداند، نه محتوای کامل.
        viewModel.fetchReportDetail(reportId) { response ->
            val report = response?.report

            if (report == null) {
                generatingReportId = null
                pdfErrorMessage = "دریافت گزارش با خطا مواجه شد."
                return@fetchReportDetail
            }

            scope.launch {
                try {
                    PdfGenerator.init(context)

                    val file = withContext(Dispatchers.IO) {
                        PdfGenerator.generateReport(
                            context = context,
                            report = report,
                            userName = userName,
                            isPremium = isPremiumUser
                        )
                    }

                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )

                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    context.startActivity(intent)

                } catch (e: Exception) {
                    pdfErrorMessage = "خطا در ساخت PDF: ${e.message}"
                } finally {
                    generatingReportId = null
                }
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppTheme.colors.pageBackground,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "تاریخچه آزمایش‌ها",
                            color = AppTheme.colors.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = null,
                                tint = AppTheme.colors.textPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = AppTheme.colors.cardBackground
                    )
                )
            }
        ) { padding ->
            when {
                // حالت لودینگ: وقتی هنوز اولین جواب از سرور نرسیده
                isLoading && testHistoryList.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = PrimaryBlue)
                    }
                }

                // حالت خطا: درخواست سرور fail شده و لیستی هم نداریم که نشون بدیم
                errorMessage != null && testHistoryList.isEmpty() -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            fontSize = 14.sp,
                            color = AppTheme.colors.textSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.loadLabHistory() }) {
                            Text(text = "تلاش دوباره")
                        }
                    }
                }

                // حالت خالی: سرور جواب داد ولی کاربر هنوز هیچ آزمایشی ثبت نکرده
                testHistoryList.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "هنوز آزمایشی ثبت نشده است",
                            fontSize = 14.sp,
                            color = AppTheme.colors.textSecondary
                        )
                    }
                }

                // حالت عادی: لیست را نشان بده
                else -> {
                    Column(modifier = Modifier.fillMaxSize().padding(padding)) {

                        pdfErrorMessage?.let { msg ->
                            Text(
                                text = msg,
                                color = Color(0xFFE57373),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                            )
                        }

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item { Spacer(modifier = Modifier.height(8.dp)) }

                            items(testHistoryList, key = { it.id }) { test ->
                                LabHistoryCard(
                                    test = test,
                                    isGeneratingPdf = generatingReportId == test.id,
                                    onClick = { onTestClick(test.id) },
                                    onDeleteClick = { viewModel.deleteLabTestItem(test.id) },
                                    onPdfClick = { onPdfClick(test.id) }
                                )
                            }

                            item { Spacer(modifier = Modifier.height(20.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabHistoryCard(
    test: LabTestItem,
    isGeneratingPdf: Boolean,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onPdfClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AppTheme.colors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(12.dp),
                color = PrimaryBlue.copy(alpha = 0.15f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = test.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppTheme.colors.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = test.date,
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // دکمه‌ی PDF
            if (isGeneratingPdf) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = PrimaryBlue
                )
            } else {
                IconButton(onClick = onPdfClick) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "دریافت PDF",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // دکمه‌ی حذف — رفتار مثل حذف نوتیفیکیشن: هم از UI هم از سرور پاک می‌شود
            IconButton(onClick = onDeleteClick) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف",
                    tint = Color(0xFFE57373),
                    modifier = Modifier.size(22.dp)
                )
            }

            Icon(
                imageVector = Icons.Default.KeyboardArrowLeft,
                contentDescription = null,
                tint = AppTheme.colors.textSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}