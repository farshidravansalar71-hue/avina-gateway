from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.database.models import User, LabReport, Subscription
from app.auth.dependencies import get_current_admin


router = APIRouter(
    prefix="/api/v1/admin/dashboard",
    tags=["Admin Dashboard"]
)

print("DASHBOARD ROUTER LOADED")

@router.get("/stats")
def get_dashboard_stats(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    """
    آمار کلی سیستم برای پنل ادمین
    """

    total_users = db.query(User).count()

    active_users = (
        db.query(User)
        .filter(User.is_active == True)
        .count()
    )

    premium_users = (
        db.query(User)
        .filter(User.is_premium == True)
        .count()
    )

    total_reports = db.query(LabReport).count()

    total_subscriptions = db.query(Subscription).count()

    today = datetime.utcnow().date()

    today_signups = (
        db.query(User)
        .filter(
            User.created_at >= today
        )
        .count()
    )

    today_reports = (
        db.query(LabReport)
        .filter(
            LabReport.created_at >= today
        )
        .count()
    )


    return {
        "total_users": total_users,
        "active_users": active_users,
        "premium_users": premium_users,
        "total_reports": total_reports,
        "total_subscriptions": total_subscriptions,
        "today_signups": today_signups,
        "today_reports": today_reports
    }
    
