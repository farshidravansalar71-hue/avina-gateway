from datetime import datetime, timedelta
from typing import Optional
import jwt

from app.core.settings import settings

# استفاده از کلید مخفی موجود در settings پروژه
SECRET_KEY = getattr(settings, "JWT_SECRET_KEY", "YOUR_SUPER_SECRET_KEY_FOR_ADMIN_AVINA")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # ۲۴ ساعت اعتبار توکن ادمین


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    ساخت توکن JWT برای کاربر/ادمین
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_token(token: str) -> Optional[dict]:
    """
    اعتبارسنجی و ررمزگشایی توکن JWT
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None