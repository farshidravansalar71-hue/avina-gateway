package com.avina.health.ocr

import kotlin.math.max
import kotlin.math.min

class LabResultParser {

    private data class Token(
        val text: String,
        val centerX: Int,
        val centerY: Int,
        val left: Int,
        val right: Int,
        val top: Int,
        val bottom: Int
    ) {
        val height: Int get() = bottom - top
    }

    private data class ParsedRow(
        val tokens: List<Token>
    )

    private val ignoredWords = setOf(
        "test", "tests", "result", "results", "unit", "units",
        "flag", "reference", "interval", "reference interval",
        "lipids", "clinical", "consideration", "sub-class",
        "information", "high", "low", "normal", "abnormal", "pattern", "risk",
        "method", "biochemistry", "hormones", "urine", "analysis", "macroscopy", "microscopy",
        "confirmed", "by", "repeated", "analysis", "ecl", "colorimetry",
        "ris", "moderate", "male", "female"
    )

    fun parse(
        ocrResult: OcrResult
    ): List<LabResult> {
        val rawTokens = flattenTokens(ocrResult)
        if (rawTokens.isEmpty()) return emptyList()

        val maxRight = rawTokens.maxOfOrNull { it.right } ?: 1000
        val midX = maxRight / 2

        val leftTokens = rawTokens.filter { it.centerX < midX }
        val rightTokens = rawTokens.filter { it.centerX >= midX }

        val labResults = mutableListOf<LabResult>()

        for (columnTokens in listOf(leftTokens, rightTokens)) {
            if (columnTokens.isEmpty()) continue
            val rows = groupTokensIntoRowsByOverlap(columnTokens)
            for (row in rows) {
                val parsedItem = parseGridRow(row.tokens)
                if (parsedItem != null) {
                    labResults.add(parsedItem)
                }
            }
        }

        return labResults
    }

    private fun flattenTokens(
        ocrResult: OcrResult
    ): List<Token> {
        return ocrResult.blocks
            .flatMap { block ->
                block.lines.flatMap { line ->
                    line.elements.mapNotNull { element ->
                        val box = element.boundingBox ?: return@mapNotNull null
                        val text = element.text.trim()
                        if (text.isBlank()) return@mapNotNull null

                        Token(
                            text = text,
                            centerX = box.centerX(),
                            centerY = box.centerY(),
                            left = box.left,
                            right = box.right,
                            top = box.top,
                            bottom = box.bottom
                        )
                    }
                }
            }
    }

    private fun groupTokensIntoRowsByOverlap(
        tokens: List<Token>
    ): List<ParsedRow> {
        val sortedByTop = tokens.sortedBy { it.top }
        val rowLists = mutableListOf<MutableList<Token>>()

        for (token in sortedByTop) {
            var placed = false
            for (row in rowLists) {
                val rowTop = row.minOf { it.top }
                val rowBottom = row.maxOf { it.bottom }

                val maxTop = max(rowTop, token.top)
                val minBottom = min(rowBottom, token.bottom)
                val overlap = minBottom - maxTop

                if (overlap > 0) {
                    val minHeight = min(rowBottom - rowTop, token.height)
                    if (overlap >= minHeight * 0.4) {
                        row.add(token)
                        placed = true
                        break
                    }
                }
            }

            if (!placed) {
                rowLists.add(mutableListOf(token))
            }
        }

        return rowLists.map { rowTokens ->
            ParsedRow(tokens = rowTokens.sortedBy { it.left })
        }.sortedBy { it.tokens.minOf { t -> t.top } }
    }

    private fun parseGridRow(
        rowTokens: List<Token>
    ): LabResult? {
        val cleaned = rowTokens.filter {
            val low = it.text.lowercase().trim('*', '.', ',')
            low !in ignoredWords
        }

        if (cleaned.size < 2) return null

        var resultIndex = -1
        for (i in cleaned.indices) {
            if (isResultCandidate(cleaned[i].text)) {
                resultIndex = i
                break
            }
        }

        if (resultIndex <= 0) return null

        val nameTokens = cleaned.subList(0, resultIndex)
        val testName = nameTokens.joinToString(" ") { it.text }.cleanTestName()

        val lowerName = testName.lowercase()
        // جلوگیری از پردازش متن‌های راهنما یا ریسک به عنوان تست
        if (lowerName.contains("risk") || lowerName.contains("ris") ||
            lowerName.contains("moderate") || lowerName.contains("high") ||
            testName.isBlank() || testName.length < 2 || isUnitCandidate(testName) || isResultCandidate(testName)) {
            return null
        }

        val resultToken = cleaned[resultIndex]
        val remaining = cleaned.subList(resultIndex + 1, cleaned.size)

        var unit: String? = null
        val referenceParts = mutableListOf<String>()

        var i = 0
        while (i < remaining.size) {
            val token = remaining[i]
            val text = token.text
            val upper = text.uppercase().trim('*', '.', ',')

            if (upper in setOf("H", "L", "HIGH", "LOW", "ECL", "BIOCHEMISTRY", "COLORIMETRY")) {
                i++
                continue
            }

            if (unit == null) {
                if (isUnitCandidate(text)) {
                    unit = text
                    i++
                    continue
                } else if (i + 1 < remaining.size) {
                    val combined = "$text ${remaining[i + 1].text}"
                    val combinedNoSpace = combined.replace(Regex("""\s+"""), "").lowercase()

                    if (isMultiWordUnitCandidate(combinedNoSpace)) {
                        unit = combined
                        i += 2
                        continue
                    }
                }
            }

            referenceParts.add(text)
            i++
        }

        val reference = if (referenceParts.isNotEmpty()) {
            referenceParts.joinToString(" ").let(::normalizeReference)
        } else null

        return LabResult(
            testName = testName,
            result = normalizeResult(resultToken.text),
            unit = unit?.let(::normalizeUnit),
            reference = reference
        )
    }

    private fun isResultCandidate(value: String): Boolean {
        val clean = value.trim('*', '+', '-', ',', '.', ':', ';')
        val lower = clean.lowercase()
        if (lower in setOf("positive", "negative", "pos", "neg", "clear", "yellow", "many", "not seen")) return true
        return clean.matches(Regex("""^[+-]?\d+(?:[.,]\d+)?$"""))
    }

    private fun isUnitCandidate(value: String): Boolean {
        val u = value.lowercase().replace(Regex("""\s+"""), "")
        val standardUnits = setOf(
            "mg/dl", "ng/dl", "pg/ml", "pg/dl", "g/dl", "mmol/l", "µmol/l",
            "umol/l", "miu/l", "iu/l", "u/l", "fl", "pg", "%", "pmol/l", "ng/ml", "ug/dl"
        )
        return u in standardUnits || u.endsWith("/l") || u.endsWith("/dl")
    }

    private fun isMultiWordUnitCandidate(combinedNoSpace: String): Boolean {
        return combinedNoSpace.contains("pmol/l") ||
                combinedNoSpace.contains("micriu/ml") ||
                combinedNoSpace.contains("microiu/ml") ||
                combinedNoSpace.contains("iu/ml") ||
                combinedNoSpace.contains("mg/dl") ||
                combinedNoSpace.contains("ng/dl") ||
                combinedNoSpace.contains("ug/dl") ||
                combinedNoSpace.contains("µg/dl") ||
                combinedNoSpace.contains("miu/l") ||
                combinedNoSpace.contains("g/dl") ||
                combinedNoSpace.contains("ng/ml")
    }

    private fun normalizeResult(value: String): String {
        return value.trim('*', '+', ',', ':', ';')
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
    }

    private fun normalizeUnit(value: String): String {
        return value.trim(',', '.', ':', ';')
            .replace("mg/di", "mg/dL", ignoreCase = true)
            .replace(Regex("""pmol\s*/\s*l""", RegexOption.IGNORE_CASE), "Pmol/L")
            .replace(Regex("""micro\s*iu\s*/\s*ml""", RegexOption.IGNORE_CASE), "micro IU/ml")
            .replace(Regex("""ug\s*/\s*dl""", RegexOption.IGNORE_CASE), "ug/dL")
    }

    private fun normalizeReference(value: String): String {
        return value.trim(',', '.', ':', ';')
            .replace("≤", "<=").replace("≥", ">=")
            .replace("−", "-").replace("–", "-").replace("—", "-")
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
    }

    private fun String.cleanTestName(): String {
        return replace(Regex("""\s+"""), " ")
            .trim(' ', ':', '-', '|', '/', '\\')
    }
}