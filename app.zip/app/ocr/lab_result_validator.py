from typing import List
import re


class LabResultValidator:
    """
    اعتبارسنجی نتایج OCR شده آزمایش
    با پشتیبانی از نام‌های مشابه OCR
    """

    def __init__(self):

        self.test_aliases = {


            # =====================
            # Lipid
            # =====================

            "LDL Cholesterol": [
                "ldl cholesterol",
                "ldl chol",
                "ldl",
                "low density lipoprotein",
            ],


            "HDL Cholesterol": [
                "hdl cholesterol",
                "hdl chol",
                "hdl",
                "high density lipoprotein",
            ],


            "VLDL Cholesterol": [
                "vldl cholesterol",
                "vldl",
            ],


            "Cholesterol, Total": [
                "cholesterol total",
                "total cholesterol",
                "cholesterol, total",
                "cholestrol total",
            ],


            "Triglycerides": [
                "triglycerides",
                "triglyceride",
                "tg",
            ],


            "Non HDL Chol. (LDL+VLDL)": [
                "non hdl",
                "non hdl chol",
                "non hdl cholesterol",
            ],


            "apoB100-calc": [
                "apob100-calc",
                "apob",
                "apob100",
            ],


            "LDL-R (Real)-C": [
                "ldl-r",
                "ldl r",
                "ldl real",
            ],


            "Lp(a) Cholesterol": [
                "lp(a)",
                "lpa cholesterol",
                "lipoprotein a",
            ],


            "IDL Cholesterol": [
                "idl cholesterol",
                "idl",
            ],


            "Remnant Lipo. (IDL+VLDL3)": [
                "remnant lipo",
                "idl+vldl3",
            ],


            "HDL-2 (Most Protective)": [
                "hdl-2",
                "hdl 2",
            ],


            "HDL-3 (Less Protective)": [
                "hdl-3",
                "hdl 3",
            ],


            "VLDL-3 (Small Remnant)": [
                "vldl-3",
                "vldl 3",
            ],



            # =====================
            # Thyroid
            # =====================

            "TSH": [
                "tsh",
            ],

            "Free T4": [
                "free t4",
                "ft4",
            ],

            "Free T3": [
                "free t3",
                "ft3",
            ],



            # =====================
            # Liver
            # =====================

            "SGOT(AST)": [
                "sgot",
                "ast",
            ],


            "SGPT (ALT)": [
                "sgpt",
                "alt",
            ],


            "Alkaline Phosphatase": [
                "alkaline phosphatase",
                "alp",
            ],



            # =====================
            # Iron
            # =====================

            "Fe": [
                "fe",
                "iron",
            ],

            "TIBC": [
                "tibc",
            ],

            "Ferritin": [
                "ferritin",
            ],



            # =====================
            # Urine
            # =====================

            "Protein": [
                "protein",
            ],

            "Glucose": [
                "glucose",
            ],

            "Blood": [
                "blood",
                "occult blood",
            ],

            "Ketone": [
                "ketone",
                "keton",
            ],

            "Nitrite": [
                "nitrite",
            ],

            "Bilirubin": [
                "bilirubin",
            ],

            "Urobilinogen": [
                "urobilinogen",
            ],

        }



    def _clean(
        self,
        text: str
    ) -> str:

        text = text.lower()

        text = re.sub(
            r"[^a-z0-9]+",
            " ",
            text
        )

        return (
            text
            .strip()
        )



    def validate(
        self,
        results: List
    ) -> List:


        validated = []


        for item in results:


            if isinstance(item, dict):

                test_name = item.get(
                    "test_name",
                    ""
                )

            else:

                test_name = getattr(
                    item,
                    "test_name",
                    ""
                )


            if not test_name:
                continue



            cleaned_name = self._clean(
                test_name
            )



            matched = False



            for canonical, aliases in self.test_aliases.items():

                for alias in aliases:

                    if (
                        self._clean(alias)
                        in
                        cleaned_name
                    ):

                        # اصلاح نام نهایی
                        if isinstance(item, dict):

                            item["test_name"] = canonical

                        else:

                            item.test_name = canonical


                        matched = True
                        break


                if matched:
                    break



            if matched:

                validated.append(
                    item
                )



        return validated