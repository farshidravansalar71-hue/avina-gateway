import logging

from fastapi import FastAPI

from app.core.logging_config import setup_logging
from app.api.lab import router as lab_router
from app.core.middleware import register_middlewares
from app.database.init_db import init_db  # <--- وارد کردن تابع ساخت جدول

# ایمپورت روترهای جدید ادمین
from app.admin.auth import router as admin_auth_router
from app.admin.users import router as admin_users_router
from app.admin.dashboard import router as admin_dashboard_router
from app.admin.reports import router as admin_reports_router

setup_logging()


logger = logging.getLogger(__name__)
print("LOGGER TEST")
logger.warning("WARNING TEST")
logger.error("ERROR TEST")

app = FastAPI(
    title="Avina Lab API",
    version="1.0.0",
    description="Backend API for Avina Health laboratory analysis.",
)


# =========================
# Startup Event: Init DB Tables (ساخت خودکار جدول‌ها هنگام شروع سرور)
# =========================
@app.on_event("startup")
async def startup_event():
    try:
        init_db()
        logger.info("Database tables initialized successfully on startup.")
        print(">>> Database tables initialized successfully on startup. <<<")
    except Exception as e:
        logger.exception(f"Failed to initialize database tables: {e}")


register_middlewares(app)


logger.info(
    "Avina server started"
)


# ثبت روترهای اصلی و ادمین
app.include_router(
    lab_router
)
app.include_router(admin_auth_router)
app.include_router(admin_users_router)
app.include_router(admin_dashboard_router)
app.include_router(admin_reports_router)


@app.get("/")
async def root():

    logger.info(
        "Root endpoint called"
    )

    return {
        "success": True,
        "service": "Avina Lab API",
        "version": "1.0.0",
    }


@app.get("/health")
async def health():

    return {
        "status": "ok",
    }