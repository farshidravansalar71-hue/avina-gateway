from datetime import datetime
from uuid import uuid4

from sqlalchemy.orm import Session

from app.core.settings import settings

from app.database.models import (
    User,
    Device,
    DeviceUsage,
    LabReport,
    LabTestDictionary,
)


# =========================================================
# USER
# =========================================================

def get_user_by_public_id(
    db: Session,
    public_id: str,
) -> User | None:

    return (
        db.query(User)
        .filter(
            User.public_id == public_id
        )
        .first()
    )


def get_user_by_email(
    db: Session,
    email: str,
) -> User | None:

    return (
        db.query(User)
        .filter(
            User.email == email
        )
        .first()
    )


def create_user(
    db: Session,
) -> User:

    user = User(
        public_id=f"usr_{uuid4().hex}",
        is_premium=False,
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return user



# =========================================================
# DEVICE
# =========================================================

def get_device(
    db: Session,
    device_id: str,
) -> Device | None:

    return (
        db.query(Device)
        .filter(
            Device.device_id == device_id
        )
        .first()
    )



def get_user_by_device_id(
    db: Session,
    device_id: str,
) -> User | None:

    device = get_device(
        db,
        device_id
    )

    if not device:
        return None

    return (
        db.query(User)
        .filter(
            User.id == device.user_id
        )
        .first()
    )



def create_device(
    db: Session,
    user_id: int,
    device_id: str,
    model: str | None = None,
    manufacturer: str | None = None,
    os_version: str | None = None,
    app_version: str | None = None,
) -> Device:

    device = Device(
        device_id=device_id,
        user_id=user_id,
        model=model,
        manufacturer=manufacturer,
        os_version=os_version,
        app_version=app_version,
        last_seen=datetime.utcnow()
    )

    db.add(device)
    db.commit()
    db.refresh(device)

    return device



def update_device_seen(
    db: Session,
    device: Device,
) -> Device:

    device.last_seen = datetime.utcnow()

    db.commit()
    db.refresh(device)

    return device



# =========================================================
# DEVICE USAGE
# =========================================================

def get_device_usage(
    db: Session,
    device_id: int,
) -> DeviceUsage | None:

    return (
        db.query(DeviceUsage)
        .filter(
            DeviceUsage.device_id == device_id
        )
        .first()
    )



def create_device_usage(
    db: Session,
    device_id: int,
) -> DeviceUsage:

    usage = DeviceUsage(
        device_id=device_id,
        free_analysis_count=0
    )

    db.add(usage)
    db.commit()
    db.refresh(usage)

    return usage



def can_use_free_analysis(
    usage: DeviceUsage | None,
) -> bool:
    """
    بررسی سهمیه رایگان دستگاه
    """

    if usage is None:
        return True

    return (
        usage.free_analysis_count
        <
        settings.FREE_ANALYSIS_LIMIT
    )



def increase_usage(
    db: Session,
    usage: DeviceUsage,
) -> DeviceUsage:

    usage.free_analysis_count += 1
    usage.last_analysis_at = datetime.utcnow()

    db.commit()
    db.refresh(usage)

    return usage



# =========================================================
# LAB REPORT
# =========================================================

def create_lab_report(
    db: Session,
    user_id: int,
    report_id: str,
    lab_results_json: str | None = None,
    analysis_json: str | None = None,
) -> LabReport:

    report = LabReport(
        report_id=report_id,
        user_id=user_id,
        lab_results_json=lab_results_json,
        analysis_json=analysis_json,
    )

    db.add(report)
    db.commit()
    db.refresh(report)

    return report



def get_lab_report(
    db: Session,
    report_id: str,
) -> LabReport | None:

    return (
        db.query(LabReport)
        .filter(
            LabReport.report_id == report_id
        )
        .first()
    )



def get_user_reports(
    db: Session,
    user_id: int,
) -> list[LabReport]:

    return (
        db.query(LabReport)
        .filter(
            LabReport.user_id == user_id
        )
        .order_by(
            LabReport.created_at.desc()
        )
        .all()
    )



def update_lab_report(
    db: Session,
    report: LabReport,
    lab_results_json: str | None = None,
    analysis_json: str | None = None,
) -> LabReport:

    if lab_results_json is not None:
        report.lab_results_json = lab_results_json

    if analysis_json is not None:
        report.analysis_json = analysis_json

    db.commit()
    db.refresh(report)

    return report



def delete_lab_report(
    db: Session,
    report: LabReport,
) -> None:

    db.delete(report)
    db.commit()



# =========================================================
# LAB TEST DICTIONARY (CACHE)
# =========================================================

def get_lab_test_dict_batch(
    db: Session,
    test_keys: list[str],
) -> dict:
    """
    گرفتن دسته‌ای اطلاعات تست‌ها از دیتابیس برای بهینه‌سازی سرعت
    """
    results = (
        db.query(LabTestDictionary)
        .filter(LabTestDictionary.test_key.in_(test_keys))
        .all()
    )
    
    return {item.test_key: item for item in results}


def save_lab_test_dict_batch(
    db: Session,
    new_items: list[dict],
) -> None:
    """
    ذخیره دسته‌ای تست‌های جدیدی که از جمنای گرفته شده در دیتابیس (کش)
    """
    for item in new_items:
        key = item.get("test_key")
        persian_name = item.get("persian_name")
        description = item.get("description")

        if not key or not persian_name:
            continue
        
        existing = (
            db.query(LabTestDictionary)
            .filter(LabTestDictionary.test_key == key)
            .first()
        )

        if not existing:
            db_item = LabTestDictionary(
                test_key=key,
                persian_name=persian_name,
                description=description,
            )
            db.add(db_item)
        else:
            # اگر وجود داشت اما نام فارسی خالی بود، به‌روزرسانی کن
            if not existing.persian_name and persian_name:
                existing.persian_name = persian_name
            if not existing.description and description:
                existing.description = description

    db.commit()