package com.avina.health.ocr

import kotlin.math.abs
import kotlin.math.max

class LabTestExtractor {

    /**
     * خروجی نهایی Extractor.
     *
     * هدف:
     * فقط نام آزمایش + نتیجه
     *
     * مثال:
     * {
     *     "label": "Vitamin D",
     *     "value": "18"
     * }
     */
    data class ExtractedItem(
        val label: String,
        val value: String
    )

    /**
     * Token استخراج‌شده از OCR به همراه موقعیت آن.
     */
    private data class Token(
        val text: String,
        val centerX: Int,
        val centerY: Int,
        val left: Int,
        val right: Int,
        val top: Int,
        val bottom: Int
    ) {
        val width: Int
            get() = max(1, right - left)

        val height: Int
            get() = max(1, bottom - top)
    }

    /**
     * یک ردیف منطقی از جدول آزمایش.
     */
    private data class Row(
        val tokens: List<Token>
    ) {
        val centerY: Int
            get() {
                val top = tokens.minOf { it.top }
                val bottom = tokens.maxOf { it.bottom }
                return (top + bottom) / 2
            }
    }

    /**
     * Candidate برای مقدار آزمایش.
     */
    private data class ResultCandidate(
        val index: Int,
        val token: Token,
        val score: Double
    )

    /**
     * کلمات عمومی که نباید بخشی از نام آزمایش شوند.
     */
    private val ignoredWords = setOf(
        "test",
        "tests",
        "result",
        "results",
        "unit",
        "units",
        "flag",
        "reference",
        "interval",
        "range",
        "reference interval",
        "lipids",
        "clinical",
        "consideration",
        "sub-class",
        "information",
        "high",
        "low",
        "normal",
        "abnormal",
        "pattern",
        "risk",
        "method",
        "biochemistry",
        "hormones",
        "urine",
        "analysis",
        "macroscopy",
        "microscopy",
        "confirmed",
        "by",
        "repeated",
        "ecl",
        "colorimetry",
        "ris",
        "moderate",
        "male",
        "female",
        "micro",
        "milli",
        "nano",
        "pico"
    )

    /**
     * Headerهای رایج برگه آزمایش.
     */
    private val headerWords = setOf(
        "test",
        "tests",
        "result",
        "results",
        "unit",
        "units",
        "flag",
        "reference",
        "interval",
        "range",
        "reference interval",
        "parameter",
        "parameters",
        "investigation",
        "value"
    )

    /**
     * کلمات مربوط به Flag / Risk.
     */
    private val riskWords = setOf(
        "risk",
        "ris",
        "high",
        "low",
        "moderate",
        "normal",
        "abnormal",
        "borderline",
        "h",
        "l"
    )

    /**
     * ورودی اصلی Extractor.
     */
    fun extract(
        ocrResult: OcrResult
    ): List<ExtractedItem> {

        val tokens = flattenTokens(ocrResult)

        if (tokens.isEmpty()) {
            return emptyList()
        }

        val rows = groupTokensIntoRows(tokens)

        if (rows.isEmpty()) {
            return emptyList()
        }

        val results = mutableListOf<ExtractedItem>()

        for (row in rows) {
            val item = extractItemFromRow(row)

            if (item != null) {
                results.add(item)
            }
        }

        return removeDuplicates(results)
    }

    /**
     * تبدیل OcrResult به Token.
     */
    private fun flattenTokens(
        ocrResult: OcrResult
    ): List<Token> {

        return ocrResult.blocks
            .flatMap { block ->
                block.lines.flatMap { line ->
                    line.elements.mapNotNull { element ->

                        val box = element.boundingBox
                            ?: return@mapNotNull null

                        val text = element.text.trim()

                        if (text.isBlank()) {
                            return@mapNotNull null
                        }

                        Token(
                            text = text,
                            centerX = box.centerX(),
                            centerY = box.centerY(),
                            left = box.left,
                            right = box.right,
                            top = box.top,
                            bottom = box.bottom
                        )
                    }
                }
            }
            .sortedWith(
                compareBy<Token> { it.centerY }
                    .thenBy { it.left }
            )
    }

    /**
     * ساخت Row بر اساس موقعیت عمودی Tokenها.
     */
    private fun groupTokensIntoRows(
        tokens: List<Token>
    ): List<Row> {

        if (tokens.isEmpty()) {
            return emptyList()
        }

        val rows = mutableListOf<MutableList<Token>>()

        for (token in tokens.sortedBy { it.centerY }) {

            var bestRow: MutableList<Token>? = null
            var bestDistance = Double.MAX_VALUE

            for (row in rows) {

                val rowTop: Double =
                    row.minOf { it.top }.toDouble()

                val rowBottom: Double =
                    row.maxOf { it.bottom }.toDouble()

                val rowCenter: Double =
                    (rowTop + rowBottom) / 2.0

                val averageHeight: Double =
                    row.map { it.height.toDouble() }
                        .average()
                        .coerceAtLeast(1.0)

                val tokenCenterY: Double =
                    token.centerY.toDouble()

                val tokenHeight: Double =
                    token.height.toDouble()

                val verticalDistance: Double =
                    abs(
                        tokenCenterY - rowCenter
                    )

                val referenceHeight: Double =
                    if (tokenHeight > averageHeight) {
                        tokenHeight
                    } else {
                        averageHeight
                    }

                val allowedDistance: Double =
                    if (referenceHeight * 0.60 > 4.0) {
                        referenceHeight * 0.60
                    } else {
                        4.0
                    }

                if (verticalDistance <= allowedDistance) {

                    if (verticalDistance < bestDistance) {
                        bestDistance = verticalDistance
                        bestRow = row
                    }
                }
            }

            if (bestRow != null) {
                bestRow.add(token)
            } else {
                rows.add(
                    mutableListOf(token)
                )
            }
        }

        return rows
            .map { rowTokens ->
                Row(
                    tokens = rowTokens.sortedBy { it.left }
                )
            }
            .sortedBy { it.centerY }
    }

    /**
     * استخراج Label + Value از یک Row.
     */
    private fun extractItemFromRow(
        row: Row
    ): ExtractedItem? {

        if (row.tokens.size < 2) {
            return null
        }

        val tokens = row.tokens
            .filterNot { isIgnoredToken(it.text) }
            .filterNot { isStandaloneReferenceSymbol(it.text) }

        if (tokens.size < 2) {
            return null
        }

        if (isNonTestRow(tokens)) {
            return null
        }

        val unitIndex = tokens.indexOfFirst { token ->
            isUnitCandidate(token.text) || isMultiWordUnitCandidate(token.text)
        }

        val candidates = tokens
            .mapIndexedNotNull { index, token ->

                if (!isResultCandidate(token.text)) {
                    return@mapIndexedNotNull null
                }

                if (unitIndex != -1 && index > unitIndex) {
                    return@mapIndexedNotNull null
                }

                ResultCandidate(
                    index = index,
                    token = token,
                    score = scoreResultCandidate(
                        token,
                        index,
                        tokens
                    )
                )
            }
            .sortedByDescending { it.score }

        if (candidates.isEmpty()) {
            return null
        }

        val candidate = candidates.first()

        if (candidate.index <= 0) {
            return null
        }

        val nameTokens =
            tokens.subList(
                0,
                candidate.index
            )

        if (nameTokens.isEmpty()) {
            return null
        }

        val testName =
            buildTestName(nameTokens)

        if (!isValidTestName(testName)) {
            return null
        }

        if (
            isLikelyNameFragment(
                testName,
                candidate.token.text
            )
        ) {
            return null
        }

        return ExtractedItem(
            label = testName,
            value = normalizeResult(
                candidate.token.text
            )
        )
    }

    /**
     * امتیازدهی Candidateهای Value.
     */
    private fun scoreResultCandidate(
        token: Token,
        index: Int,
        tokens: List<Token>
    ): Double {

        var score = 0.0

        if (isNumericResult(token.text)) {
            score += 10.0
        }

        if (isTextResult(token.text)) {
            score += 8.0
        }

        if (isRangeResult(token.text)) {
            score += 7.0
        }

        if (index > 0) {
            score += 3.0
        }

        if (
            index > 0 &&
            tokens
                .subList(0, index)
                .any { it.text.any(Char::isLetter) }
        ) {
            score += 4.0
        }

        if (index + 1 < tokens.size) {

            val next =
                tokens[index + 1].text

            if (isUnitCandidate(next)) {
                score += 15.0
            }
        }

        if (index + 2 < tokens.size) {

            val combined =
                "${tokens[index + 1].text} " +
                        tokens[index + 2].text

            if (
                isMultiWordUnitCandidate(
                    combined
                )
            ) {
                score += 12.0
            }
        }

        if (index + 1 < tokens.size) {

            if (
                isRangeResult(
                    tokens[index + 1].text
                )
            ) {
                score += 6.0
            }
        }

        if (index + 2 < tokens.size) {

            val next = tokens[index + 1].text
            val afterNext = tokens[index + 2].text

            if (
                isUnitCandidate(next) &&
                isRangeResult(afterNext)
            ) {
                score += 12.0
            }
        }

        if (token.height <= 2) {
            score -= 3.0
        }

        return score
    }

    /**
     * ساخت نام نهایی آزمایش.
     */
    private fun buildTestName(
        tokens: List<Token>
    ): String {

        return tokens
            .filterNot {
                isUnitCandidate(it.text)
            }
            .joinToString(" ") {
                it.text
            }
            .replace(
                Regex("""\s+"""),
                " "
            )
            .trim(
                ' ',
                ':',
                '-',
                '|',
                '/',
                '\\'
            )
    }

    /**
     * اعتبارسنجی نام آزمایش.
     */
    private fun isValidTestName(
        testName: String
    ): Boolean {

        if (testName.length < 2) {
            return false
        }

        val normalized =
            testName
                .lowercase()
                .trim()

        if (normalized in ignoredWords) {
            return false
        }

        if (normalized in headerWords) {
            return false
        }

        if (normalized in riskWords) {
            return false
        }

        if (
            normalized.contains(
                "reference interval"
            )
        ) {
            return false
        }

        if (
            normalized.contains(
                "clinical consideration"
            )
        ) {
            return false
        }

        if (
            normalized.contains("risk")
        ) {
            return false
        }

        if (isResultCandidate(testName)) {
            return false
        }

        if (isUnitCandidate(testName)) {
            return false
        }

        val words = normalized.split(Regex("""\s+"""))
        val allWordsIgnored = words.all { word ->
            word in ignoredWords || word in riskWords || isUnitCandidate(word) || word.length <= 1
        }
        if (allWordsIgnored) {
            return false
        }

        if (!testName.any { it.isLetter() }) {
            return false
        }

        return true
    }

    /**
     * تشخیص Header / توضیحات / Risk.
     */
    private fun isNonTestRow(
        tokens: List<Token>
    ): Boolean {

        val rowText =
            tokens.joinToString(" ") {
                it.text
            }.lowercase()

        if (
            rowText.contains(
                "clinical consideration"
            )
        ) {
            return true
        }

        if (
            rowText.contains(
                "reference interval"
            )
        ) {
            return true
        }

        if (
            rowText.contains("risk")
        ) {
            return true
        }

        val normalizedWords =
            tokens.map {
                it.text
                    .lowercase()
                    .trim(
                        '*',
                        '.',
                        ',',
                        ':',
                        ';'
                    )
            }

        val headerCount =
            normalizedWords.count {
                it in headerWords
            }

        if (headerCount >= 2) {
            return true
        }

        val meaningfulTokens =
            tokens.filterNot {
                isResultCandidate(it.text) ||
                        isUnitCandidate(it.text)
            }

        if (meaningfulTokens.isEmpty()) {
            return true
        }

        val ignoredCount =
            meaningfulTokens.count {

                val normalized =
                    it.text
                        .lowercase()
                        .trim(
                            '*',
                            '.',
                            ',',
                            ':',
                            ';'
                        )

                normalized in ignoredWords
            }

        return ignoredCount >=
                meaningfulTokens.size
    }

    private fun isNumericResult(
        value: String
    ): Boolean {

        val clean =
            normalizeDigits(
                value.trim(
                    '*',
                    '+',
                    '-',
                    ',',
                    '.',
                    ':',
                    ';'
                )
            )

        return clean.matches(
            Regex(
                """^[+-]?\d+(?:[.,]\d+)?$"""
            )
        )
    }

    private fun isRangeResult(
        value: String
    ): Boolean {

        val clean =
            normalizeDigits(
                value
                    .trim()
                    .replace(
                        '–',
                        '-'
                    )
                    .replace(
                        '—',
                        '-'
                    )
                    .replace(
                        Regex("""\s+"""),
                        ""
                    )
            )

        return clean.matches(
            Regex(
                """^[+-]?\d+(?:[.,]\d+)?-[+-]?\d+(?:[.,]\d+)?$"""
            )
        )
    }

    private fun isTextResult(
        value: String
    ): Boolean {

        val clean =
            value
                .trim()
                .lowercase()

        return clean in setOf(
            "positive",
            "negative",
            "pos",
            "neg",
            "detectable",
            "undetectable",
            "reactive",
            "non-reactive",
            "clear",
            "yellow",
            "many",
            "not seen",
            "seen",
            "trace",
            "nil",
            "none",
            "منفی",
            "مثبت"
        )
    }

    private fun isResultCandidate(
        value: String
    ): Boolean {

        return isNumericResult(value) ||
                isRangeResult(value) ||
                isTextResult(value)
    }

    private fun isUnitCandidate(
        value: String
    ): Boolean {

        val normalized =
            value
                .lowercase()
                .replace(
                    Regex("""\s+"""),
                    ""
                )

        val units = setOf(
            "mg/dl",
            "g/dl",
            "iu/l",
            "u/l",
            "miu/ml",
            "ng/ml",
            "ng/dl",
            "pg/ml",
            "pg/dl",
            "cells/mcl",
            "cells/mcL".lowercase(),
            "cells/µl",
            "cells/ul",
            "%",
            "mmol/l",
            "µiu/ml",
            "fl",
            "pg",
            "g/l",
            "mg/l",
            "sec",
            "min",
            "10^3/ul",
            "10^3/µl",
            "10^6/ul",
            "10^6/µl",
            "pmol/l",
            "umol/l",
            "µmol/l",
            "ug/dl",
            "µg/dl",
            "iu/ml",
            "meq/l"
        )

        if (normalized in units) {
            return true
        }

        return normalized.endsWith("/l") ||
                normalized.endsWith("/dl") ||
                normalized.endsWith("/ml") ||
                normalized.endsWith("/ul") ||
                normalized.endsWith("/µl")
    }

    private fun isMultiWordUnitCandidate(
        value: String
    ): Boolean {

        val normalized =
            value
                .lowercase()
                .replace(
                    Regex("""\s+"""),
                    ""
                )

        return normalized.contains("mg/dl") ||
                normalized.contains("g/dl") ||
                normalized.contains("ng/ml") ||
                normalized.contains("ng/dl") ||
                normalized.contains("pg/ml") ||
                normalized.contains("pg/dl") ||
                normalized.contains("miu/ml") ||
                normalized.contains("µiu/ml") ||
                normalized.contains("iu/ml") ||
                normalized.contains("iu/l") ||
                normalized.contains("mmol/l") ||
                normalized.contains("pmol/l") ||
                normalized.contains("umol/l") ||
                normalized.contains("µmol/l") ||
                normalized.contains("meq/l") ||
                normalized.contains("cells/mcl") ||
                normalized.contains("cells/ul") ||
                normalized.contains("cells/µl")
    }

    private fun isStandaloneReferenceSymbol(
        value: String
    ): Boolean {

        val normalized =
            value
                .lowercase()
                .trim()

        return normalized == "<" ||
                normalized == ">" ||
                normalized == "<=" ||
                normalized == ">=" ||
                normalized == "≤" ||
                normalized == "≥"
    }

    private fun isIgnoredToken(
        value: String
    ): Boolean {

        val normalized =
            value
                .lowercase()
                .trim(
                    '*',
                    '.',
                    ',',
                    ':',
                    ';'
                )

        if (normalized.isBlank()) {
            return true
        }

        if (normalized in ignoredWords) {
            return true
        }

        if (normalized in riskWords) {
            return true
        }

        if (isUnitCandidate(normalized)) {
            return true
        }

        return false
    }

    private fun isLikelyNameFragment(
        testName: String,
        result: String
    ): Boolean {

        val name =
            testName
                .lowercase()
                .replace(
                    Regex("""\s+"""),
                    " "
                )
                .trim()

        val resultValue =
            normalizeDigits(
                result
                    .lowercase()
                    .trim()
            )

        if (
            Regex(
                """\bb\s*$resultValue\b"""
            ).containsMatchIn(name)
        ) {
            return true
        }

        if (
            resultValue.length <= 2 &&
            Regex(
                """[a-z]\s*$resultValue$"""
            ).containsMatchIn(name)
        ) {
            return true
        }

        return false
    }

    private fun normalizeDigits(
        input: String
    ): String {

        return input
            .replace('۰', '0')
            .replace('۱', '1')
            .replace('۲', '2')
            .replace('۳', '3')
            .replace('۴', '4')
            .replace('۵', '5')
            .replace('۶', '6')
            .replace('۷', '7')
            .replace('۸', '8')
            .replace('۹', '9')
            .replace('٠', '0')
            .replace('١', '1')
            .replace('٢', '2')
            .replace('٣', '3')
            .replace('٤', '4')
            .replace('٥', '5')
            .replace('٦', '6')
            .replace('٧', '7')
            .replace('٨', '8')
            .replace('٩', '9')
            .replace('٫', '.')
            .replace('٬', '.')
    }

    private fun normalizeResult(
        value: String
    ): String {

        return normalizeDigits(
            value
                .trim(
                    '*',
                    '+',
                    ',',
                    ':',
                    ';'
                )
                .replace(
                    '–',
                    '-'
                )
                .replace(
                    '—',
                    '-'
                )
                .trim()
        )
    }

    private fun removeDuplicates(
        items: List<ExtractedItem>
    ): List<ExtractedItem> {

        val seen = mutableSetOf<String>()

        return items.filter { item ->

            val key =
                item.label
                    .trim()
                    .lowercase() +
                        "|" +
                        item.value
                            .trim()
                            .lowercase()

            if (key in seen) {
                false
            } else {
                seen.add(key)
                true
            }
        }
    }
}