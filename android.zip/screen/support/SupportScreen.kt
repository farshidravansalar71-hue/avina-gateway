package com.avina.health.screen.support

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue

@Composable
fun SupportScreen(
    currentLang: String,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current // گرفتن کانتکست در بالای کامپوزابل
    var expandedFaqIndex by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppTheme.colors.pageBackground)
            .statusBarsPadding()
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(
                    imageVector = if (currentLang == "en") Icons.Default.ArrowBack else Icons.Default.ArrowForward,
                    contentDescription = "Back",
                    tint = AppTheme.colors.textPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (currentLang == "en") "Support & Help" else "پشتیبانی و راهنما",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = AppTheme.colors.textPrimary
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Contact Options Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = AppTheme.colors.cardBackground,
                shadowElevation = 1.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (currentLang == "en") "Direct Communication" else "ارتباط مستقیم",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppTheme.colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    SupportOptionRow(
                        icon = Icons.Default.Phone,
                        title = if (currentLang == "en") "Phone Support" else "پشتیبانی تلفنی",
                        subtitle = "021-91000000",
                        currentLang = currentLang
                    ) {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:02191000000"))
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = PrimaryBlue.copy(alpha = 0.08f))

                    SupportOptionRow(
                        icon = Icons.Default.Chat,
                        title = if (currentLang == "en") "Telegram Support" else "پشتیبانی تلگرام",
                        subtitle = "@avintebsupport",
                        currentLang = currentLang
                    ) {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/avintebsupport"))
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }

            // FAQ Section Header
            Text(
                text = if (currentLang == "en") "Frequently Asked Questions" else "سوالات متداول",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AppTheme.colors.textPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )

            // FAQ Items
            val faqs = if (currentLang == "en") {
                listOf(
                    "How to interpret lab test results?" to "You can upload your lab test image or PDF, and our AI analyzes the metrics instantly.",
                    "Is my health data secure?" to "Yes, all your medical records and personal data are encrypted and stored securely.",
                    "How to upgrade to Premium?" to "Go to your profile, tap on the Premium card, and choose your preferred subscription plan."
                )
            } else {
                listOf(
                    "چطور نتایج آزمایشم را تفسیر کنم؟" to "شما می‌توانید تصویر یا فایل PDF آزمایش خود را آپلود کنید تا هوش مصنوعی آوین طب به سرعت مقادیر آن را تحلیل کند.",
                    "آیا اطلاعات سلامت من امن است؟" to "بله، تمامی سوابق پزشکی و داده‌های شخصی شما رمزنگاری شده و به صورت امن ذخیره می‌شوند.",
                    "چطور حساب خود را به نسخه پرمیوم ارتقا دهم؟" to "از طریق صفحه پروفایل، روی کارت پرمیوم کلیک کرده و پلن اشتراک مورد نظر خود را انتخاب کنید."
                )
            }

            faqs.forEachIndexed { index, (question, answer) ->
                FaqItem(
                    question = question,
                    answer = answer,
                    isExpanded = expandedFaqIndex == index,
                    currentLang = currentLang,
                    onClick = {
                        expandedFaqIndex = if (expandedFaqIndex == index) null else index
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SupportOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    currentLang: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(40.dp),
            shape = RoundedCornerShape(12.dp),
            color = PrimaryBlue.copy(alpha = 0.12f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 11.sp, color = AppTheme.colors.textSecondary)
        }
        Icon(
            imageVector = if (currentLang == "en") Icons.Default.KeyboardArrowRight else Icons.Default.KeyboardArrowLeft,
            contentDescription = null,
            tint = AppTheme.colors.textSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun FaqItem(
    question: String,
    answer: String,
    isExpanded: Boolean,
    currentLang: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = AppTheme.colors.cardBackground,
        shadowElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = question,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppTheme.colors.textPrimary,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
            if (isExpanded) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = PrimaryBlue.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = answer,
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary,
                    lineHeight = 18.sp
                )
            }
        }
    }
}