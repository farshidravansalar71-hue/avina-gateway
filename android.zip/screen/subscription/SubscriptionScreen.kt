// صفحه خرید پرمیوم
package com.avina.health.screen.subscription

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SubscriptionScreen(
    onBackClick: () -> Unit = {},
    onSubscribeClick: (String) -> Unit = {}
) {
    // انیمیشن کم و زیاد شدن نور ستاره‌های زرد
    val infiniteTransition = rememberInfiniteTransition(label = "starsTransition")

    val starAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "yellowStarAlpha"
    )

    // انیمیشن حرکت شهاب‌های زرد
    val shootingProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "yellowShootingProgress"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        var selectedPlan by remember { mutableStateOf("1_year") }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(AppTheme.colors.pageBackground)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp)
            ) {
                Spacer(modifier = Modifier.height(50.dp))

                // هدر صفحه
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(AppTheme.colors.cardBackground)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "بازگشت",
                            tint = AppTheme.colors.textPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "اشتراک و خرید آزمایش آوین",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppTheme.colors.textPrimary
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // بنر حرفه‌ای با ستاره‌ها و شهاب‌های زرد
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = Color.Transparent
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Brush.linearGradient(colors = listOf(Color(0xFF011640), Color(0xFF0B2D78))))
                            .padding(20.dp)
                    ) {
                        // لایه Canvas برای رسم ستاره‌ها و شهاب‌های زرد پس‌زمینه
                        Canvas(modifier = Modifier.matchParentSize()) {
                            val yellowStarColor = Color(0xFFFFD700) // رنگ زرد طلایی

                            // ۱. ۶ ستاره زرد کوچک در نقاط مختلف
                            val yellowStars = listOf(
                                Offset(size.width * 0.12f, size.height * 0.25f),
                                Offset(size.width * 0.35f, size.height * 0.78f),
                                Offset(size.width * 0.58f, size.height * 0.2f),
                                Offset(size.width * 0.78f, size.height * 0.35f),
                                Offset(size.width * 0.88f, size.height * 0.82f),
                                Offset(size.width * 0.45f, size.height * 0.55f)
                            )

                            yellowStars.forEachIndexed { index, offset ->
                                val currentAlpha = if (index % 2 == 0) starAlpha else (1.2f - starAlpha).coerceIn(0.2f, 0.95f)
                                drawCircle(
                                    color = yellowStarColor.copy(alpha = currentAlpha),
                                    radius = if (index % 2 == 0) 1.8.dp.toPx() else 1.3.dp.toPx(),
                                    center = offset
                                )
                            }

                            // ۲. شهاب‌های زرد متحرک و محوشونده
                            val startX = listOf(0.45f, 0.85f)
                            val startY = listOf(0.05f, 0.2f)
                            val delays = listOf(0.0f, 0.5f)

                            val angleRad = Math.toRadians(25.0)
                            val tailLength = 65.dp.toPx()

                            for (i in startX.indices) {
                                val p = (shootingProgress + delays[i]) % 1f

                                val headX = size.width * (startX[i] - p * 0.5f)
                                val headY = size.height * (startY[i] + p * 0.6f)

                                val tailX = headX + tailLength * cos(angleRad).toFloat()
                                val tailY = headY - tailLength * sin(angleRad).toFloat()

                                val alphaFactor = when {
                                    p < 0.15f -> p / 0.15f
                                    p > 0.75f -> (1f - p) / 0.25f
                                    else -> 1f
                                }

                                if (alphaFactor > 0f) {
                                    // رد و دنباله نور زرد شهاب
                                    drawLine(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xFFFFD700).copy(alpha = 0.35f * alphaFactor),
                                                Color(0xFFFFF176).copy(alpha = 0.95f * alphaFactor)
                                            ),
                                            start = Offset(tailX, tailY),
                                            end = Offset(headX, headY)
                                        ),
                                        start = Offset(tailX, tailY),
                                        end = Offset(headX, headY),
                                        strokeWidth = 1.4.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )

                                    // سرِ درخشان زرد شهاب
                                    drawCircle(
                                        color = Color(0xFFFFF176).copy(alpha = alphaFactor),
                                        radius = 1.6.dp.toPx(),
                                        center = Offset(headX, headY)
                                    )
                                }
                            }
                        }

                        // محتوای اصلی بنر
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, null, tint = Color(0xFFFFD700), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("ارتقا به نسخه حرفه‌ای", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("تحلیل هوشمند و گزارش‌های کامل سلامت در انتظار شماست.", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text("انتخاب نوع خرید", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                SubscriptionOptionCard("خرید تکی یک آزمایش", "۵۰,۰۰۰ تومان", "مناسب برای استفاده موردی", "تک‌جلسه‌ای 🧪", selectedPlan == "single_test") { selectedPlan = "single_test" }
                Spacer(modifier = Modifier.height(12.dp))
                SubscriptionOptionCard("اشتراک ماهانه", "۹۹,۰۰۰ تومان", "۳۰ روزه", null, selectedPlan == "1_month") { selectedPlan = "1_month" }
                Spacer(modifier = Modifier.height(12.dp))
                SubscriptionOptionCard("اشتراک سه‌ماهه", "۲۴۹,۰۰۰ تومان", "۹۰ روزه", "اقتصادی", selectedPlan == "3_months") { selectedPlan = "3_months" }
                Spacer(modifier = Modifier.height(12.dp))
                SubscriptionOptionCard("اشتراک سالانه", "۷۹۰,۰۰۰ تومان", "۳۶۵ روزه", "۳۵٪ تخفیف", selectedPlan == "1_year") { selectedPlan = "1_year" }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { onSubscribeClick(selectedPlan) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Text("تایید و ادامه پرداخت", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun SubscriptionOptionCard(
    title: String, price: String, duration: String, badge: String?, isSelected: Boolean, onClick: () -> Unit
) {
    val borderColor = if (isSelected) PrimaryBlue else Color.Transparent
    val backgroundColor = if (isSelected) PrimaryBlue.copy(alpha = 0.1f) else AppTheme.colors.cardBackground

    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        color = backgroundColor,
        border = androidx.compose.foundation.BorderStroke(2.dp, borderColor)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppTheme.colors.textPrimary)
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(shape = RoundedCornerShape(6.dp), color = PrimaryBlue.copy(alpha = 0.2f)) {
                            Text(badge, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                        }
                    }
                }
                Text(duration, fontSize = 11.sp, color = AppTheme.colors.textSecondary)
            }
            Text(price, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
        }
    }
}