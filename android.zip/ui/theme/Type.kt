package com.avina.health.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontWeight

val Typography = Typography(

    bodyLarge = androidx.compose.material3.Typography().bodyLarge.copy(
        fontFamily = VazirFont,
        fontWeight = FontWeight.Normal
    ),

    bodyMedium = androidx.compose.material3.Typography().bodyMedium.copy(
        fontFamily = VazirFont,
        fontWeight = FontWeight.Normal
    ),

    titleLarge = androidx.compose.material3.Typography().titleLarge.copy(
        fontFamily = VazirFont,
        fontWeight = FontWeight.Bold
    )
)