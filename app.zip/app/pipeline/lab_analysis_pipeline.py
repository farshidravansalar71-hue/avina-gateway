from sqlalchemy.orm import Session
from app.ai.gpt_vision_client import GPTVisionClient
from app.ai.gemini_client import GeminiClient

from app.ai.gemini_selector import select_tests_for_analysis

from app.services.lab_normalizer import normalize_lab_json
from app.services.lab_validator import validate_gemini_analysis
from app.services.chart_builder import build_final_avina_json
from app.services.lab_dictionary import DEFAULT_LAB_DICTIONARY

from app.database.crud import (
    get_lab_test_dict_batch,
    save_lab_test_dict_batch,
)


class LabAnalysisPipeline:
    """
    AVINA Lab Pipeline

    Flow:
    Android Image -> GPT Vision -> Normalizer -> Selector -> Check DB Cache -> 
    Gemini Analysis -> Save DB Cache -> Inject Names/Descriptions -> Validation -> Final Report
    """

    def __init__(self):
        self.gpt = GPTVisionClient()
        self.gemini = GeminiClient()

    def run(
        self,
        image_path: str,
        db: Session = None
    ) -> dict:

        # =====================================
        # STEP 1: GPT VISION
        # =====================================
        raw_lab = self.gpt.extract_lab(image_path)
        print("[GPT Vision] Success")

        # =====================================
        # STEP 2: NORMALIZER
        # =====================================
        clean_lab = normalize_lab_json(raw_lab)
        print("[Normalizer] Success")

        # =====================================
        # STEP 3: SELECTOR & DATABASE CACHE CHECK
        # =====================================
        gemini_input = select_tests_for_analysis(clean_lab)

        # استخراج کلیدهای تست برای چک کردن کش
        test_keys = [
            test.get("name") or test.get("test_name") 
            for test in gemini_input.get("tests", [])
            if test.get("name") or test.get("test_name")
        ]

        cached_tests_map = {}
        if db and test_keys:
            cached_tests_map = get_lab_test_dict_batch(db, test_keys)
            print(f"[Database Cache] Found {len(cached_tests_map)}/{len(test_keys)} tests in local DB.")

        print(f"[Selector] {len(gemini_input['tests'])}/{len(clean_lab['tests'])}")

        # =====================================
        # STEP 4: GEMINI ANALYSIS
        # =====================================
        analysis = self.gemini.analyze(gemini_input)
        print("[Gemini Analysis] Success")

        # =====================================
        # STEP 4.1: MERGE & SAVE TO DB CACHE
        # =====================================
        gemini_tests_map = {}
        if isinstance(analysis, dict):
            # استخراج از یافته‌های مهم
            for finding in analysis.get("important_findings", []):
                t_name = finding.get("test_name") or finding.get("title")
                if t_name:
                    gemini_tests_map[t_name] = {
                        "persian_name": finding.get("persian_name", ""),
                        "description": finding.get("description", "")
                    }
            
            # استخراج از لیست کلی اگر جمنای آن را برگردانده باشد
            for t_item in analysis.get("lab_results", []):
                t_name = t_item.get("name") or t_item.get("test_name")
                if t_name:
                    gemini_tests_map[t_name] = {
                        "persian_name": t_item.get("persian_name", ""),
                        "description": t_item.get("description", "")
                    }

        # ذخیره تست‌های جدید تحلیل‌شده در کش دیتابیس
        if db and gemini_tests_map:
            new_cache_items = []
            for k_name, val in gemini_tests_map.items():
                p_name = val.get("persian_name", "")
                desc = val.get("description", "")
                if k_name not in cached_tests_map and (p_name or desc):
                    new_cache_items.append({
                        "test_key": k_name,
                        "persian_name": p_name,
                        "description": desc
                    })
            if new_cache_items:
                save_lab_test_dict_batch(db, new_cache_items)
                print(f"[Database Cache] Saved {len(new_cache_items)} new tests to local DB.")
                cached_tests_map.update(get_lab_test_dict_batch(db, list(gemini_tests_map.keys())))

        # =====================================
        # STEP 4.2: INJECT CACHE / GEMINI / DEFAULT DATA TO CLEAN LAB
        # (حل مشکل: پر کردن ۱۰۰٪ نام‌های فارسی و توضیحات)
        # =====================================
        for test in clean_lab.get("tests", []):
            t_name = test.get("name")
            
            # اولویت ۱: کش دیتابیس محلی
            if t_name in cached_tests_map and cached_tests_map[t_name].persian_name:
                c_item = cached_tests_map[t_name]
                test["persian_name"] = c_item.persian_name
                test["description"] = c_item.description or ""
            
            # اولویت ۲: خروجی مستقیم جدید Gemini
            elif t_name in gemini_tests_map and gemini_tests_map[t_name].get("persian_name"):
                g_item = gemini_tests_map[t_name]
                test["persian_name"] = g_item.get("persian_name", "")
                test["description"] = g_item.get("description", "")
            
            # اولویت ۳: دیکشنری پیش‌فرض سیستم (Fallback)
            elif t_name in DEFAULT_LAB_DICTIONARY:
                def_item = DEFAULT_LAB_DICTIONARY[t_name]
                test["persian_name"] = def_item["persian_name"]
                test["description"] = def_item["description"]
            
            else:
                test["persian_name"] = ""
                test["description"] = ""

        # =====================================
        # STEP 5: VALIDATION
        # =====================================
        validated = validate_gemini_analysis(
            clean_lab,
            analysis
        )
        print("######## TEST VALIDATED ########")
        print(validated)
        print("[Validation] Success")

        # =====================================
        # STEP 6: FINAL AVINA REPORT
        # =====================================
        final_report = build_final_avina_json(
            clean_lab,
            validated
        )
        print("[Final JSON] Success")

        # =====================================
        # STEP 7: RESPONSE WRAPPER
        # =====================================
        return {
            "report": final_report
        }