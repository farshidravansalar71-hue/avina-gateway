package com.avina.health.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import java.io.ByteArrayOutputStream

/**
 * فشرده‌سازی تصاویر آزمایش قبل از ارسال به سرور.
 *
 * مسیر:
 *
 * Uri
 * ↓
 * OpenInputStream
 * ↓
 * Decode Bounds
 * ↓
 * Decode Bitmap
 * ↓
 * Resize
 * ↓
 * JPEG
 * ↓
 * ByteArray
 */
object ImageCompressor {

    private const val TAG = "AVINA_COMPRESSOR"

    private const val MAX_WIDTH = 2400
    private const val MAX_HEIGHT = 2400

    /**
     * کیفیت JPEG
     */
    private const val JPEG_QUALITY = 85

    /**
     * تصویر را از Uri می‌خواند و به JPEG فشرده تبدیل می‌کند.
     */
    fun compress(
        context: Context,
        uri: Uri
    ): ByteArray {

        Log.d(TAG, "========================================")
        Log.d(TAG, "1. compress() START")
        Log.d(TAG, "2. URI = $uri")
        Log.d(TAG, "3. URI scheme = ${uri.scheme}")
        Log.d(TAG, "4. URI authority = ${uri.authority}")
        Log.d(TAG, "5. URI path = ${uri.path}")

        return try {

            Log.d(TAG, "6. Starting bitmap decode")

            val bitmap = decodeBitmap(
                context = context,
                uri = uri
            )

            Log.d(
                TAG,
                "7. Bitmap decoded successfully: " +
                        "${bitmap.width}x${bitmap.height}"
            )

            try {

                Log.d(TAG, "8. Starting resize check")

                val resizedBitmap =
                    resizeIfNeeded(bitmap)

                Log.d(
                    TAG,
                    "9. Resize result: " +
                            "${resizedBitmap.width}x${resizedBitmap.height}"
                )

                try {

                    Log.d(TAG, "10. Starting JPEG compression")

                    val outputStream =
                        ByteArrayOutputStream()

                    val success =
                        resizedBitmap.compress(
                            Bitmap.CompressFormat.JPEG,
                            JPEG_QUALITY,
                            outputStream
                        )

                    Log.d(
                        TAG,
                        "11. JPEG compress success = $success"
                    )

                    if (!success) {

                        Log.e(
                            TAG,
                            "12. JPEG compression FAILED"
                        )

                        throw IllegalStateException(
                            "فشرده‌سازی تصویر انجام نشد."
                        )
                    }

                    val result =
                        outputStream.toByteArray()

                    Log.d(
                        TAG,
                        "13. JPEG created successfully"
                    )

                    Log.d(
                        TAG,
                        "14. Final image size = ${result.size} bytes"
                    )

                    Log.d(TAG, "15. compress() SUCCESS")
                    Log.d(TAG, "========================================")

                    result

                } finally {

                    if (
                        resizedBitmap !== bitmap &&
                        !resizedBitmap.isRecycled
                    ) {

                        Log.d(
                            TAG,
                            "16. Recycling resized bitmap"
                        )

                        resizedBitmap.recycle()
                    }
                }

            } finally {

                if (!bitmap.isRecycled) {

                    Log.d(
                        TAG,
                        "17. Recycling original bitmap"
                    )

                    bitmap.recycle()
                }
            }

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "❌ compress() FAILED",
                exception
            )

            Log.e(
                TAG,
                "❌ URI = $uri"
            )

            Log.e(
                TAG,
                "❌ URI scheme = ${uri.scheme}"
            )

            Log.e(
                TAG,
                "❌ URI authority = ${uri.authority}"
            )

            Log.d(TAG, "========================================")

            throw exception
        }
    }

    /**
     * Decode کردن تصویر با نمونه‌برداری مناسب.
     */
    private fun decodeBitmap(
        context: Context,
        uri: Uri
    ): Bitmap {

        Log.d(TAG, "----------------------------------------")
        Log.d(TAG, "18. decodeBitmap() START")
        Log.d(TAG, "19. Opening InputStream for URI")

        val resolver =
            context.contentResolver

        val boundsOptions =
            BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }

        val boundsStream =
            resolver.openInputStream(uri)

        if (boundsStream == null) {

            Log.e(
                TAG,
                "❌ 20. openInputStream() returned NULL"
            )

            Log.e(
                TAG,
                "❌ Cannot read URI: $uri"
            )

            throw IllegalStateException(
                "امکان خواندن تصویر وجود ندارد."
            )
        }

        Log.d(
            TAG,
            "20. InputStream opened successfully"
        )

        boundsStream.use { input ->

            BitmapFactory.decodeStream(
                input,
                null,
                boundsOptions
            )
        }

        Log.d(
            TAG,
            "21. Bounds decoded"
        )

        val originalWidth =
            boundsOptions.outWidth

        val originalHeight =
            boundsOptions.outHeight

        Log.d(
            TAG,
            "22. Original dimensions = " +
                    "${originalWidth}x${originalHeight}"
        )

        Log.d(
            TAG,
            "23. Image mimeType = ${boundsOptions.outMimeType}"
        )

        if (
            originalWidth <= 0 ||
            originalHeight <= 0
        ) {

            Log.e(
                TAG,
                "❌ 24. Invalid image dimensions"
            )

            Log.e(
                TAG,
                "❌ width = $originalWidth"
            )

            Log.e(
                TAG,
                "❌ height = $originalHeight"
            )

            Log.e(
                TAG,
                "❌ mimeType = ${boundsOptions.outMimeType}"
            )

            throw IllegalStateException(
                "ابعاد تصویر قابل تشخیص نیست."
            )
        }

        val sampleSize =
            calculateSampleSize(
                width = originalWidth,
                height = originalHeight
            )

        Log.d(
            TAG,
            "25. Calculated sampleSize = $sampleSize"
        )

        val decodeOptions =
            BitmapFactory.Options().apply {

                inSampleSize =
                    sampleSize

                inPreferredConfig =
                    Bitmap.Config.ARGB_8888
            }

        Log.d(
            TAG,
            "26. Starting final Bitmap decode"
        )

        val imageStream =
            resolver.openInputStream(uri)

        if (imageStream == null) {

            Log.e(
                TAG,
                "❌ 27. Second openInputStream() returned NULL"
            )

            throw IllegalStateException(
                "تصویر قابل خواندن نیست."
            )
        }

        val bitmap =
            imageStream.use { input ->

                BitmapFactory.decodeStream(
                    input,
                    null,
                    decodeOptions
                )
            }

        if (bitmap == null) {

            Log.e(
                TAG,
                "❌ 28. BitmapFactory.decodeStream() returned NULL"
            )

            throw IllegalStateException(
                "تصویر قابل Decode نیست."
            )
        }

        Log.d(
            TAG,
            "29. Final Bitmap decoded successfully"
        )

        Log.d(
            TAG,
            "30. Bitmap dimensions = " +
                    "${bitmap.width}x${bitmap.height}"
        )

        Log.d(TAG, "decodeBitmap() SUCCESS")
        Log.d(TAG, "----------------------------------------")

        return bitmap
    }

    /**
     * تعیین مقدار inSampleSize
     */
    private fun calculateSampleSize(
        width: Int,
        height: Int
    ): Int {

        var sampleSize = 1

        while (
            width / (sampleSize * 2) >= MAX_WIDTH &&
            height / (sampleSize * 2) >= MAX_HEIGHT
        ) {

            sampleSize *= 2
        }

        Log.d(
            TAG,
            "calculateSampleSize(): " +
                    "${width}x${height} -> sampleSize=$sampleSize"
        )

        return sampleSize
    }

    /**
     * اگر تصویر بزرگ‌تر از محدوده مجاز باشد،
     * آن را با حفظ نسبت ابعاد کوچک می‌کند.
     */
    private fun resizeIfNeeded(
        bitmap: Bitmap
    ): Bitmap {

        val width =
            bitmap.width

        val height =
            bitmap.height

        Log.d(
            TAG,
            "resizeIfNeeded(): input=${width}x${height}"
        )

        if (
            width <= MAX_WIDTH &&
            height <= MAX_HEIGHT
        ) {

            Log.d(
                TAG,
                "resizeIfNeeded(): no resize required"
            )

            return bitmap
        }

        val widthRatio =
            MAX_WIDTH.toFloat() / width

        val heightRatio =
            MAX_HEIGHT.toFloat() / height

        val scale =
            minOf(
                widthRatio,
                heightRatio
            )

        val newWidth =
            (width * scale)
                .toInt()
                .coerceAtLeast(1)

        val newHeight =
            (height * scale)
                .toInt()
                .coerceAtLeast(1)

        Log.d(
            TAG,
            "resizeIfNeeded(): resizing to " +
                    "${newWidth}x${newHeight}"
        )

        return Bitmap.createScaledBitmap(
            bitmap,
            newWidth,
            newHeight,
            true
        )
    }
}