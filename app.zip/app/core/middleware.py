import time
import logging

from fastapi import FastAPI, Request


logger = logging.getLogger(__name__)


def register_middlewares(app: FastAPI):

    @app.middleware("http")
    async def request_logger(
        request: Request,
        call_next
    ):

        start_time = time.time()

        response = await call_next(
            request
        )

        duration = time.time() - start_time


        logger.info(
            f"{request.method} "
            f"{request.url.path} "
            f"status={response.status_code} "
            f"time={duration:.4f}s"
        )


        return response