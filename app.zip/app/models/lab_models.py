from typing import List, Optional, Dict, Any

from pydantic import BaseModel, Field


# ============================================================
# PYDANTIC SCHEMAS (API Response Models)
# ============================================================

class LabItemResult(BaseModel):

    test_name: str
    value: Optional[str] = None
    unit: Optional[str] = None
    reference_range: Optional[str] = None
    status: Optional[str] = None


    class Config:
        populate_by_name = True



class LabReportSummary(BaseModel):

    report_id: str
    created_at: str
    overall_status_title: Optional[str] = None
    tests_count: int = 0


    class Config:
        populate_by_name = True



class LabReportListResponse(BaseModel):

    success: bool = True
    reports: List[LabReportSummary] = []


    class Config:
        populate_by_name = True



class LabAnalysisResponse(BaseModel):

    success: bool = True

    reportId: Optional[str] = Field(
        None,
        alias="report_id"
    )

    report: Optional[Dict[str, Any]] = None

    message: Optional[str] = None

    remainingFreeTests: Optional[int] = None

    isPremium: bool = False


    class Config:
        populate_by_name = True
        allow_population_by_field_name = True