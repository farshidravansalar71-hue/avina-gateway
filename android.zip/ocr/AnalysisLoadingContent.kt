package com.avina.health.ocr

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.R
import com.avina.health.ui.theme.AppTheme


@Composable
fun AnalysisLoadingContent() {

    val infiniteTransition = rememberInfiniteTransition(
        label = "logoPulse"
    )

    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoAlpha"
    )


    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {


            Box(
                contentAlignment = Alignment.Center
            ) {

                CircularProgressIndicator(
                    modifier = Modifier.size(170.dp),
                    strokeWidth = 4.dp
                )


                Image(
                    painter = painterResource(
                        id = R.drawable.logo
                    ),
                    contentDescription = "Avina Logo",
                    modifier = Modifier
                        .size(90.dp)
                        .alpha(alpha)
                )
            }


            Spacer(
                modifier = Modifier.height(40.dp)
            )


            Text(
                text = "آوینا در حال بررسی آزمایش شماست...",
                color = AppTheme.colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )


            Spacer(
                modifier = Modifier.height(12.dp)
            )


            Text(
                text = "استخراج اطلاعات آزمایش\nتحلیل هوشمند نتایج\nساخت گزارش سلامت",
                color = AppTheme.colors.textPrimary,
                fontSize = 15.sp,
                lineHeight = 28.sp
            )


            Spacer(
                modifier = Modifier.height(24.dp)
            )


            Text(
                text = "🔒 اطلاعات شما محفوظ و محرمانه است",
                color = AppTheme.colors.textPrimary,
                fontSize = 13.sp
            )
        }
    }
}