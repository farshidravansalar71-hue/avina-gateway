package com.avina.health.components

import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue
import com.avina.health.ui.theme.TextSecondary
import com.avina.health.utils.LocalLanguage

@Composable
fun AvinaBottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    showMiddleSpacer: Boolean = true
) {
    val currentLang = LocalLanguage.current
    val isEnglish = currentLang == "en"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(AppTheme.colors.pageBackground)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = RoundedCornerShape(22.dp),
                    ambientColor = Color(0x12000000),
                    spotColor = Color(0x12000000)
                )
                .clip(RoundedCornerShape(22.dp))
                .background(AppTheme.colors.cardBackground)
                .padding(horizontal = 2.dp, vertical = 2.dp)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavigationItem(
                        selected = selectedTab == 0,
                        onClick = { onTabSelected(0) },
                        icon = Icons.Default.Home,
                        label = if (isEnglish) "Home" else "خانه"
                    )

                    PdfNavigationItem(
                        selected = selectedTab == 1,
                        onClick = { onTabSelected(1) },
                        icon = Icons.Default.Description,
                        label = if (isEnglish) "PDF Report" else "گزارش PDF",
                        isEnglish = isEnglish
                    )

                    NavigationItem(
                        selected = selectedTab == 2,
                        onClick = { onTabSelected(2) },
                        icon = Icons.Default.ShowChart,
                        label = if (isEnglish) "Trends" else "روندها"
                    )

                    if (showMiddleSpacer) {
                        Spacer(modifier = Modifier.width(44.dp))
                    }

                    NavigationItem(
                        selected = selectedTab == 3,
                        onClick = { onTabSelected(3) },
                        icon = Icons.Default.Lightbulb,
                        label = if (isEnglish) "Tips" else "توصیه‌ها"
                    )
                    NavigationItem(
                        selected = selectedTab == 4,
                        onClick = { onTabSelected(4) },
                        icon = Icons.Default.SupportAgent,
                        label = if (isEnglish) "Support" else "مشاوره"
                    )
                    NavigationItem(
                        selected = selectedTab == 5,
                        onClick = { onTabSelected(5) },
                        icon = Icons.Default.Person,
                        label = if (isEnglish) "Profile" else "پروفایل"
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.NavigationItem(
    selected: Boolean,
    onClick: () -> Unit,
    icon: ImageVector,
    label: String
) {
    val unselectedColor = AppTheme.colors.textSecondary

    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        alwaysShowLabel = true,
        interactionSource = remember { MutableInteractionSource() },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) PrimaryBlue else unselectedColor,
                modifier = Modifier.size(20.dp)
            )
        },
        label = {
            Text(
                text = label,
                fontSize = 9.sp,
                lineHeight = 9.sp,
                color = if (selected) PrimaryBlue else unselectedColor,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        },
        colors = NavigationBarItemDefaults.colors(
            indicatorColor = Color.Transparent,
            selectedIconColor = PrimaryBlue,
            selectedTextColor = PrimaryBlue,
            unselectedIconColor = unselectedColor,
            unselectedTextColor = unselectedColor
        )
    )
}

@Composable
private fun RowScope.PdfNavigationItem(
    selected: Boolean,
    onClick: () -> Unit,
    icon: ImageVector,
    label: String,
    isEnglish: Boolean
) {
    val unselectedColor = AppTheme.colors.textSecondary

    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        alwaysShowLabel = true,
        interactionSource = remember { MutableInteractionSource() },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) PrimaryBlue else unselectedColor,
                modifier = Modifier.size(20.dp)
            )
        },
        label = {
            Text(
                text = label,
                fontSize = 9.sp,
                lineHeight = 9.sp,
                color = if (selected) PrimaryBlue else unselectedColor,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        },
        colors = NavigationBarItemDefaults.colors(
            indicatorColor = Color.Transparent,
            selectedIconColor = PrimaryBlue,
            selectedTextColor = PrimaryBlue,
            unselectedIconColor = unselectedColor,
            unselectedTextColor = unselectedColor
        )
    )
}