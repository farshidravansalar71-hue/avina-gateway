//دور زدن محدودیت‌های رایگان uuid
package com.avina.health.data

import android.content.Context
import android.provider.Settings
import java.util.UUID

class LabUsageManager(context: Context) {
    private val prefs = context.getSharedPreferences("avina_lab_usage_prefs", Context.MODE_PRIVATE)

    /**
     * شناسه یکتای پایدار دستگاه (UID)
     * با استفاده از ANDROID_ID حتی اگر کاربر دیتای اپ را پاک کند (Clear Data)،
     * این شناسه حفظ می‌شود تا نتواند محدودیت ۵ آزمایش رایگان را دور بزند.
     */
    val deviceUid: String by lazy {
        val savedUid = prefs.getString("device_unique_id", null)
        if (!savedUid.isNullOrEmpty()) {
            savedUid
        } else {
            val androidId = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ANDROID_ID
            ).takeIf { !it.isNullOrBlank() } ?: UUID.randomUUID().toString()

            prefs.edit().putString("device_unique_id", androidId).apply()
            androidId
        }
    }

    /**
     * تعداد آزمایش‌های رایگان مصرف شده (حداکثر ۵ عدد)
     */
    var freeTestsUsed: Int
        get() = prefs.getInt("free_tests_used", 0)
        set(value) = prefs.edit().putInt("free_tests_used", value).apply()

    /**
     * تعداد آزمایش‌های خریداری شده اضافی (مربوط به پرداخت موردی ۵۰ هزار تومانی)
     */
    var purchasedTestsCount: Int
        get() = prefs.getInt("purchased_tests_count", 0)
        set(value) = prefs.edit().putInt("purchased_tests_count", value).apply()

    /**
     * بررسی اینکه آیا کاربر اجازه تحلیل آزمایش جدید را دارد یا خیر
     */
    fun canAnalyzeLab(): Boolean {
        // اگر هنوز از ۵ آزمایش رایگان سهمیه دارد
        if (freeTestsUsed < 5) return true
        // اگر سهمیه خریداری شده (پرداخت موردی) دارد
        if (purchasedTestsCount > 0) return true

        return false // یعنی نه سهمیه رایگان دارد و نه آزمایش تکی خریده
    }

    /**
     * مصرف یک سهمیه هنگام کلیک روی تحلیل آزمایش
     * اول از رایگان‌ها کم می‌کند، اگر تمام شده بود از آزمایش‌های خریداری‌شده کسر می‌کند.
     */
    fun consumeTest(): Boolean {
        return if (freeTestsUsed < 5) {
            freeTestsUsed++
            true
        } else if (purchasedTestsCount > 0) {
            purchasedTestsCount--
            true
        } else {
            false // اجازه تحلیل داده نمی‌شود و باید دیالوگ خرید باز شود
        }
    }

    /**
     * زمانی که کاربر پرداخت ۵۰ هزار تومانی را انجام داد، یک عدد به سهمیه‌اش اضافه می‌شود
     */
    fun addPurchasedTest() {
        purchasedTestsCount++
    }
}