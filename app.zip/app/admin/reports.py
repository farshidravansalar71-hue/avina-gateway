from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.database.models import User, LabReport
from app.auth.dependencies import get_current_admin


router = APIRouter(
    prefix="/api/v1/admin/reports",
    tags=["Admin Reports"]
)


@router.get("/")
def get_all_reports(
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    """
    دریافت لیست گزارش‌های آزمایش برای ادمین
    """

    total = db.query(LabReport).count()

    reports = (
        db.query(LabReport)
        .offset(skip)
        .limit(limit)
        .all()
    )

    return {
        "total_reports": total,
        "reports": [
            {
                "id": report.id,
                "report_id": report.report_id,
                "user": {
                    "id": report.user.id,
                    "email": report.user.email,
                    "is_premium": report.user.is_premium
                } if report.user else None,
                "created_at": report.created_at
            }
            for report in reports
        ]
    }