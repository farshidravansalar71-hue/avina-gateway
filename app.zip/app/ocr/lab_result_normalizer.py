from typing import List
import re
from difflib import SequenceMatcher


class LabResultNormalizer:
    """
    Generic Lab Result Normalizer

    هدف:
    - اصلاح OCR typo
    - استانداردسازی نام
    - بدون وابستگی به لیست هزار آزمایش
    """

    COMMON_NAMES = [

        "LDL Cholesterol",
        "HDL Cholesterol",
        "Total Cholesterol",
        "Triglycerides",

        "SGOT(AST)",
        "SGPT(ALT)",
        "Alkaline Phosphatase",

        "Ferritin",
        "Iron",
        "TIBC",

        "TSH",
        "Free T4",
        "Free T3",

        "Protein",
        "Glucose",
        "Blood",
        "Ketone",
        "Bilirubin",
        "Nitrite",
        "Urobilinogen",

    ]


    def normalize(
        self,
        results: List
    ) -> List:


        output=[]


        for item in results:


            name = self._get_name(item)


            if not name:
                continue


            clean_name = self._clean(name)


            matched = self._find_best_match(
                clean_name
            )


            if matched:

                self._set_name(
                    item,
                    matched
                )


            output.append(item)


        return output



    # -----------------------------


    def _get_name(
        self,
        item
    ):

        if isinstance(item,dict):

            return item.get(
                "test_name",
                ""
            )

        return getattr(
            item,
            "test_name",
            ""
        )



    # -----------------------------


    def _set_name(
        self,
        item,
        value
    ):


        if isinstance(item,dict):

            item["test_name"]=value


        else:

            item.test_name=value



    # -----------------------------


    def _clean(
        self,
        text
    ):


        text=text.lower()


        replacements={

            "cholestrol":
            "cholesterol",

            "cholest":
            "cholesterol",

            "triglycride":
            "triglyceride",

            "ferritin":
            "ferritin",

            "sgot ast":
            "sgot",

            "sgpt alt":
            "sgpt",

        }


        for a,b in replacements.items():

            text=text.replace(
                a,
                b
            )


        text=re.sub(
            r"[^a-z0-9 ]",
            " ",
            text
        )


        text=" ".join(
            text.split()
        )


        return text



    # -----------------------------


    def _find_best_match(
        self,
        name
    ):


        best=None
        score=0


        for candidate in self.COMMON_NAMES:


            c=self._clean(
                candidate
            )


            s=SequenceMatcher(
                None,
                name,
                c
            ).ratio()



            if s > score:

                score=s
                best=candidate



        if score >=0.75:

            return best


        return None