package com.avina.health.network

import android.content.Context
import okhttp3.Interceptor
import okhttp3.Response

class SignatureInterceptor(
    private val appContext: Context
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val deviceId = DeviceIdManager.getOrCreateDeviceId(appContext)
        val timestamp = RequestSigner.currentTimestamp()
        val signature = RequestSigner.generateSignature(
            deviceId = deviceId,
            timestamp = timestamp,
            secret = ApiConfig.HMAC_SECRET_KEY
        )

        val newRequest = chain.request().newBuilder()
            .addHeader("x-device-id", deviceId)
            .addHeader("x-timestamp", timestamp)
            .addHeader("x-signature", signature)
            .build()

        return chain.proceed(newRequest)
    }
}