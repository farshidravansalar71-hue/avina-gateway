from copy import deepcopy


def build_report_for_user(
    report_json: dict,
    is_premium: bool,
) -> dict:
    """
    نسخه قابل ارسال گزارش را بر اساس سطح دسترسی کاربر می‌سازد.
    گزارش کامل قبل از این مرحله در دیتابیس ذخیره می‌شود.
    این تابع فقط داده‌ای را که از API به کاربر ارسال می‌شود فیلتر می‌کند.
    """

    # کاربر Premium گزارش کامل را دریافت می‌کند.
    if is_premium:
        return report_json

    # روی کپی مستقل کار می‌کنیم تا گزارش اصلی تغییر نکند.
    report = deepcopy(report_json)

    # ==========================================
    # FREE ACCESS
    # ==========================================

    health_summary = report.get("health_summary")
    if isinstance(health_summary, dict):

        health_score = health_summary.get("health_score")
        if isinstance(health_score, dict):
            # عدد دقیق فقط Premium — ولی برچسب کلی (label، مثلاً
            # "نیازمند توجه") برای رایگان می‌ماند طبق تصمیم محصولی:
            # "حتی رایگان باید وضعیت کلی را ببیند، فقط نه عدد دقیق".
            health_score["score"] = None
            health_score.pop("description", None)
            # label عمداً دست‌نخورده می‌ماند.

        overall_status = health_summary.get("overall_status")
        if isinstance(overall_status, dict):
            # توضیح تحلیلی فقط Premium؛ title (اگر کوتاه و غیرتفسیری
            # است) دست‌نخورده می‌ماند — در صورت نیاز به سخت‌گیری بیشتر
            # می‌توان همان‌جا title را هم pop کرد.
            overall_status.pop("description", None)

    # یافته‌های هوشمند فقط Premium
    report["important_findings"] = []

    # توصیه‌های هوشمند فقط Premium
    report["smart_recommendations"] = []

    # نمودارها فقط Premium
    report["charts"] = {
        "available_tests": []
    }

    return report