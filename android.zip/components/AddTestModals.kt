package com.avina.health.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avina.health.ui.theme.AppTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAddTestBottomSheet(
    onDismiss: () -> Unit,
    onScanImageClick: () -> Unit,
    onManualEntryClick: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = AppTheme.colors.cardBackground, // تغییر به رنگ تم کارت‌ها
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ثبت آزمایش جدید",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = AppTheme.colors.textPrimary // هماهنگ با تم تیره/روشن
            )

            Spacer(modifier = Modifier.height(20.dp))

            BottomSheetOptionCard(
                title = "اسکن / ارسال تصویر آزمایش",
                subtitle = "تحلیل سریع و هوشمند برگه آزمایش با هوش مصنوعی",
                icon = Icons.Default.PhotoCamera,
                iconBackgroundColor = Color(0xFF2563EB),
                onClick = onScanImageClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            BottomSheetOptionCard(
                title = "ورود دستی اطلاعات",
                subtitle = "وارد کردن مقادیر و فاکتورهای آزمایش به‌صورت دستی",
                icon = Icons.Default.EditNote,
                iconBackgroundColor = Color(0xFF0284C7),
                onClick = onManualEntryClick
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageSourceBottomSheet(
    onDismiss: () -> Unit,
    onFileSelectClick: () -> Unit,
    onGallerySelectClick: () -> Unit,
    onCameraCaptureClick: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = AppTheme.colors.cardBackground, // تغییر به رنگ تم کارت‌ها
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "انتخاب منبع تصویر آزمایش",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = AppTheme.colors.textPrimary // هماهنگ با تم تیره/روشن
            )

            Spacer(modifier = Modifier.height(20.dp))

            BottomSheetOptionCard(
                title = "انتخاب فایل (PDF / مدرک)",
                subtitle = "آپلود فایل‌های مستندات پزشکی",
                icon = Icons.Default.InsertDriveFile,
                iconBackgroundColor = Color(0xFF0284C7),
                onClick = onFileSelectClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            BottomSheetOptionCard(
                title = "انتخاب از گالری تصاویر",
                subtitle = "انتخاب عکس برگه آزمایش از حافظه گوشی",
                icon = Icons.Default.PhotoLibrary,
                iconBackgroundColor = Color(0xFF7C3AED),
                onClick = onGallerySelectClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            BottomSheetOptionCard(
                title = "عکس‌برداری با دوربین",
                subtitle = "گرفتن عکس مستقیم از برگه آزمایش",
                icon = Icons.Default.PhotoCamera,
                iconBackgroundColor = Color(0xFF2563EB),
                onClick = onCameraCaptureClick
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun BottomSheetOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBackgroundColor: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        color = AppTheme.colors.pageBackground, // تطبیق رنگ پس‌زمینه کارت گزینه‌ها با تم
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AppTheme.colors.textSecondary.copy(alpha = 0.15f)) // حاشیه ملایم متناسب با تم
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(iconBackgroundColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start // به صورت استاندارد برای خوانایی بهتر متن‌های فارسی چپ‌چین/راست‌چین
            ) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppTheme.colors.textPrimary, // رنگ متناسب با دارک‌مُد
                    textAlign = TextAlign.Start
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = AppTheme.colors.textSecondary, // رنگ متناسب با دارک‌مُد
                    textAlign = TextAlign.Start
                )
            }
        }
    }
}