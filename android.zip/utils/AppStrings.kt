package com.avina.health.utils

object AppStrings {
    fun get(key: String, lang: String): String {
        return when (lang) {
            "en" -> when (key) {
                "app_name" -> "Avin Med"
                "profile_title" -> "Profile"
                "history_title" -> "Lab History"
                "language_title" -> "Language"
                "language_subtitle" -> "Farsi, English"
                "logout" -> "Log Out"
                else -> key
            }
            else -> when (key) { // پیش‌فرض فارسی
                "app_name" -> "آوین طب"
                "profile_title" -> "پروفایل"
                "history_title" -> "تاریخچه آزمایش‌ها"
                "language_title" -> "زبان"
                "language_subtitle" -> "فارسی ، English"
                "logout" -> "خروج از حساب کاربری"
                else -> key
            }
        }
    }
}