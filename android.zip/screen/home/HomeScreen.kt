package com.avina.health.screen.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.avina.health.components.AiInsightCard
import com.avina.health.components.AttentionCard
import com.avina.health.components.HealthScoreCard
import com.avina.health.components.HomeHeader
import com.avina.health.components.TrendChartSection
import com.avina.health.data.UserPreferencesManager
import com.avina.health.screen.profile.ProfileViewModel
import com.avina.health.ui.theme.AppTheme
import com.avina.health.utils.LocalLanguage

data class HomeActions(
    val onNavigateToHealthDetail: () -> Unit = {},
    val onNavigateToAiRecommendation: () -> Unit = {},
    val onLogoutClick: () -> Unit = {},
    val onNavigateToAddTest: () -> Unit = {},
    val onNavigateToReports: () -> Unit = {},
    val onNavigateToAi: () -> Unit = {},
    val onNavigateToProfile: () -> Unit = {},
    val onNavigateToAttentionDetail: () -> Unit = {},
    val onNotificationClick: () -> Unit = {},
    val onSearchClick: () -> Unit = {},
    val onOcrScanClick: () -> Unit = {},
    val onPdfReportClick: () -> Unit = {},
    val onConsultationClick: () -> Unit = {},
    val onTrendClick: () -> Unit = {}
)

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    userName: String = "سید",
    actions: HomeActions = HomeActions(),
    profileViewModel: ProfileViewModel = viewModel()
) {
    val context = LocalContext.current
    val userPreferencesManager = remember { UserPreferencesManager(context) }
    val profileImageUri by userPreferencesManager.profileImageUri.collectAsState(initial = null)

    // دریافت وضعیت اتوماتیک اعلان‌های خوانده‌نشده
    val hasUnreadNotifications by profileViewModel.hasUnreadNotifications.collectAsState()

    // گرفتن زبان جاری به صورت خودکار از MainActivity
    val currentLang = LocalLanguage.current
    val isEnglish = currentLang == "en"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppTheme.colors.pageBackground)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // فراخوانی هدر با قابلیت بج اتوماتیک
        HomeHeader(
            userName = userName,
            profileImageUri = profileImageUri,
            hasUnreadNotifications = hasUnreadNotifications,
            onNotificationClick = {
                profileViewModel.markNotificationsAsRead()
                actions.onNotificationClick()
            },
            onProfileClick = actions.onNavigateToProfile
        )

        // متن کارت هوش مصنوعی بر اساس زبان
        AiInsightCard(
            text = if (isEnglish)
                "Your Vitamin D level is low.\n15 minutes of sun walking is recommended today."
            else
                "سطح ویتامین D شما پایین است.\nامروز ۱۵ دقیقه پیاده‌روی در آفتاب توصیه می‌شود.",
            onDetailClick = actions.onNavigateToAiRecommendation,
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            HealthScoreCard(
                score = 78,
                statusText = if (isEnglish) "Excellent" else "عالی",
                onDetailClick = actions.onNavigateToHealthDetail,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            )

            AttentionCard(
                items = if (isEnglish) {
                    listOf("Vitamin D", "LDL Cholesterol", "Triglycerides")
                } else {
                    listOf("ویتامین D", "کلسترول LDL", "تری‌گلیسیرید")
                },
                onSeeAllClick = actions.onNavigateToAttentionDetail,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            )
        }

        TrendChartSection(
            modifier = Modifier.fillMaxWidth(),
            onSeeAllClick = actions.onTrendClick
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}