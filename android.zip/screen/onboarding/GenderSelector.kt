package com.avina.health.screen.onboarding

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import com.avina.health.ui.theme.AppTheme
import com.avina.health.ui.theme.PrimaryBlue

@Composable
fun GenderSelector(
    selected: String,
    onSelected: (String) -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "جنسیت",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = AppTheme.colors.textPrimary
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GenderItem(
                    modifier = Modifier.weight(1f),
                    emoji = "👨",
                    title = "مرد",
                    selected = selected == "مرد",
                    onClick = {
                        onSelected("مرد")
                    }
                )

                GenderItem(
                    modifier = Modifier.weight(1f),
                    emoji = "👩",
                    title = "زن",
                    selected = selected == "زن",
                    onClick = {
                        onSelected("زن")
                    }
                )
            }
        }
    }
}

@Composable
private fun GenderItem(
    modifier: Modifier = Modifier,
    emoji: String,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val borderColor =
        if (selected)
            PrimaryBlue
        else
            PrimaryBlue.copy(alpha = 0.2f)

    val backgroundColor =
        if (selected)
            PrimaryBlue.copy(alpha = 0.1f)
        else
            AppTheme.colors.cardBackground

    Column(
        modifier = modifier
            .height(90.dp)
            .background(
                color = backgroundColor,
                shape = RoundedCornerShape(18.dp)
            )
            .border(
                width = 1.5.dp,
                color = borderColor,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable {
                onClick()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = emoji,
            fontSize = 28.sp
        )

        Spacer(
            modifier = Modifier.height(6.dp)
        )

        Text(
            text = title,
            fontSize = 15.sp,
            color = AppTheme.colors.textPrimary,
            fontWeight = FontWeight.Medium
        )
    }
}