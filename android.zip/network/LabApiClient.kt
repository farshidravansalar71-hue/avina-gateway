package com.avina.health.network

import android.content.Context
import android.util.Log
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit

object LabApiClient {

    private const val TAG = "AVINA_API"

    private const val BASE_URL = "http://10.157.129.140:8000/"

    /*
     * JSON configuration
     */
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        explicitNulls = false
    }

    /*
     * HTTP Logging
     */
    private val loggingInterceptor =
        HttpLoggingInterceptor { message ->
            Log.d(TAG, message)
        }.apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

    /*
     * Service instance - lazy، چون به Context نیاز داریم که فقط بعد از init() موجوده
     */
    private var _service: LabApiService? = null

    val service: LabApiService
        get() = _service
            ?: throw IllegalStateException(
                "LabApiClient.init(context) باید قبل از استفاده از service صدا زده شود"
            )

    /*
     * باید یک‌بار، ترجیحاً در Application.onCreate() یا MainActivity.onCreate() صدا زده شود
     */
    fun init(context: Context) {
        if (_service != null) {
            return // قبلاً initialize شده
        }

        val appContext = context.applicationContext

        val httpClient = OkHttpClient.Builder()
            .addInterceptor(SignatureInterceptor(appContext))
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient)
            .addConverterFactory(
                json.asConverterFactory("application/json".toMediaType())
            )
            .build()

        _service = retrofit.create(LabApiService::class.java)

        Log.d(TAG, "========================================")
        Log.d(TAG, "LabApiClient initialized")
        Log.d(TAG, "Base URL = $BASE_URL")
        Log.d(TAG, "Endpoint = /api/v1/lab/analyze")
        Log.d(TAG, "========================================")
    }
}