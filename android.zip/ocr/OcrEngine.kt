package com.avina.health.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class OcrElement(
    val text: String,
    val boundingBox: Rect?
)

data class OcrLine(
    val text: String,
    val boundingBox: Rect?,
    val elements: List<OcrElement>
)

data class OcrBlock(
    val text: String,
    val boundingBox: Rect?,
    val lines: List<OcrLine>
)

data class OcrResult(
    val fullText: String,
    val blocks: List<OcrBlock>
)

class OcrEngine {

    private val recognizer = TextRecognition.getClient(
        TextRecognizerOptions.DEFAULT_OPTIONS
    )

    suspend fun recognizeText(
        bitmap: Bitmap
    ): Result<OcrResult> = suspendCancellableCoroutine { continuation ->

        if (bitmap.isRecycled) {
            continuation.resume(
                Result.failure(
                    IllegalArgumentException("Bitmap معتبر نیست یا recycle شده است")
                )
            )
            return@suspendCancellableCoroutine
        }

        val image = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->

                if (!continuation.isActive) return@addOnSuccessListener

                val fullText = visionText.text.trim()

                if (fullText.isBlank()) {
                    continuation.resume(
                        Result.failure(
                            Exception("متنی از تصویر پیدا نشد")
                        )
                    )
                    return@addOnSuccessListener
                }

                val blocks = visionText.textBlocks.map { block ->

                    val lines = block.lines.map { line ->

                        val elements = line.elements.map { element ->
                            OcrElement(
                                text = element.text,
                                boundingBox = element.boundingBox?.let(::Rect)
                            )
                        }

                        OcrLine(
                            text = line.text,
                            boundingBox = line.boundingBox?.let(::Rect),
                            elements = elements
                        )
                    }

                    OcrBlock(
                        text = block.text,
                        boundingBox = block.boundingBox?.let(::Rect),
                        lines = lines
                    )
                }

                continuation.resume(
                    Result.success(
                        OcrResult(
                            fullText = fullText,
                            blocks = blocks
                        )
                    )
                )
            }
            .addOnFailureListener { exception ->

                if (!continuation.isActive) return@addOnFailureListener

                continuation.resume(
                    Result.failure(exception)
                )
            }

        continuation.invokeOnCancellation {
            /*
             * ML Kit در این API لغو مستقیم پردازش را ارائه نمی‌دهد.
             * فقط از resume شدن Coroutine لغوشده جلوگیری می‌کنیم.
             */
        }
    }

    fun createDebugText(
        result: OcrResult
    ): String {

        val output = StringBuilder()

        output.appendLine("========== OCR DEBUG ==========")
        output.appendLine()
        output.appendLine("FULL TEXT:")
        output.appendLine(result.fullText)
        output.appendLine()
        output.appendLine("========== ELEMENTS ==========")
        output.appendLine()

        var elementIndex = 1

        for ((blockIndex, block) in result.blocks.withIndex()) {

            output.appendLine("BLOCK ${blockIndex + 1}")
            output.appendLine(
                "Block Box: ${formatRect(block.boundingBox)}"
            )
            output.appendLine()

            for ((lineIndex, line) in block.lines.withIndex()) {

                output.appendLine(
                    "  LINE ${lineIndex + 1}: ${line.text}"
                )

                output.appendLine(
                    "  Line Box: ${formatRect(line.boundingBox)}"
                )

                for (element in line.elements) {

                    val box = element.boundingBox

                    output.appendLine(
                        "    [$elementIndex] \"${element.text}\""
                    )

                    output.appendLine(
                        "        X=${box?.left ?: -1} " +
                                "Y=${box?.top ?: -1} " +
                                "R=${box?.right ?: -1} " +
                                "B=${box?.bottom ?: -1}"
                    )

                    output.appendLine(
                        "        CenterX=${box?.centerX() ?: -1} " +
                                "CenterY=${box?.centerY() ?: -1}"
                    )

                    output.appendLine()

                    elementIndex++
                }

                output.appendLine()
            }

            output.appendLine("--------------------------------")
        }

        return output.toString()
    }

    private fun formatRect(
        rect: Rect?
    ): String {
        return rect?.let {
            "L=${it.left}, T=${it.top}, " +
                    "R=${it.right}, B=${it.bottom}"
        } ?: "null"
    }

    fun close() {
        recognizer.close()
    }
}