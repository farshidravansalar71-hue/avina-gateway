import json
import time
import logging

from google import genai

from app.core.settings import settings


logger = logging.getLogger(__name__)


class GeminiClient:
    """
    AVINA Gemini Analysis Client


    Flow:

    Selected Lab JSON
          |
          v
    Gemini Analysis
          |
          v
    Analysis JSON

    """


    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        max_retries: int = 3
    ):


        self.keys = (
            [api_key]
            if api_key
            else settings.GEMINI_KEYS
        )


        if not self.keys:

            raise ValueError(
                "Gemini API keys not found"
            )


        self.model = (
            model
            or settings.GEMINI_MODEL
        )


        self.max_retries = max_retries


        self.current_key_index = 0


        self._create_client()



    # =====================================================
    # CREATE CLIENT
    # =====================================================

    def _create_client(self):


        key = self.keys[
            self.current_key_index
        ]


        self.client = genai.Client(
            api_key=key
        )


        logger.info(
            f"Gemini ready key={self.current_key_index + 1}"
        )



    # =====================================================
    # ANALYZE SELECTED LAB DATA
    # =====================================================

    def analyze(
        self,
        gemini_input: dict
    ) -> dict:


        tests_json = json.dumps(
            gemini_input,
            ensure_ascii=False,
            separators=(
                ",",
                ":"
            )
        )


        prompt = f"""
تو موتور تحلیل آزمایش پزشکی آوینا هستی.

داده زیر فقط شامل آزمایش‌های مهم انتخاب شده است.

قوانین:
- فقط بر اساس داده ورودی تحلیل کن.
- مقدار جدید تولید نکن.
- نام لاتین آزمایش را تغییر نده و دقیقاً در test_name قرار بده.
- حتماً برای هر آزمایش، معادل روان فارسی و پزشکی آن را در persian_name بنویس (مثلاً فریتین / ذخیره آهن).
- یک توضیح علمی و جامع در description هر تست بنویس که شامل: کاربرد آزمایش در بدن، علت اهمیت آن، و عوارض بالا یا پایین بودن آن باشد.
- تشخیص قطعی پزشکی نده.
- اگر reference وجود ندارد حدس نزن.
- موارد طبیعی را در important_findings قرار نده.
- value در findings باید دقیقا برابر ورودی باشد.

خروجی فقط JSON معتبر باشد.

ساختار:

{{
"health_score": {{
 "score":0,
 "label":"",
 "description":""
}},

"overall_status": {{
 "status":"",
 "title":"",
 "description":""
}},

"important_findings":[
 {{
 "test_name":"",
 "persian_name":"",
 "value":"",
 "status":"",
 "explanation":"",
 "description":""
 }}
],

"attention_items":[
 {{
 "title":"",
 "description":"",
 "priority":""
 }}
],

"recommendations":[]
}}

ورودی آزمایش:

{tests_json}
"""


        response = self._generate(
            prompt
        )


        return self._parse_json(
            response
        )



    # =====================================================
    # GENERATE
    # =====================================================

    def _generate(
        self,
        prompt
    ):


        last_error = None


        for attempt in range(
            1,
            self.max_retries + 1
        ):


            try:


                response = (
                    self.client
                    .models
                    .generate_content(
                        model=self.model,
                        contents=prompt,
                        config={
                            "response_mime_type":
                            "application/json"
                        }
                    )
                )


                self._print_usage(
                    response
                )


                if not response.text:

                    raise Exception(
                        "Empty Gemini response"
                    )


                return response.text



            except Exception as e:


                last_error = e


                logger.error(
                    f"Gemini error key={self.current_key_index + 1}: {e}"
                )


                self.current_key_index = (
                    self.current_key_index + 1
                ) % len(self.keys)



                self._create_client()



                if attempt < self.max_retries:

                    time.sleep(
                        attempt * 2
                    )



        raise RuntimeError(
            f"Gemini failed: {last_error}"
        )



    # =====================================================
    # JSON PARSER
    # =====================================================

    def _parse_json(
        self,
        text: str
    ):


        text = (
            text
            .strip()
            .replace(
                "```json",
                ""
            )
            .replace(
                "```",
                ""
            )
            .strip()
        )


        start = text.find(
            "{"
        )


        end = text.rfind(
            "}"
        )


        if start != -1 and end != -1:

            text = text[
                start:end+1
            ]


        return json.loads(
            text
        )



    # =====================================================
    # TOKEN MONITOR
    # =====================================================

    def _print_usage(
        self,
        response
    ):


        print(
            "\n====== GEMINI USAGE ======"
        )


        usage = getattr(
            response,
            "usage_metadata",
            None
        )


        if usage:


            print(
                "Prompt tokens:",
                getattr(
                    usage,
                    "prompt_token_count",
                    None
                )
            )


            print(
                "Output tokens:",
                getattr(
                    usage,
                    "candidates_token_count",
                    None
                )
            )


            print(
                "Total tokens:",
                getattr(
                    usage,
                    "total_token_count",
                    None
                )
            )


        else:

            print(
                "No usage metadata returned"
            )


        print(
            "==========================\n"
        )