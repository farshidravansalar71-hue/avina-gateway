package com.avina.health.screen.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


@Composable
fun WelcomeScreen(
    onStartClick: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {


        Text(
            text = "🩺",
            fontSize = 60.sp
        )


        Spacer(
            modifier = Modifier.height(20.dp)
        )


        Text(
            text = "Welcome to Avina",
            fontSize = 28.sp
        )


        Spacer(
            modifier = Modifier.height(10.dp)
        )


        Text(
            text = "Your smart health assistant"
        )


        Spacer(
            modifier = Modifier.height(40.dp)
        )


        Button(
            onClick = onStartClick,
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "شروع"
            )

        }

    }
}