from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # =========================
    # Application
    # =========================
    APP_NAME: str = "Avina Lab API"

    # =========================
    # Limits
    # =========================
    FREE_ANALYSIS_LIMIT: int = 3
    MAX_IMAGE_SIZE_MB: int = 5

    # =========================
    # Database
    # =========================
    DATABASE_URL: str = "sqlite:///./avina.db"

    # =========================
    # Security
    # =========================
    HMAC_SECRET_KEY: str | None = None

    # =========================
    # AI PIPELINE
    #
    # Image
    #  ↓
    # GPT Vision
    #  ↓
    # Raw JSON
    #  ↓
    # Normalizer
    #  ↓
    # Selector
    #  ↓
    # Gemini
    #  ↓
    # Validation
    #  ↓
    # Final JSON
    # =========================
    ENABLE_GPT_VISION: bool = True
    ENABLE_GEMINI_ANALYSIS: bool = True
    MAX_GEMINI_RETRIES: int = 3

    # =========================
    # OpenAI GPT Vision
    # =========================
    OPENAI_API_KEY: str | None = None
    OPENAI_BASE_URL: str | None = None
    OPENAI_MODEL: str = "gpt-5.2-chat"

    # =========================
    # Gemini Analysis
    # =========================
    GEMINI_MODEL: str = "gemini-3.5-flash-lite"

    # Gemini Key Pool
    GEMINI_KEY_1: str | None = None
    GEMINI_KEY_2: str | None = None
    GEMINI_KEY_3: str | None = None
    GEMINI_KEY_4: str | None = None
    GEMINI_KEY_5: str | None = None
    GEMINI_KEY_6: str | None = None
    GEMINI_KEY_7: str | None = None

    @property
    def GEMINI_KEYS(self):
        return [
            key
            for key in [
                self.GEMINI_KEY_1,
                self.GEMINI_KEY_2,
                self.GEMINI_KEY_3,
                self.GEMINI_KEY_4,
                self.GEMINI_KEY_5,
                self.GEMINI_KEY_6,
                self.GEMINI_KEY_7,
            ]
            if key
        ]

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache
def get_settings():
    instance = Settings()

    if not instance.HMAC_SECRET_KEY:
        raise RuntimeError(
            "HMAC_SECRET_KEY is not configured. "
            "Set it in your .env file before starting the server."
        )

    return instance


settings = get_settings()