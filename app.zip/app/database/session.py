from sqlalchemy.orm import sessionmaker

from app.database.database import engine


# =========================
# Database Session Factory
# =========================

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


# =========================
# FastAPI Dependency
# =========================

def get_db():

    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()