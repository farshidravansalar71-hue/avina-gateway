from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.database.models import User
from app.auth.jwt import create_access_token
# اگر تابع verify_password در security.py قرار دارد آن را ایمپورت کنید:
from app.auth.password import verify_password

router = APIRouter(prefix="/api/v1/admin/auth", tags=["Admin Auth"])


@router.post("/login")
def admin_login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    لاگین ادمین و دریافت Access Token جهت دسترسی به پنل مدیریت
    """
    # 1. پیدا کردن کاربر بر اساس ایمیل یا public_id (وارد شده در فیلد username)
    user = db.query(User).filter(
        (User.email == form_data.username) | (User.public_id == form_data.username)
    ).first()

    # 2. بررسی وجود کاربر
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="نام کاربری یا رمز عبور اشتباه است."
        )

    # 3. بررسی صحت پسورد (با فرض استفاده از verify_password)
    if not verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="نام کاربری یا رمز عبور اشتباه است."
        )

    # 4. بررسی فعال بودن و داشتن دسترسی ادمین
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="حساب کاربری شما غیرفعال شده است."
        )

    if not user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="شما دسترسی مدیریت به این بخش را ندارید."
        )

    # 5. به‌روزرسانی زمان آخرین ورود
    user.last_login = datetime.utcnow()
    db.commit()

    # 6. ساخت توکن JWT
    access_token = create_access_token(data={"sub": str(user.id)})

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }