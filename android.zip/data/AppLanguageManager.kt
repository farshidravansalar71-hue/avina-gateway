//انتخاب زبان
package com.avina.health.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings_prefs")

class AppLanguageManager(private val context: Context) {
    companion object {
        private val LANGUAGE_KEY = stringPreferencesKey("app_language")
    }

    // گرفتن زبان ذخیره‌شده (پیش‌فرض فارسی "fa")
    val currentLanguage: Flow<String> = context.dataStore.data
        .map { preferences ->
            preferences[LANGUAGE_KEY] ?: "fa"
        }

    // ذخیره کردن زبان جدید (fa یا en)
    suspend fun setLanguage(languageCode: String) {
        context.dataStore.edit { preferences ->
            preferences[LANGUAGE_KEY] = languageCode
        }
    }
}